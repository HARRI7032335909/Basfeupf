package com.basfeupf.core.models;

import java.util.List;
import java.util.Map;

public interface FooterLinks {
    String getTitleText();
    String getSubTitleText();
    String getFileReference();
    String getCopyright();

    List<Map<String, String>> getLinkList_column1();
    List<Map<String, String>> getLinkList_column2();
    List<Map<String, String>> getLinkList_column3();
    List<Map<String, String>> getLinkList_column4();
    List<Map<String, String>> getLinkList_column5();
}
