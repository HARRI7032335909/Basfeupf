package com.basfeupf.core.models.impl;

import com.basfeupf.core.models.CxmSupport;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.*;

@Model(adaptables =SlingHttpServletRequest.class,adapters = CxmSupport.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class CxmSupportImpl implements CxmSupport {
 private static final Logger LOG= LoggerFactory.getLogger(CxmSupportImpl.class);

    private static final String OPTIONS_NAME = "businessSegments";
    @ValueMapValue
    private String phoneSupportHeading;
    @ValueMapValue
    private String phoneSupportDescription;
    @ValueMapValue
    private String emailSupportHeading;
    @ValueMapValue
    private String leftColumnTitle;
    @ValueMapValue
    private String rightColumnTitle;
    @ValueMapValue
    private String customerServiceLabel;
    @ValueMapValue
    private String repSupportDescription;
    @ValueMapValue
    private String repImagePath;
    @ValueMapValue
    private String callusat;
    @ValueMapValue
    private String gonow;

    @Self
    private SlingHttpServletRequest request;

    @ValueMapValue
    private String businessSegments;

   @Inject
    Resource componentResource;
    private static final String SEGMENT_ID = "segmentId";
    private static final String SEGMENT_TITLE = "segmentTitle";
    private static final String SEGMENT_EMAIL_TITLE ="segmentEmailTitle";
    private static final String SEGMENT_DESCRIPTION ="segmentDescription";
    private static final String SEGMENT_IMAGE ="segmentImage";
    private static final String SEGMENT_HOURS ="segmentHours";
    private static final String SEGMENT_PHONE ="segmentPhone";
    private static final String SEGMENT_EMAIL ="segmentEmail";





    @Override
    public String getPhoneSupportHeading() {
        return phoneSupportHeading;
    }

    @Override
    public String getPhoneSupportDescription() {
        return phoneSupportDescription;
    }

    @Override
    public String getEmailSupportHeading() {
        return emailSupportHeading;
    }

    @Override
    public String getLeftColumnTitle() {
        return leftColumnTitle;
    }

    @Override
    public String getRightColumnTitle() {
        return rightColumnTitle;
    }

    @Override
    public String getCustomerServiceLabel() {
        return customerServiceLabel;
    }

    @Override
    public String getRepSupportDescription() {
        return repSupportDescription;
    }

    @Override
    public String getRepImagePath() {
        return repImagePath;
    }
    @Override
    public String getCallus() {
        return callusat;
    }
    @Override
    public String getGonow() {
        return gonow;
    }
    @Override
    public String getBusinessSegments() {
        return this.businessSegments;
    }

    @PostConstruct
    private void init() {
        Iterator<Resource> resItr = request.getResource().listChildren();
        Iterator<Resource> resnext = resItr.next().listChildren();
        StringBuilder segment_sb = new StringBuilder("[");
        while (resnext.hasNext()) {
            Resource res1 = resnext.next();
            if (StringUtils.equals(res1.getName(), OPTIONS_NAME)) {
                Iterator<Resource> resItr2 = res1.listChildren();
                while (resItr2.hasNext()) {
                    Resource res = resItr2.next();
                    ValueMap vm = res.getValueMap();
                    String segmentId = vm.get(SEGMENT_ID, StringUtils.EMPTY);
                    String segmentTitle = vm.get(SEGMENT_TITLE, StringUtils.EMPTY);
                    String segmentEmailTitle = vm.get(SEGMENT_EMAIL_TITLE,StringUtils.EMPTY);
                    String segmentDescription = vm.get(SEGMENT_DESCRIPTION,StringUtils.EMPTY);
                    String segmentImage = vm.get(SEGMENT_IMAGE,StringUtils.EMPTY);
                    String segmentHours = vm.get(SEGMENT_HOURS,StringUtils.EMPTY);
                    String segmentPhone = vm.get(SEGMENT_PHONE, StringUtils.EMPTY);
                    String segmentEmail = vm.get(SEGMENT_EMAIL,StringUtils.EMPTY);
                    segment_sb.append("{\"segmentId\":\"").append(segmentId).append("\",\"segmentTitle\":\"").append(segmentTitle).append("\",\"segmentEmailTitle\":\"").append(segmentEmailTitle).append("\",\"segmentDescription\":\"").append(segmentDescription).append("\",\"segmentImage\":\"").append(segmentImage).append("\",\"segmentHours\":\"").append(segmentHours).append("\",\"segmentPhone\":\"").append(segmentPhone).append("\",\"segmentEmail\":\"").append(segmentEmail).append("\"},");
                }
                if (segment_sb.length() > 1) {
                    segment_sb = segment_sb.deleteCharAt(segment_sb.length() - 1);
                }
            }
        }
        segment_sb.append("]");
        this.businessSegments = segment_sb.toString();
    }
}
