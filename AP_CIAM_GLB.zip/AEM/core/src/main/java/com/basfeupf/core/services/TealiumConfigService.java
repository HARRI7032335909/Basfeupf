package com.basfeupf.core.services;

public interface TealiumConfigService {
    String getTealiumDomain();
}