package com.basfeupf.core.services;

import com.google.gson.JsonObject;

public interface AppAccessTokenService {
    JsonObject getAppAccessToken(JsonObject requestObject);
}
