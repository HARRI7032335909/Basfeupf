package com.basfeupf.core.services;

public interface LogServise {
	
	public void log_message(String url,String request, String response, String time);

}
