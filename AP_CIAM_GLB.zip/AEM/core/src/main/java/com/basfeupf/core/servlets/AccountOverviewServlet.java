package com.basfeupf.core.servlets;
import com.basfeupf.core.constants.Basf_Constant;
import com.basfeupf.core.services.*;
import com.google.gson.Gson;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.servlet.Servlet;
import com.google.gson.JsonObject;

@Component(service = Servlet.class, immediate = true,
		property = {
        "sling.servlet.resourceTypes="+AccountOverviewServlet.RESOURCE_TYPES,
        "sling.servlet.methods="+HttpConstants.METHOD_POST,
        "sling.servlet.extensions=json"
})

public class AccountOverviewServlet extends SlingAllMethodsServlet {

	private static final long serialVersionUID = 1L;

	@Reference
	AuthConfigService authConfigService;
	
	@Reference
	TalendServise talendServise;

	public final static String RESOURCE_TYPES = "/bin/eupf/accountoverview";
	
	Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		response.setContentType("application/json");
		JsonObject responseJson = handlePost(request, response);
		out.println(responseJson);

	}
	private JsonObject handlePost(SlingHttpServletRequest request, SlingHttpServletResponse response) {

		JsonObject accountJsonObject = new JsonObject();
		try {
			String[] selectors = request.getRequestPathInfo().getSelectors();
			if (selectors.length > 0) {
				String endPointURL = StringUtils.EMPTY;
				switch (selectors[0]) {
					case "get_repo_details":
						endPointURL=authConfigService.getTalendEndpointUrlv1()+"/repinfo/repdetails";
						break;
					case "get_account_overview":
						endPointURL=authConfigService.getTalendEndpointUrlv1()+"/account/detail";
						break;
					case "get_account_contacts":
						endPointURL=authConfigService.getTalendEndpointUrlv1()+"/account/contacts";
						break;
					case "get_embedded_report":
						endPointURL=authConfigService.getTalendEndpointUrlv1()+"/order/visibility";
						break;
					case "get_activity_representative":
						endPointURL=authConfigService.getTalendEndpointUrlv1()+"/activity/representatives";
						break;
					case "account_update":
						endPointURL=authConfigService.getTalendEndpointUrlv1()+"/account/update";
						break;
					default:
						accountJsonObject.addProperty(Basf_Constant.ERROR_MSG, selectors[0] + " - no service found");
						break;
				}
				if (StringUtils.isNotBlank(endPointURL)){
					JsonObject headerJson = new JsonObject();
					headerJson.addProperty("client_secret", authConfigService.getEupf_apigee_talend_key());
					headerJson.addProperty("client_id", authConfigService.getEupf_apigee_talend_client_id());
					JsonObject requestPayloadJson = new Gson().fromJson(request.getReader(), JsonObject.class);
					accountJsonObject =talendServise.callPost(requestPayloadJson, endPointURL, headerJson);
				}

			} else {
				accountJsonObject.addProperty(Basf_Constant.ERROR_MSG, "Please select a valid service");
			}

		} catch (Exception e) {
			accountJsonObject.addProperty(Basf_Constant.ERROR_MSG, e.getClass().getSimpleName() + " : " + e.getMessage());
			StackTraceElement[] sTElements = e.getStackTrace();
			for (StackTraceElement stackTraceEle : sTElements) {
				String corePackageName = this.getClass().getPackage().getName().split("core")[0] + "core";
				if (stackTraceEle.getClassName().contains(corePackageName)) {
					StringBuffer stringBuffer = new StringBuffer();
					stringBuffer.append("\n{").append("\n\t\"ClassName\" : \"" + stackTraceEle.getClassName() + "\"")
							.append("\n\t\"MethodName\" : \"" + stackTraceEle.getMethodName() + "\",")
							.append("\n\t\"LineNumber\" : \"" + stackTraceEle.getLineNumber() + "\",")
							.append("\n\t\"" + e.getClass().getSimpleName() + "\" : \"" + e.getMessage() + "\"")
							.append("\n}\n");
					logger.error(stringBuffer.toString());
					accountJsonObject.addProperty(Basf_Constant.ERROR_MSG, stringBuffer.toString());
					break;
				}
			}
		}
		return accountJsonObject;
	}
}
