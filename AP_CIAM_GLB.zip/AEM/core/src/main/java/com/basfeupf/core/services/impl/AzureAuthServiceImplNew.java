package com.basfeupf.core.services.impl;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.RSAPublicKeySpec;
import java.util.Objects;

import javax.servlet.http.Cookie;

import com.basfeupf.core.services.AzureAuthService;
import org.apache.commons.codec.binary.Base64;
import org.apache.sling.api.SlingHttpServletRequest;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.basfeupf.core.constants.Basf_Constant;
import com.basfeupf.core.services.AuthConfigService;
import com.basfeupf.core.services.AzureAuthServiceNew;
import com.basfeupf.core.services.HttpCallerService;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

@Component(service = AzureAuthServiceNew.class)
public class AzureAuthServiceImplNew implements AzureAuthServiceNew {

	@Reference
	HttpCallerService httpCallerService;

	@Reference
	AuthConfigService authConfigService;

	@Reference
	AzureAuthService azureAuthService;
	
	Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public JsonObject isValidToken(SlingHttpServletRequest request)
			throws Exception {

		JsonObject responseJson = new JsonObject();
		String id_token = null;
		String state = null;
		String nonce = null;
		Cookie[] cookies = request.getCookies();
		
		for (Cookie cookie : cookies) {
			String cookieName = cookie.getName();
			String cookieValue = cookie.getValue();
			
			if (cookieName.equals("id_token")) {
				id_token = cookieValue;
			} else if (cookieName.equals("state")) {
				state = cookieValue;
			} else if (cookieName.equals("nonce")) {
				nonce = cookieValue;
			}
		}
		
		if (Objects.isNull(id_token) && Objects.isNull(nonce)) {
			responseJson.addProperty(Basf_Constant.STATUS, Basf_Constant.STATUS_FAIL);
			responseJson.addProperty(Basf_Constant.ERROR_MSG, "id_token or nonce not found");
			return responseJson;
		}
		
		String policy = "";
		if (Objects.nonNull(state) && !state.isEmpty()) {
			if (state.equals(Basf_Constant.LOGIN)) {
				policy = authConfigService.getAzure_loginPolicy();
			} else if (state.equals(Basf_Constant.FORGOT_PASSWORD)) {
				policy = authConfigService.getAzure_resetPasswordPolicy();
			} else if (state.equals(Basf_Constant.PARTNER)) {
				policy = authConfigService.getAzure_partner_signupPolicy();
			}  else if (state.equals(Basf_Constant.REGISTER)) {
				policy = authConfigService.getAzure_enduser_signupPolicy();
			}
		} else {
			policy = authConfigService.getAzure_enduser_signupPolicy();
		}

		String[] id_token_parts = id_token.split("\\.");
		byte[] data = (id_token_parts[0] + "." + id_token_parts[1]).getBytes(StandardCharsets.UTF_8);
		byte[] ID_TOKEN_SIGNATURE = base64UrlDecodeToBytes(id_token_parts[2]);


		String openIdConfigUrl = getOpenIdConfigUrl(policy);

		JsonObject openIdConfig = httpCallerService.callGet(openIdConfigUrl);
		String jwks_uri = getJwks_uri(openIdConfig);
		String issuer = getIssuer(openIdConfig);

		JsonObject metaKeyObject = getMetaKeyObject(jwks_uri);
		PublicKey publicKey = getPublicKey(metaKeyObject);

		boolean isSignatureValid = verifyUsingPublicKey(data, ID_TOKEN_SIGNATURE, publicKey);
		if (isSignatureValid) {
			boolean isClaimsValid = validateClaims(id_token, nonce, issuer);
			if (isClaimsValid) {
				responseJson.addProperty(Basf_Constant.STATUS, Basf_Constant.STATUS_SUCCESS);
				responseJson.addProperty("request_origin", "same origin");
				return responseJson;
			} else {
				JsonObject thirdPartyClaims = validateThirdPartyClaims(id_token, nonce, issuer);
				thirdPartyClaims.addProperty("request_origin", "different origin");
				return thirdPartyClaims;
			}
		} else {
			responseJson.addProperty(Basf_Constant.STATUS, Basf_Constant.STATUS_FAIL);
			responseJson.addProperty(Basf_Constant.ERROR_MSG, "signature not matched");
		}
		return responseJson;
	}
	
	@Override
	public JsonObject isValidToken(JsonObject jsonObject) throws Exception {
		
		String id_token = jsonObject.get("id_token").getAsString();
		String nonce = jsonObject.get("nonce").getAsString();
		String state = null;
		JsonObject jsonObjectJwt= new JsonObject();
		
		if (jsonObject.has("state")) {
			state = jsonObject.get("state").getAsString();
		}

		/***************************/
		String policy = "";
		JsonObject payLoadJson = azureAuthService.getPayloadJson(id_token);
		if(payLoadJson.has("tfp")){
			policy=payLoadJson.get("tfp").getAsString();
		}
/****************************/
		

		if (Objects.nonNull(state) && !state.isEmpty() && policy.equals("")) {
			if (state.equals(Basf_Constant.LOGIN)) {
				policy = authConfigService.getAzure_loginPolicy();
			} else if (state.equals(Basf_Constant.FORGOT_PASSWORD)) {
				policy = authConfigService.getAzure_resetPasswordPolicy();
			} else if (state.equals(Basf_Constant.PARTNER)) {
				policy = authConfigService.getAzure_partner_signupPolicy();
			} else if (state.equals(Basf_Constant.REGISTER)) {
				policy = authConfigService.getAzure_enduser_signupPolicy();
			}
		} else {
			if(policy.equals("")) {
				policy = authConfigService.getAzure_enduser_signupPolicy();
			}
		}

		String[] id_token_parts = id_token.split("\\.");
		byte[] data = (id_token_parts[0] + "." + id_token_parts[1]).getBytes(StandardCharsets.UTF_8);
		byte[] ID_TOKEN_SIGNATURE = base64UrlDecodeToBytes(id_token_parts[2]);

		String openIdConfigUrl = getOpenIdConfigUrl(policy);

		JsonObject openIdConfig = httpCallerService.callGet(openIdConfigUrl);
		String jwks_uri = getJwks_uri(openIdConfig);
		String issuer = getIssuer(openIdConfig);

		JsonObject metaKeyObject = getMetaKeyObject(jwks_uri);
		PublicKey publicKey = getPublicKey(metaKeyObject);

		boolean isSignatureValid = verifyUsingPublicKey(data, ID_TOKEN_SIGNATURE, publicKey);
		if (isSignatureValid) {
			boolean isClaimsValid = validateClaims(id_token, nonce, issuer);
			if (isClaimsValid) {
				Gson gson = new Gson();
				jsonObjectJwt = gson.fromJson(base64UrlDecode(id_token_parts[1]), JsonObject.class);
				jsonObjectJwt.addProperty("isvalid", true);
				JsonObject payloadJson = getPayloadJson(id_token);
				String aud = payloadJson.get("aud").getAsString();
				if(aud.equalsIgnoreCase(authConfigService.getAzure_clientId())) {
					jsonObjectJwt.addProperty("request_origin", "same");
				} else {
					jsonObjectJwt.addProperty("request_origin", "different");
				}
				return jsonObjectJwt;
			} else {
				jsonObjectJwt.addProperty("isvalid", false);
				logger.error("isClaimsValid: " + isClaimsValid);
				return jsonObjectJwt;
			}
		} else {
			jsonObjectJwt.addProperty("isvalid", false);
			logger.error("isSignatureValid: " + isSignatureValid);

			return jsonObjectJwt;
		}
	}

	@Override
	public JsonObject getPayloadJson(String id_token) throws Exception {
		String[] id_token_parts = id_token.split("\\.");
		Gson gson = new Gson();
		return gson.fromJson(base64UrlDecode(id_token_parts[1]), JsonObject.class);
		
	}

	private boolean validateClaims(String id_token, String nonce, String issuer) throws Exception {

		JsonObject payloadJson = getPayloadJson(id_token);

		long exp = payloadJson.get("exp").getAsLong();
		String aud = payloadJson.get("aud").getAsString();
		String iss = payloadJson.get("iss").getAsString();

		long currentTime = System.currentTimeMillis() / 1000; // to ist convert

		if (issuer.equals(iss)) {
			if (aud.equals(authConfigService.getAzure_clientId()) && exp > currentTime) {
					return true;
			} else {
				logger.error("'aud from AEM Configiguration' is not matched with 'aud from id_token' : " + issuer);
				return true;
				
			}
		} else {
			logger.error("'issuer from openIdConfigUrl' is not matched with 'issuer from id_token' : " + issuer);
		}
		return false;
	}
	
	@Override
	public JsonObject validateThirdPartyClaims(String id_token, String nonce, String state) throws Exception {

		JsonObject responseJson = new JsonObject();
		JsonObject payloadJson = getPayloadJson(id_token);
		
		String[] id_token_parts = id_token.split("\\.");
		byte[] data = (id_token_parts[0] + "." + id_token_parts[1]).getBytes(StandardCharsets.UTF_8);
		byte[] ID_TOKEN_SIGNATURE = base64UrlDecodeToBytes(id_token_parts[2]);
		
		String policy = "";
		if (Objects.nonNull(state) && !state.isEmpty()) {
			if (state.equals(Basf_Constant.LOGIN)) {
				policy = authConfigService.getAzure_loginPolicy();
			} else if (state.equals(Basf_Constant.FORGOT_PASSWORD)) {
				policy = authConfigService.getAzure_resetPasswordPolicy();
			} else if (state.equals(Basf_Constant.PARTNER)) {
				policy = authConfigService.getAzure_partner_signupPolicy();
			}
		} else {
			policy = authConfigService.getAzure_enduser_signupPolicy();
		}

		String openIdConfigUrl = getOpenIdConfigUrl(policy);

		JsonObject openIdConfig = httpCallerService.callGet(openIdConfigUrl);
		String jwks_uri = getJwks_uri(openIdConfig);
		String issuer = getIssuer(openIdConfig);

		JsonObject metaKeyObject = getMetaKeyObject(jwks_uri);
		PublicKey publicKey = getPublicKey(metaKeyObject);

		boolean isSignatureValid = verifyUsingPublicKey(data, ID_TOKEN_SIGNATURE, publicKey);
		if (isSignatureValid) {
			long exp = payloadJson.get("exp").getAsLong();
			long iat = payloadJson.get("iat").getAsLong();
			String aud = payloadJson.get("aud").getAsString();
			String iss = payloadJson.get("iss").getAsString();

			long currentTime = System.currentTimeMillis() / 1000; // to ist convert

			if (issuer.equals(iss)) {
				
				JsonArray jsonArray = new JsonArray();
				
				JsonObject requestJson = new JsonObject();
				requestJson.addProperty("type", "get_third_party_redirect_uri");
				requestJson.addProperty("client_id", aud);
				
				JsonObject jsonObject2 = new JsonObject();
				jsonObject2.addProperty("requestJsonString", requestJson.toString());
				
				String awsEndpointUrl = authConfigService.getAwsEndpointUrl();
				responseJson = httpCallerService.callPost(jsonObject2, awsEndpointUrl);

				if (responseJson.get(Basf_Constant.ERROR_MSG).getAsString().equals(Basf_Constant.STATUS_SUCCESS)) {
					
					String responseJsonString = responseJson.get("responseJsonString").getAsString();
					Gson gson = new Gson();
					jsonArray = gson.fromJson(responseJsonString, JsonArray.class);
					responseJson.add(Basf_Constant.DATA, jsonArray);
					
					if (jsonArray.size() != 0) {
						if (/*Objects.nonNull(nonce) && nonce.equals(nonce2) &&*/ 
								exp > currentTime && currentTime > iat) {
							responseJson.addProperty(Basf_Constant.STATUS, Basf_Constant.STATUS_SUCCESS);
						} else {
							responseJson.addProperty(Basf_Constant.STATUS, Basf_Constant.STATUS_FAIL);
							responseJson.addProperty(Basf_Constant.ERROR_MSG, "token expired");
						}
					} else {
						responseJson.addProperty(Basf_Constant.STATUS, Basf_Constant.STATUS_FAIL);
						responseJson.addProperty(Basf_Constant.ERROR_MSG, "client_id not found");
					}
				}
			} else {
				responseJson.addProperty(Basf_Constant.STATUS, Basf_Constant.STATUS_FAIL);
				responseJson.addProperty(Basf_Constant.ERROR_MSG, "issuer not matched");
			}
		}  else {
			responseJson.addProperty(Basf_Constant.STATUS, Basf_Constant.STATUS_FAIL);
			responseJson.addProperty(Basf_Constant.ERROR_MSG, "signature not valid");
		}
		return responseJson;
	}

	private String getOpenIdConfigUrl(String policy) {

		return "https://" + authConfigService.getAzure_tenant() + ".b2clogin.com/" + authConfigService.getAzure_tenant()
				+ ".onmicrosoft.com/v2.0/.well-known/openid-configuration?p=" + policy;
	}

	private String getJwks_uri(JsonObject openIdConfig) throws Exception {
		return openIdConfig.get("jwks_uri").getAsString();
	}

	private String getIssuer(JsonObject openIdConfig) throws Exception{
		return openIdConfig.get("issuer").getAsString();
	}

	private JsonObject getMetaKeyObject(String jwks_uri) throws Exception {
		JsonObject jsonObject = httpCallerService.callGet(jwks_uri);
		jsonObject.get("keys").getAsJsonArray().get(0).getAsJsonObject();
		return jsonObject;
	}

	private String getModulus(JsonObject metaKeyObject) throws Exception {
		return metaKeyObject.get("keys").getAsJsonArray().get(0).getAsJsonObject().get("n").getAsString();
	}

	private String getExponent(JsonObject metaKeyObject) throws Exception {
		return metaKeyObject.get("keys").getAsJsonArray().get(0).getAsJsonObject().get("e").getAsString();
	}

	private String getAlgorithm(JsonObject metaKeyObject) throws Exception {
		return metaKeyObject.get("keys").getAsJsonArray().get(0).getAsJsonObject().get("kty").getAsString();
	}

	private PublicKey getPublicKey(JsonObject metaKeyObject) throws Exception {

		String modulus = getModulus(metaKeyObject);
		String exponent = getExponent(metaKeyObject);

		byte[] nb = base64UrlDecodeToBytes(modulus);
		byte[] eb = base64UrlDecodeToBytes(exponent);
		BigInteger n = new BigInteger(1, nb);
		BigInteger e = new BigInteger(1, eb);

		RSAPublicKeySpec rsaPublicKeySpec = new RSAPublicKeySpec(n, e);
		try {
			String algorithm = getAlgorithm(metaKeyObject);
			return KeyFactory.getInstance(algorithm).generatePublic(rsaPublicKeySpec);
			
		} catch (Exception ex) {
			throw new RuntimeException("Cant create public key", ex);
		}
	}

	private String base64UrlDecode(String input) throws Exception {
		byte[] decodedBytes = base64UrlDecodeToBytes(input);
		return new String(decodedBytes, StandardCharsets.UTF_8);
		
	}

	private byte[] base64UrlDecodeToBytes(String input) throws Exception {
		Base64 decoder = new Base64(-1, null, true);
		return  decoder.decode(input);
		
	}

	private boolean verifyUsingPublicKey(byte[] data, byte[] signature, PublicKey pubKey)
			throws GeneralSecurityException {
		Signature sig = Signature.getInstance("SHA256withRSA");
		sig.initVerify(pubKey);
		sig.update(data);
		return sig.verify(signature);
	}
}
