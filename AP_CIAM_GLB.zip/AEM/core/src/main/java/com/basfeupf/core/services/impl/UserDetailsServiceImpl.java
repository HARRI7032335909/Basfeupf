package com.basfeupf.core.services.impl;

import com.basfeupf.core.services.AuthConfigService;
import com.basfeupf.core.services.LogServise;
import com.basfeupf.core.services.UserDetailsService;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPatch;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.osgi.services.HttpClientBuilderFactory;
import org.osgi.framework.ServiceException;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

@Component(service = UserDetailsService.class)
public class UserDetailsServiceImpl implements UserDetailsService {

    @Reference
    LogServise logServise;

    @Reference
    private HttpClientBuilderFactory httpClientBuilderFactory;

    @Reference
    AuthConfigService authConfigService;


    @Override
    public JsonObject updateUser(String userId, JsonObject requestBody, String appAccessToken) {
        String updateUserBaseURL = "https://graph.microsoft.com/v1.0/users/";

        try {
            return callPost(requestBody, appAccessToken, updateUserBaseURL + userId);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new JsonObject();
    }

    public JsonObject callPost(JsonObject requestBody, String accessToken, String url) throws ServiceException, IOException {

        //HttpClient client = HttpClientBuilder.create().build();
        HttpClientBuilder builder = httpClientBuilderFactory.newBuilder();
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(authConfigService.getAzure_timeout())
                .setSocketTimeout(authConfigService.getAzure_timeout()).build();
        builder.setDefaultRequestConfig(requestConfig);
        HttpClient client = builder.build();

        HttpPatch patch = new HttpPatch(url);
        long lStartTime = System.nanoTime();

        patch.addHeader("Content-Type", "application/json");
        patch.setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + accessToken);
        patch.setEntity(new StringEntity(requestBody.toString()));
        HttpResponse httpResponse = client.execute(patch);

        int statusCode = httpResponse.getStatusLine().getStatusCode();
        long lEndTime = System.nanoTime();
        JsonObject responseJson = new JsonObject();
        if (statusCode != 200 && statusCode != 204 && statusCode != 201) {
            if (httpResponse.getStatusLine().getStatusCode() == 401) {
                BufferedReader br = new BufferedReader(new InputStreamReader((httpResponse.getEntity().getContent())));
                Gson gson = new Gson();
                JsonObject updatedResponse = gson.fromJson(br, JsonObject.class);
                logServise.log_message(url,requestBody.toString(), br.toString(), String.valueOf((lEndTime - lStartTime)/1000));
                responseJson.addProperty("status", "Failed");
                return responseJson;
                //throw new ServiceException("Authorization Failed");
            } else {
                BufferedReader br = new BufferedReader(new InputStreamReader((httpResponse.getEntity().getContent())));
                Gson gson = new Gson();
                JsonObject updatedResponse = gson.fromJson(br, JsonObject.class);
                logServise.log_message(url,requestBody.toString(), updatedResponse.toString(), String.valueOf((lEndTime - lStartTime)/1000));
                responseJson.addProperty("status", "Failed");
                return responseJson;
                //throw new ServiceException(" Failed HTTP Resonse: " + httpResponse.toString());
            }
        }

        logServise.log_message(url,requestBody.toString(), requestBody.toString(), String.valueOf((lEndTime - lStartTime)/1000));


        if(statusCode==204) {
            responseJson.addProperty("status", "Updated");
        }else{
            responseJson.addProperty("status", "Failed");
        }
        return responseJson;
    }
}
