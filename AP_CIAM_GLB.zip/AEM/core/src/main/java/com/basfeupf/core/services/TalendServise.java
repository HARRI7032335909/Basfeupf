package com.basfeupf.core.services;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.osgi.framework.ServiceException;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public interface TalendServise {

	void add_attr_value_in_response(JsonObject talendResponseJson, JsonArray app_data_array, JsonObject responseJson) throws Exception;

	JsonObject getTalendRequestJson(String requestAttribute, String requestType, String accountType,
			String businessSegment, String sub, String account_id, String contactId, JsonArray attrJsonArray)
			throws Exception;

	JsonObject callGet(String url, JsonObject headerJson) throws ClientProtocolException, IOException, ServiceException;

	JsonObject callPost(JsonObject requestBody, String url, JsonObject headerJson) throws ServiceException, IOException;

	JsonObject getRequest(String jwt_token, String state, JsonObject userDetilsjson, JsonObject payloadJson) throws Exception;

	JsonObject getRegistrationRequest(String jwt_token, String state);

	JsonObject talendAPI(String jwt_token, String state, String xApiKey, String xApiClientId, String url, JsonObject userDetilsjson) throws Exception;
	
	JsonObject talendAPIGeneric(String xApiClientId,  String xApiKey, String url,JsonObject requestJson ) throws Exception;
	
	JsonObject batchUpdate(int userUpdateLimit) throws Exception;

	String getValue(JsonObject jsonObject, String key) throws Exception;

	String getMdmValue(String[] array, String key);

}
