package com.basfeupf.core.services.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.osgi.service.component.annotations.Component;

import com.basfeupf.core.constants.Basf_Constant;
import com.basfeupf.core.services.EupfResourceHelper;

@Component(service=EupfResourceHelper.class)
public class EupfResourceHelperImpl implements EupfResourceHelper {

 	@SlingObject
	ResourceResolverFactory resourceResolverFactory;

	@Override
	public ResourceResolver getResourceResolver() throws LoginException {

		ResourceResolver resourceResolver=null;
		try{
		Map<String, Object> map = new HashMap<>();
		map.put(ResourceResolverFactory.SUBSERVICE, Basf_Constant.SUB_SERVICE_NAME);
		resourceResolver = resourceResolverFactory.getServiceResourceResolver(map);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return resourceResolver;
	}

}
