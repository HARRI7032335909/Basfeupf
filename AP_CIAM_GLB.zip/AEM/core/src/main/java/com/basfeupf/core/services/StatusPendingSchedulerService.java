package com.basfeupf.core.services;

public interface StatusPendingSchedulerService {

	int getUserUpdateLimit();

}
