package com.basfeupf.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

public interface TealiumAuthConfiguration {

    @ObjectClassDefinition(name = "BASF EUPF Tealium Configuration", description = "BASF Tealium Script Auth Configuration")
    public @interface TealiumConfig{

        @AttributeDefinition(name = "Tealium Domain", description = "Enter Tealium Domain", type = AttributeType.STRING, required = false)
        String tealium_domain() default "";
    }
}