package com.basfeupf.core.services.impl;

import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.basfeupf.core.services.LogServise;

@Component(service = LogServise.class)
public class LogServiseImpl implements LogServise {

	
	
	Logger logger = LoggerFactory.getLogger(this.getClass());

	
	
	@Override
	public void log_message(String url,String request, String response, String time) {
		try {
			logger.debug("url==>"+url +"\n\t request==>"+request+"\n\t response==>"+response+"\n\t time==>"+time+"\n\t \n\t");
		} catch(Exception e) {
			logger.error("error"+e);
		}
		
	}

}
