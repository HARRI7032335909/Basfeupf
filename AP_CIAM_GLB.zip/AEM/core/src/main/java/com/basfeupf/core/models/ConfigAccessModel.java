package com.basfeupf.core.models;

import javax.annotation.PostConstruct;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;

import com.basfeupf.core.services.AuthConfigService;

@Model(adaptables = {Resource.class, SlingHttpServletRequest.class}, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class ConfigAccessModel{
	
	@OSGiService
	AuthConfigService authConfigService;

    private String azure_extension_no;

    private String sfcc_redirect_uri;
   
    
    
    
    public String getSfcc_redirect_uri() {
		return sfcc_redirect_uri;
	}




	public void setSfcc_redirect_uri(String sfcc_redirect_uri) {
		this.sfcc_redirect_uri = sfcc_redirect_uri;
	}




	public String getAzure_extension_no() {
		return azure_extension_no;
	}




	public void setAzure_extension_no(String azure_extension_no) {
		this.azure_extension_no = authConfigService.getAzure_extension_no();
	}




	@PostConstruct
    public void activate() {
		azure_extension_no=authConfigService.getAzure_extension_no();
		sfcc_redirect_uri = authConfigService.getSFCCRedirectURI();
               
    }
}
