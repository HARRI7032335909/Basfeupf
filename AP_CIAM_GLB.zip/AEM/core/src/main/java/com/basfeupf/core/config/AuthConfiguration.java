package com.basfeupf.core.config;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

public interface AuthConfiguration {

	@ObjectClassDefinition(name = "EUPF Configuration", description = "BASF EUPF Authentication Configuration")
	public @interface AuthConfig {
		
		// Azure
		@AttributeDefinition(name = "Azure Client Id", description = "Enter Azure Client Id", type = AttributeType.STRING, required = false)
		String azure_client_id() default "";

		@AttributeDefinition(name = "Azure Tenant", description = "Enter Azure Tenant", type = AttributeType.STRING, required = false)
		String azure_tenant() default "";

		@AttributeDefinition(name = "Azure Tenant ID", description = "Enter Azure Tenant", type = AttributeType.STRING, required = false)
		String azure_tenant_id() default "";
		
		@AttributeDefinition(name = "Azure Client Secret", description = "Enter Azure Client Secret", type = AttributeType.STRING, required = false)
		String azure_client_secret() default "";

		@AttributeDefinition(name = "Azure Enduser Signup Policy", description = "Enter Azure Enduser Signup Policy", type = AttributeType.STRING, required = false)
		String azure_enduser_signup_policy() default "";

		@AttributeDefinition(name = "Azure Lite Enduser Signup Policy", description = "Enter Azure Lite Enduser Signup Policy", type = AttributeType.STRING, required = false)
		String azure_liteuser_signup_policy() default "";
		
		@AttributeDefinition(name = "Azure Partner Signup Policy", description = "Enter Azure Partner Signup Policy", type = AttributeType.STRING, required = false)
		String azure_partner_signup_policy() default "";

		@AttributeDefinition(name = "Azure Signup Redirect Uri", description = "Enter Azure Signup Redirect Uri", type = AttributeType.STRING, required = false)
		String azure_signup_Redirect_Uri() default "";

		@AttributeDefinition(name = "Azure Signup Scope", description = "Enter Azure Signup Scope", type = AttributeType.STRING, required = false)
		String azure_signup_scope() default "";

		@AttributeDefinition(name = "Azure Signup Response Type", description = "Enter Azure Signup Response Type", type = AttributeType.STRING, required = false)
		String azure_signup_response_type() default "";

		@AttributeDefinition(name = "Azure Login Policy", description = "Enter Azure Login Policy", type = AttributeType.STRING, required = false)
		String azure_login_policy() default "";

		@AttributeDefinition(name = "Azure Login Redirect Uri", description = "Enter Azure Login Redirect Uri", type = AttributeType.STRING, required = false)
		String azure_login_Redirect_Uri() default "";

		@AttributeDefinition(name = "Azure Login Scope", description = "Enter Azure Login Scope", type = AttributeType.STRING, required = false)
		String azure_login_scope() default "";

		@AttributeDefinition(name = "Azure Login Response Type", description = "Enter Azure Login Response Type", type = AttributeType.STRING, required = false)
		String azure_login_response_type() default "";

		@AttributeDefinition(name = "Azure Reset Password Policy", description = "Enter Azure Reset Password Policy", type = AttributeType.STRING, required = false)
		String azure_reset_pswd_policy() default "";

		@AttributeDefinition(name = "Azure Reset Password Redirect Uri", description = "Enter Azure Reset Password Redirect Uri", type = AttributeType.STRING, required = false)
		String azure_reset_pswd_Redirect_Uri() default "";

		@AttributeDefinition(name = "Azure Reset Password Scope", description = "Enter Azure Reset Password Scope", type = AttributeType.STRING, required = false)
		String azure_reset_pswd_scope() default "";

		@AttributeDefinition(name = "Azure Reset Password Response Type", description = "Enter Azure Reset Password Response Type", type = AttributeType.STRING, required = false)
		String azure_reset_pswd_response_type() default "";

		@AttributeDefinition(name = "Azure Logout Policy", description = "Enter Azure Logout Policy", type = AttributeType.STRING, required = false)
		String azure_logout_policy() default "";

		@AttributeDefinition(name = "Azure Logout Redirect Uri", description = "Enter Azure Logout Redirect Uri", type = AttributeType.STRING, required = false)
		String azure_logout_Redirect_Uri() default "";
		
		@AttributeDefinition(name = "Logout Redirect Uri", description = "Enter Logout Redirect Uri", type = AttributeType.STRING, required = false)
		String logout_Redirect_Uri() default "";
		
		// EUPF API
		@AttributeDefinition(name = "EUPF Endpoint URL", description = "Enter EUPF Endpoint URL", type = AttributeType.STRING, required = false)
		String eupf_endpoint_url() default "";
		
		@AttributeDefinition(name = "Azure Validate Token Selector", description = "Enter Azure Validate Token Selector", type = AttributeType.STRING, required = false)
		String azure_validate_token_selector() default "";
		
		@AttributeDefinition(name = "AWS Endpoint URL", description = "AWS Endpoint URL", type = AttributeType.STRING, required = false)
		String aws_endpoint_url() default "";

		// SMTP
		@AttributeDefinition(name = "SMTP Host", description = "Enter SMTP Host", type = AttributeType.STRING, required = false)
		String smtp_host() default "";

		@AttributeDefinition(name = "SMTP Port", description = "Enter SMTP Port", type = AttributeType.STRING, required = false)
		String smtp_port() default "";

		@AttributeDefinition(name = "SMTP Usename", description = "Enter SMTP Username", type = AttributeType.STRING, required = false)
		String smtp_usename() default "";

		@AttributeDefinition(name = "SMTP Password", description = "Enter SMTP Password", type = AttributeType.STRING, required = false)
		String smtp_pswd() default "";

		@AttributeDefinition(name = "SMTP Configset", description = "Enter SMTP Configset", type = AttributeType.STRING, required = false)
		String smtp_configset() default "";
		
		@AttributeDefinition(name = "SMTP SSL", description = "Select SMTP SSL", type = AttributeType.BOOLEAN, required = false)
		boolean smtp_ssl();

		@AttributeDefinition(name = "Sender Email", description = "Enter Sender Email", type = AttributeType.STRING, required = false)
		String sender_email() default "";

		@AttributeDefinition(name = "Email Sender Name", description = "Enter Email Sender Name", type = AttributeType.STRING, required = false)
		String sender_name() default "";

		@AttributeDefinition(name = "Email Signup Subject", description = "Enter Email Signup Subject", type = AttributeType.STRING, required = false)
		String signup_email_subject() default "";
		
		@AttributeDefinition(name = "Email Signup Body", description = "Enter Email Signup Body", type = AttributeType.STRING, required = false)
		String signup_email_body() default "";
		
		@AttributeDefinition(name = "Email Forgot Pass Subject", description = "Enter Forgot Password Signup Subject", type = AttributeType.STRING, required = false)
		String signup_forgot_pass_subject() default "";
		
		@AttributeDefinition(name = "Email Forgot Pass Body", description = "Enter Forgot Password Signup Body", type = AttributeType.STRING, required = false)
		String signup_forgot_pass_body() default "";
		
		@AttributeDefinition(name = "APIGEE-Talend Endpoint URL", description = "Enter Talend Endpoint URL", type = AttributeType.STRING, required = false)
		String eupf_talend_url() default "";
		
		@AttributeDefinition(name = "APIGEE-Captivate Endpoint URL", description = "Enter Talend Endpoint URL", type = AttributeType.STRING, required = false)
		String eupf_apigee_captivate_url() default "";
		
		@AttributeDefinition(name = "APIGEE-Talend X-API Key", description = "Enter Talend Endpoint URL", type = AttributeType.STRING, required = false)
		String eupf_apigee_talend_key() default "";

		@AttributeDefinition(name = "APIGEE-Talend X-API Client ID", description = "APIGEE-Talend X-API Client ID", type = AttributeType.STRING, required = false)
		String eupf_apigee_talend_client_id() default "";
		
		@AttributeDefinition(name = "APIGEE-Captivate X-API Key", description = "Enter APIGEE-Captivate X-API Key", type = AttributeType.STRING, required = false)
		String eupf_apigee_captivate_key() default "";
		
		@AttributeDefinition(name = "nonce value", description = "Enter nonce value", type = AttributeType.STRING, required = false)
		String nonce() default "123456";
		
		
		@AttributeDefinition(name = "code verifier", description = "Enter code verifier value", type = AttributeType.STRING, required = false)
		String codeVerifier() default "g9gfQ8VXqO7Pjl3f-FDafDHqced3XWvcGxa5QgBSB_s";
		
		@AttributeDefinition(name = "grant type", description = "Enter grant type value", type = AttributeType.STRING, required = false)
		String grant_type() default "authorization_code";
		
		@AttributeDefinition(name = "offline access", description = "Enter offline access value", type = AttributeType.STRING, required = false)
		String offline_access() default "%20offline_access";
		
		@AttributeDefinition(name = "Azure Extension Number", description = "Enter Azure Extension Number", type = AttributeType.STRING, required = false)
		String azure_extension_no() default "5414203b3cb64ca1b2ba6122a0e0ddee";
		
		@AttributeDefinition(name = "Disable Mail", description = "Disable Mail")
		boolean disable_mail() default false;
		
		@AttributeDefinition(name = "Azure Connection Timeout", description = "Azure Connection Timeout")
		int azure_timeout() default 20000;
		
		@AttributeDefinition(name = "APIGEE Connection Timeout", description = "APIGEE Connection Timeout")
		int apigee_timeout() default 20000;
		
		@AttributeDefinition(name = "AWS Connection Timeout", description = "AWS Connection Timeout")
		int aws_timeout() default 20000;
		
		@AttributeDefinition(name = "Cookie Domain Name", description = "Enter Cookie Domain Name", type = AttributeType.STRING, required = false)
		String cookie_domain_name() default ".basf.com";

		@AttributeDefinition(name = "User Group URL1", description = "Enter User Group URL", type = AttributeType.STRING, required = false)
		String user_group_url1() default "https://graph.microsoft.com/v1.0/users/";

		@AttributeDefinition(name = "User Group URL2", description = "Enter User Group URL", type = AttributeType.STRING, required = false)
		String user_group_url2() default "/memberOf?$select=id,displayName";

		@AttributeDefinition(name = "Internal User Domain", description = "Internal User Domain", type = AttributeType.STRING, required = false)
		String email() default "gmail.com,";

		@AttributeDefinition(name = "MDM Business Segment Mapping Config", description = "MDM Business Segment Mapping Config", type = AttributeType.STRING, required = false)
		String[] businessSegment() default {""};

		@AttributeDefinition(name = "AEM Business Segment Mapping Config", description = "AEM Business Segment Mapping Config", type = AttributeType.STRING, required = false)
		String[] aemBusinessSegment() default {""};

		@AttributeDefinition(name = "Account Type Mapping Config", description = "Account Type Mapping Config", type = AttributeType.STRING, required = false)
		String[] accountType() default {""};

		@AttributeDefinition(name = "SFCC US Seeds Redirect Uri", description = "Enter SFCC US Seeds Redirect Uri", type = AttributeType.STRING, required = false)
		String sfccRedirectURI() default "";
		@AttributeDefinition(name = "EUPF End Point URL", description = "Enter EUPF Endpoint URL", type = AttributeType.STRING, required = false)
		String eupf_talend_url_v1() default "";
	}
}