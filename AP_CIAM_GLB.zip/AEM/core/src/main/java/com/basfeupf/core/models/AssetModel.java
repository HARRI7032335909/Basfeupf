package com.basfeupf.core.models;

import org.apache.sling.api.resource.ValueMap;

public class AssetModel {

    private String name;
    private String title;
    private String description;
    private String programStartDate;
    private String programEndDate;
    private String size;
    private String format;
    private String shaId;
    private String thumbnailType;
    private String thumbnailBase64;
    private String assetPath;
    private String displayOrder;

    public AssetModel() {};

    public AssetModel(final ValueMap properties){
        if (properties != null){
            this.title = getStringProperty(properties, "dc:title");
            this.description = getStringProperty(properties, "dc:description");
        }
    }

    private String getStringProperty(ValueMap properties, String propertyName){
        if (properties.get(propertyName) == null) {
            return "";
        }
        return properties.get(propertyName).toString();
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProgramStartDate() {
        return programStartDate;
    }

    public void setProgramStartDate(String programStartDate) {
        this.programStartDate = programStartDate;
    }

    public String getProgramEndDate() {
        return programEndDate;
    }

    public void setProgramEndDate(String programEndDate) {
        this.programEndDate = programEndDate;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getShaId() {
        return shaId;
    }

    public void setShaId(String shaId) {
        this.shaId = shaId;
    }

    public String getThumbnailType() {
        return thumbnailType;
    }

    public void setThumbnailType(String thumbnailType) {
        this.thumbnailType = thumbnailType;
    }

    public String getThumbnailBase64() {
        return thumbnailBase64;
    }

    public void setThumbnailBase64(String thumbnailBase64) {
        this.thumbnailBase64 = thumbnailBase64;
    }

    public String getAssetPath() {
        return assetPath;
    }

    public void setAssetPath(String assetPath) {
        this.assetPath = assetPath;
    }

    public String getDisplayOrder() {
        return displayOrder;
    }

    public void setDisplayOrder(String displayOrder) {
        this.displayOrder = displayOrder;
    }
}
