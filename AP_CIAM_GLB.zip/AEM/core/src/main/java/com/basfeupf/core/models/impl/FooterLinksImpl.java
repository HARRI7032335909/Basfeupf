package com.basfeupf.core.models.impl;


import com.basfeupf.core.models.FooterLinks;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import java.util.*;

@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = FooterLinks.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class FooterLinksImpl implements FooterLinks {
    private static final Logger LOG = LoggerFactory.getLogger(FooterLinksImpl.class);

    @Inject
    Resource componentResource;

    @ValueMapValue
    private String titleText;
    @ValueMapValue
    private String subTitleText;
    @ValueMapValue
    private String fileReference;
    @ValueMapValue
    private String copyright;


    @Override
    public String getTitleText() {
        return titleText;
    }
    @Override
    public String getSubTitleText() { return subTitleText; }
    @Override
    public String getFileReference() { return fileReference; }
    @Override
    public String getCopyright() { return copyright; }

    @Override
    public List<Map<String,String>> getLinkList_column1(){
        List<Map<String, String>> column1Map=new ArrayList<>();
        try {
            Resource linkDetail1=componentResource.getChild("linkList_column1");
            if(Objects.nonNull(linkDetail1)){
                for (Resource link : linkDetail1.getChildren()) {
                    Map<String,String> linkMap1=new HashMap<>();
                    linkMap1.put("label",link.getValueMap().get("label",String.class));
                    linkMap1.put("link",link.getValueMap().get("link",String.class));
                    linkMap1.put("segment",link.getValueMap().get("segment",String.class));
                    column1Map.add(linkMap1);
                }
            }
        }catch (Exception e){
            LOG.error("\n ERROR while getting Link Details {} ",e.getMessage());
        }
        return column1Map;
    }

    @Override
    public List<Map<String, String>> getLinkList_column2() {
        List<Map<String, String>> column2Map=new ArrayList<>();
        try {
            Resource linkDetail2=componentResource.getChild("linkList_column2");
            if(Objects.nonNull(linkDetail2)){
                for (Resource link : linkDetail2.getChildren()) {
                    Map<String,String> linkMap2=new HashMap<>();
                    linkMap2.put("label",link.getValueMap().get("label",String.class));
                    linkMap2.put("link",link.getValueMap().get("link",String.class));
                    linkMap2.put("segment",link.getValueMap().get("segment",String.class));
                    column2Map.add(linkMap2);
                }
            }
        }catch (Exception e){
            LOG.error("\n ERROR while getting Link Details {} ",e.getMessage());
        }
        return column2Map;
    }

    @Override
    public List<Map<String,String>> getLinkList_column3(){
        List<Map<String, String>> column3Map=new ArrayList<>();
        try {
            Resource linkDetail3=componentResource.getChild("linkList_column3");
            if(Objects.nonNull(linkDetail3)){
                for (Resource link : linkDetail3.getChildren()) {
                    Map<String,String> linkMap3=new HashMap<>();
                    linkMap3.put("label",link.getValueMap().get("label",String.class));
                    linkMap3.put("link",link.getValueMap().get("link",String.class));
                    linkMap3.put("segment",link.getValueMap().get("segment",String.class));
                    column3Map.add(linkMap3);
                }
            }
        }catch (Exception e){
            LOG.error("\n ERROR while getting Link Details {} ",e.getMessage());
        }
        return column3Map;
    }

    @Override
    public List<Map<String,String>> getLinkList_column4(){
        List<Map<String, String>> column4Map=new ArrayList<>();
        try {
            Resource linkDetail4=componentResource.getChild("linkList_column4");
            if(Objects.nonNull(linkDetail4)){
                for (Resource link : linkDetail4.getChildren()) {
                    Map<String,String> linkMap4=new HashMap<>();
                    linkMap4.put("label",link.getValueMap().get("label",String.class));
                    linkMap4.put("link",link.getValueMap().get("link",String.class));
                    linkMap4.put("segment",link.getValueMap().get("segment",String.class));
                    column4Map.add(linkMap4);
                }
            }
        }catch (Exception e){
            LOG.error("\n ERROR while getting Footer Link Details {} ",e.getMessage());
        }
        return column4Map;
    }

    @Override
    public List<Map<String,String>> getLinkList_column5(){
        List<Map<String, String>> column5Map=new ArrayList<>();
        try {
            Resource linkDetail5=componentResource.getChild("linkList_column5");
            if(Objects.nonNull(linkDetail5)){
                for (Resource link : linkDetail5.getChildren()) {
                    Map<String,String> linkMap5=new HashMap<>();
                    linkMap5.put("label",link.getValueMap().get("label",String.class));
                    linkMap5.put("link",link.getValueMap().get("link",String.class));
                    linkMap5.put("segment",link.getValueMap().get("segment",String.class));
                    column5Map.add(linkMap5);
                }
            }
        }catch (Exception e){
            LOG.error("\n ERROR while getting Footer Link Details {} ",e.getMessage());
        }
        return column5Map;
    }
}
