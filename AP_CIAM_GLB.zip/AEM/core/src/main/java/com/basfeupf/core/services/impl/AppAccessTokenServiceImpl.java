package com.basfeupf.core.services.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.osgi.services.HttpClientBuilderFactory;
import org.osgi.framework.ServiceException;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.basfeupf.core.services.AppAccessTokenService;
import com.basfeupf.core.services.AuthConfigService;
import com.basfeupf.core.services.HttpCallerService;
import com.basfeupf.core.services.LogServise;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@Component(service=AppAccessTokenService.class)
public class AppAccessTokenServiceImpl implements AppAccessTokenService {

	@Reference
	HttpCallerService httpCallerService;

	@Reference
	AuthConfigService authConfigService;
	
	@Reference
	LogServise logServise;
	
	@Reference
	private HttpClientBuilderFactory httpClientBuilderFactory;

	
	Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public JsonObject getAppAccessToken(JsonObject requestObject) {

		String azure_tenant_id = authConfigService.getAzure_tenant_id();
		String accessTokenURL = "https://login.microsoftonline.com/"+azure_tenant_id+"/oauth2/v2.0/token";

		String urlparams = "grant_type="+requestObject.get("grant_type").getAsString()+"&"+
				 		   "client_id="+authConfigService.getAzure_clientId()+"&"+
						   "client_secret="+authConfigService.getAzure_client_secret()+"&"+
						   "scope="+requestObject.get("scope").getAsString();
		try {
			return callPost(urlparams, accessTokenURL);

		} catch (IOException e) {
			e.printStackTrace();
		}

		return new JsonObject();
	}

	public JsonObject callPost(String urlparams, String url) throws ServiceException, IOException {

		//HttpClient client = HttpClientBuilder.create().build();
		HttpClientBuilder builder = httpClientBuilderFactory.newBuilder();
		RequestConfig requestConfig = RequestConfig.custom()
				.setConnectTimeout(authConfigService.getAzure_timeout())
				.setSocketTimeout(authConfigService.getAzure_timeout()).build();
		builder.setDefaultRequestConfig(requestConfig);
		HttpClient client = builder.build();


		HttpPost post = new HttpPost(url);
		long lStartTime = System.nanoTime();
		
		post.addHeader("Content-Type", "application/x-www-form-urlencoded");
		post.setEntity(new StringEntity(urlparams));
		HttpResponse httpResponse = client.execute(post);

		int statusCode = httpResponse.getStatusLine().getStatusCode();

		if (statusCode != 200 && statusCode != 201) {
			if (httpResponse.getStatusLine().getStatusCode() == 401) {
				throw new ServiceException("Authorization Failed");
			} else {
				throw new ServiceException(" Failed HTTP Resonse: " + httpResponse.toString());
			}
		}

		BufferedReader br = new BufferedReader(new InputStreamReader((httpResponse.getEntity().getContent())));
		Gson gson = new Gson();
		JsonObject updatedResponse = gson.fromJson(br, JsonObject.class);
		
		long lEndTime = System.nanoTime();
		logServise.log_message(url,urlparams, updatedResponse.toString(), String.valueOf((lEndTime - lStartTime)/1000));
		
		return updatedResponse;
	}
	
	
}
