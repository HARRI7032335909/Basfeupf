package com.basfeupf.core.services;

import org.apache.sling.api.SlingHttpServletRequest;

import com.google.gson.JsonObject;

public interface AzureAuthServiceNew {

	JsonObject isValidToken(SlingHttpServletRequest request)
			throws Exception;

	JsonObject getPayloadJson(String id_token) throws Exception;

	JsonObject isValidToken(JsonObject jsonObject) throws Exception;

	JsonObject validateThirdPartyClaims(String id_token, String nonce, String state) throws Exception;

}
