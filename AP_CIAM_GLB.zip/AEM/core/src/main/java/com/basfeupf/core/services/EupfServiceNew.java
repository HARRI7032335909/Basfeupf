package com.basfeupf.core.services;

import java.io.IOException;

import javax.mail.internet.MimeBodyPart;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.osgi.framework.ServiceException;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public interface EupfServiceNew {

	JsonObject testLambda(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

	JsonObject getAzureToken(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

	boolean sendEmail(String senderEmail, String senderName, String toEmail, String subject, String body,
			MimeBodyPart pdfBodyPart) throws Exception;

	JsonObject callSignUpEmail(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

	JsonObject insertIntoUserDetils(JsonObject payloadJson) throws ServiceException, IOException;

	JsonObject updateLeadId(JsonObject jsonObject) throws ServiceException, IOException;

	JsonObject getTokenJson(SlingHttpServletRequest request) throws Exception;

	JsonObject callAwsRestService(JsonObject requestJson) throws Exception;

	JsonObject getTalendRequestJson(JsonObject requestJson, JsonArray app_data_array, JsonArray userIdArray)
			throws Exception;
	
	public JsonObject updateAdobeuuid(String sub, String adobeuuid) throws ServiceException, IOException;

	

}
