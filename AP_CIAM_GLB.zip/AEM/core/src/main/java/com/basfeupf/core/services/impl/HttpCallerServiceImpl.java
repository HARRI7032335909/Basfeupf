package com.basfeupf.core.services.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.osgi.services.HttpClientBuilderFactory;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.osgi.framework.ServiceException;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.basfeupf.core.services.AuthConfigService;
import com.basfeupf.core.services.HttpCallerService;
import com.basfeupf.core.services.LogServise;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

@Component(service = HttpCallerService.class)
public class HttpCallerServiceImpl implements HttpCallerService {
	
//	@Reference
//	TalendServise talendServise;
	
	@Reference
	LogServise logServise;
	
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Reference
	private HttpClientBuilderFactory httpClientBuilderFactory;
	
	@Reference
	AuthConfigService authConfigService;

	@Override
	public JsonObject createRequest(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws IOException {
		String body = request.getReader().lines().collect(Collectors.joining());
		Gson gson = new Gson();
		JsonObject bodyJsonObj = gson.fromJson(body, JsonObject.class);
//		JsonObject bodyJson = Objects.nonNull(bodyJsonObj) && bodyJsonObj.has("data")
//				? bodyJsonObj.get("data").getAsJsonObject()
//				: new JsonObject();
		return bodyJsonObj;
	}

	@Override
	public JsonObject callGet(String url) throws ClientProtocolException, IOException, ServiceException {

	//	HttpClient client = HttpClientBuilder.create().build();
		HttpClientBuilder builder = httpClientBuilderFactory.newBuilder();
		RequestConfig requestConfig = RequestConfig.custom()
				.setConnectTimeout(authConfigService.getAws_timeout())
				.setSocketTimeout(authConfigService.getAws_timeout()).build();
		builder.setDefaultRequestConfig(requestConfig);
		HttpClient client = builder.build();
		HttpGet get = new HttpGet(url);
		HttpResponse httpResponse = client.execute(get);
		
		long lStartTime = System.nanoTime();

		int statusCode = httpResponse.getStatusLine().getStatusCode();

		if (statusCode != 200 && statusCode != 201) {
			if (httpResponse.getStatusLine().getStatusCode() == 401) {
				throw new ServiceException("Authorization Failed");
			} else {

				BufferedReader br = new BufferedReader(new InputStreamReader((httpResponse.getEntity().getContent())));

				long lEndTime = System.nanoTime();
				logServise.log_message(url,"", br.toString(), String.valueOf((lEndTime - lStartTime)/1000)+statusCode);

				throw new ServiceException(" Failed HTTP Resonse: " + httpResponse.toString());


			}
		}

		BufferedReader br = new BufferedReader(new InputStreamReader((httpResponse.getEntity().getContent())));
		Gson gson = new Gson();
		JsonObject updatedResponse = gson.fromJson(br, JsonObject.class);
		
		long lEndTime = System.nanoTime();
		logServise.log_message(url,"", updatedResponse.toString(), String.valueOf((lEndTime - lStartTime)/1000));
		
		return updatedResponse;
	}

	@Override
	public JsonObject callPost(JsonObject requestBody, String url) throws ServiceException, IOException {

		//HttpClient client = HttpClientBuilder.create().build();
		
		HttpClientBuilder builder = httpClientBuilderFactory.newBuilder();
		RequestConfig requestConfig = RequestConfig.custom()
				.setConnectTimeout(authConfigService.getAws_timeout())
				.setSocketTimeout(authConfigService.getAws_timeout()).build();
		builder.setDefaultRequestConfig(requestConfig);
		HttpClient client = builder.build();
		
		HttpPost post = new HttpPost(url);
		long lStartTime = System.nanoTime();
		post.addHeader("Content-Type", "application/json");
		post.setEntity(new StringEntity(requestBody.toString()));
		HttpResponse httpResponse = client.execute(post);

		int statusCode = httpResponse.getStatusLine().getStatusCode();

		if (statusCode != 200 && statusCode != 201) {
			if (httpResponse.getStatusLine().getStatusCode() == 401) {
				throw new ServiceException("Authorization Failed");
			} else {
				throw new ServiceException(" Failed HTTP Resonse: " + httpResponse.toString());
			}
		}

		BufferedReader br = new BufferedReader(new InputStreamReader((httpResponse.getEntity().getContent())));
		Gson gson = new Gson();
		JsonObject updatedResponse = gson.fromJson(br, JsonObject.class);
		
		long lEndTime = System.nanoTime();
		logServise.log_message(url,requestBody.toString(), updatedResponse.toString(), String.valueOf((lEndTime - lStartTime)/1000));
		
		return updatedResponse;
	}
	
	

}
