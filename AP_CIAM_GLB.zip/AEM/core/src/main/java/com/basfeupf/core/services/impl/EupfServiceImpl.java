
package com.basfeupf.core.services.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.Objects;
import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.http.Cookie;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.osgi.services.HttpClientBuilderFactory;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.osgi.framework.ServiceException;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.basfeupf.core.constants.Basf_Constant;
import com.basfeupf.core.services.AuthConfigService;
import com.basfeupf.core.services.AzureAuthService;
import com.basfeupf.core.services.EupfService;
import com.basfeupf.core.services.HttpCallerService;
import com.basfeupf.core.services.LogServise;
import com.basfeupf.core.services.PkceService;
import com.basfeupf.core.services.TalendServise;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

@Component(service = EupfService.class)
public class EupfServiceImpl implements EupfService {

	@Reference
	AzureAuthService azureAuthService;

	@Reference
	HttpCallerService httpCallerService;

	@Reference
	AuthConfigService authConfigService;

	@Reference
	PkceService pkceService;
	
	@Reference
	LogServise logServise;
	
	@Reference
	private HttpClientBuilderFactory httpClientBuilderFactory;

	Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public JsonObject testLambda(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception {

		JsonObject requestBody = httpCallerService.createRequest(request, response);

		String jwt_token = requestBody.get("jwt_token").getAsString();
		JsonObject payloadJson = azureAuthService.getPayloadJson(jwt_token);
		String email = null;

		if (payloadJson.has("emails")) {
			email = payloadJson.get("emails").getAsJsonArray().get(0).getAsString();
		} else if (payloadJson.has("signInNames.emailAddress")) {
			email = payloadJson.get("signInNames.emailAddress").getAsString();
		}

		requestBody.addProperty("email", email);
		JsonObject requestJson = new JsonObject();
		requestJson.addProperty("requestJsonString", requestBody.toString());

		String url = "https://d8wcglfj27.execute-api.us-east-1.amazonaws.com/For-EUPF-API-Dev-Lambda/for-eupf-api-dev";

		JsonObject responseJson = httpCallerService.callPost(requestJson, url);

		if (responseJson.has("errormsg")) {
			String errormsg = responseJson.get("errormsg").getAsString();
			if (!errormsg.toLowerCase().contains("error") && !errormsg.toLowerCase().contains("exception")) {
				return responseJson;
			}
		}
		return null;
	}

	@Override
	public JsonObject getAzureToken(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws Exception {

		String code = request.getParameter("code");
		String state = request.getParameter("state");

//		String codeVerifier = pkceService.generateCodeVerifier();
		String codeVerifier = "g9gfQ8VXqO7Pjl3f-FDafDHqced3XWvcGxa5QgBSB_s";
//		String codeChallenge = pkceService.generateCodeChallange(codeVerifier);
		String grant_type = "authorization_code";
		String client_id = authConfigService.getAzure_clientId();
		String scope = client_id + "%20offline_access";
//		String response_mode = "query";
		String redirect_uri = "https://jwt.ms/";
		String client_secret = authConfigService.getAzure_client_secret();

		String policy = "";
		if (Objects.nonNull(state) && !state.isEmpty()) {
			if (state.equals(Basf_Constant.LOGIN)) {
				policy = authConfigService.getAzure_loginPolicy();
			} else if (state.equals(Basf_Constant.FORGOT_PASSWORD)) {
				policy = authConfigService.getAzure_resetPasswordPolicy();
			} else if (state.equals(Basf_Constant.PARTNER)) {
				policy = authConfigService.getAzure_partner_signupPolicy();
			} else if (state.equals(Basf_Constant.REGISTER)) {
				policy = authConfigService.getAzure_enduser_signupPolicy();
			}
		} else {
			policy = authConfigService.getAzure_enduser_signupPolicy();
		}

		String url = "https://" + authConfigService.getAzure_tenant() + ".b2clogin.com/"
				+ authConfigService.getAzure_tenant() + ".onmicrosoft.com/" + policy + "/oauth2/v2.0/token";

		long lStartTime = System.nanoTime();

		//HttpClient client = HttpClientBuilder.create().build();
		
		HttpClientBuilder builder = httpClientBuilderFactory.newBuilder();
		RequestConfig requestConfig = RequestConfig.custom()
				.setConnectTimeout(authConfigService.getAzure_timeout())
				.setSocketTimeout(authConfigService.getAzure_timeout()).build();
		builder.setDefaultRequestConfig(requestConfig);
		HttpClient client = builder.build();
		
		HttpPost post = new HttpPost(url);
		post.addHeader("Content-Type", "application/x-www-form-urlencoded");
		String body = "grant_type=" + grant_type + "&client_id=" + client_id + "&scope=" + scope + "&code=" + code
				+ "&redirect_uri=" + redirect_uri + "&code_verifier=" + codeVerifier + "&client_secret="
				+ client_secret;

		post.setEntity(new StringEntity(body));

		HttpResponse httpResponse = client.execute(post);

		int statusCode = httpResponse.getStatusLine().getStatusCode();

		if (statusCode != 200 && statusCode != 201) {
			if (statusCode == 400) {
//				throw new ServiceException("Authorization Failed");
			} else if (statusCode == 401) {
				throw new ServiceException("Authorization Failed");
			} else {
				throw new ServiceException(" Failed HTTP Resonse: " + httpResponse.toString());
			}
		}

		BufferedReader br = new BufferedReader(new InputStreamReader((httpResponse.getEntity().getContent())));
		Gson gson = new Gson();
		JsonObject updatedResponse = gson.fromJson(br, JsonObject.class);
		long lEndTime = System.nanoTime();
		logServise.log_message(url,body.toString(), updatedResponse.toString(), String.valueOf((lEndTime - lStartTime)/1000));
		return updatedResponse;

	}

	@Override
	public JsonObject insertIntoUserDetils(JsonObject payloadJson) throws ServiceException, IOException {

		payloadJson.addProperty("type", "insert_user_details");
		JsonObject requestJson = new JsonObject();
		requestJson.addProperty("requestJsonString", payloadJson.toString());
		String awsEndpointUrl = authConfigService.getAwsEndpointUrl();
		JsonObject responseJson = httpCallerService.callPost(requestJson, awsEndpointUrl);
		return responseJson;
	}

	@Override
	public JsonObject callSignUpEmail(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws Exception {

		JsonObject requestBody = httpCallerService.createRequest(request, response);
		JsonObject jsonObject = new JsonObject();

		String senderEmail = null;
		String senderName = null;
		String toEmail = requestBody.get("to_email").getAsString();
		String subject = null;
		MimeBodyPart pdfBodyPart = null;
		String firstName = requestBody.get("firstName").getAsString();
		String lastName = requestBody.get("lastName").getAsString();
		String body = authConfigService.getSignupEmailBody();

		body = body.replace("First Name Last Name", firstName + " " + lastName);

		boolean status = sendEmail(senderEmail, senderName, toEmail, subject, body, pdfBodyPart);
		if (status) {
			jsonObject.addProperty("status", "mail sent");
		} else {
			jsonObject.addProperty("status", "mail not sent");
		}

		return jsonObject;
	}

	@Override
	public boolean sendEmail(String senderEmail, String senderName, String toEmail, String subject, String body,
			MimeBodyPart pdfBodyPart) throws Exception {

		boolean status = false;
		if (Objects.isNull(senderEmail)) {
			senderEmail = authConfigService.getSenderEmail();
		}

		if (Objects.isNull(senderName)) {
			senderName = authConfigService.getSenderName();
		}

		Properties props = System.getProperties();
		if (authConfigService.isSmtpSSl()) {
			props.put("mail.transport.protocol", "smtps");
		} else {
			props.put("mail.transport.protocol", "smtp");
		}
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", authConfigService.getSmtpPort());
		props.put("mail.smtp.starttls.enable", "true");

		Session session = Session.getDefaultInstance(props);

		MimeMessage message = new MimeMessage(session);
		message.setRecipient(Message.RecipientType.TO, new InternetAddress(toEmail));
		message.setSubject(subject, "UTF-8");
		message.setSentDate(new Date());
//			message.setText(body, "UTF-8");
//			message.setContent(body, "text/html");
		if (!authConfigService.getSmtpConfigset().isEmpty()) {
			message.setHeader("X-SES-CONFIGURATION-SET", authConfigService.getSmtpConfigset());
		}

		message.addHeader("Content-type", "text/HTML; charset=UTF-8");
		message.addHeader("Content-Transfer-Encoding", "8bit");

		message.setFrom(new InternetAddress(senderEmail, senderName));

		Multipart multipart = new MimeMultipart();
		BodyPart messageBodyPart = new MimeBodyPart();
		messageBodyPart.setContent(body, "text/html");
		multipart.addBodyPart(messageBodyPart);

		if (Objects.nonNull(pdfBodyPart)) {
			multipart.addBodyPart(pdfBodyPart);
		}

		message.setContent(multipart);
//			msg.setReplyTo(InternetAddress.parse("no_reply@example.com", false));

		Transport transport = session.getTransport();

		transport.connect(authConfigService.getSmtpHost(), authConfigService.getSmtpUsername(),
				authConfigService.getSmtpPassword());
		transport.sendMessage(message, message.getAllRecipients());
		transport.close();
		status = true;
		return status;

	}

	@Override
	public JsonObject getTokenJson(SlingHttpServletRequest request) throws Exception {

		JsonObject tokenJson = new JsonObject();
		Cookie[] cookies = request.getCookies();

		if (Objects.nonNull(cookies)) {
			for (Cookie cookie : cookies) {
				String cookieName = cookie.getName();
				String cookieValue = cookie.getValue();

				if (cookieName.equals("access_token") || cookieName.equals("id_token")
						|| cookieName.equals("token_type") || cookieName.equals("not_before")
						|| cookieName.equals("expires_in") || cookieName.equals("expires_on")
						|| cookieName.equals("resource") || cookieName.equals("resource")
						|| cookieName.equals("id_token_expires_in") || cookieName.equals("profile_info")
						|| cookieName.equals("refresh_token") || cookieName.equals("refresh_token_expires_in")
						|| cookieName.equals("nonce")) {

					tokenJson.addProperty(cookieName, cookieValue);
				}
			}
		}
		return tokenJson;
	}

	@Override
	public JsonObject callAwsRestService(JsonObject requestJson) throws Exception {

		JsonArray jsonArray = new JsonArray();

		JsonObject jsonObject2 = new JsonObject();
		jsonObject2.addProperty("requestJsonString", requestJson.toString());

		String awsEndpointUrl = authConfigService.getAwsEndpointUrl();
		JsonObject responseJson = httpCallerService.callPost(jsonObject2, awsEndpointUrl);

		if (responseJson.get(Basf_Constant.ERROR_MSG).getAsString().equals(Basf_Constant.STATUS_SUCCESS)) {
			String responseJsonString = responseJson.get("responseJsonString").getAsString();
			Gson gson = new Gson();
			try {
			jsonArray = gson.fromJson(responseJsonString, JsonArray.class);
			} catch(Exception e) {
				
			}
			responseJson.addProperty(Basf_Constant.STATUS, Basf_Constant.STATUS_SUCCESS);
		} else {
			responseJson.addProperty(Basf_Constant.STATUS, Basf_Constant.STATUS_FAIL);
		}
		responseJson.add(Basf_Constant.DATA, jsonArray);
		return responseJson;
	}

	@Override
	public JsonObject getTalendRequestJson(JsonObject requestJson, JsonArray app_data_array, JsonArray userIdArray)
			throws Exception {
		
		// for talendRequestJson

		String contactId = "";
		String account_id = "";

		for (JsonElement userElement : userIdArray) {
			JsonObject userJson = userElement.getAsJsonObject();
			if (userJson.has("contactId")) {
				contactId = userJson.get("contactId").getAsString();
			}
			if (userJson.has("account_id")) {
				account_id = userJson.get("account_id").getAsString();
			}
			break;
		}

		JsonArray talendRequestAttrArray = new JsonArray();

		for (JsonElement jsonElement : app_data_array) {
			JsonObject jsonObject = jsonElement.getAsJsonObject();
			String attrib_map_id = jsonObject.has("attrib_map_id")
					? jsonObject.get("attrib_map_id").getAsString()
					: "";

			JsonObject attrJson = new JsonObject();
			attrJson.addProperty("attr_key", attrib_map_id);
			attrJson.addProperty("attr_value", "");
			talendRequestAttrArray.add(attrJson);
		}

		String requestAttribute = requestJson.get("request_attribute").getAsString();
		String requestType = requestJson.get("request_type").getAsString();
		String accountType = requestJson.get("account_type").getAsString();
		String businessSegment = requestJson.get("segment_id").getAsString();
		String eupf_id = requestJson.get("sub").getAsString();

		JsonObject talendRequestJson = new JsonObject();
		talendRequestJson.addProperty("eupf_id", eupf_id);
		talendRequestJson.addProperty("request_attribute", requestAttribute);
		talendRequestJson.addProperty("request_type", requestType);
		talendRequestJson.addProperty("account_type", accountType);
		talendRequestJson.addProperty("business_tegment", businessSegment);
		talendRequestJson.addProperty("account_basf_id", account_id);
		talendRequestJson.addProperty("contactId", contactId);
		talendRequestJson.add("attributes", talendRequestAttrArray);

		return talendRequestJson;
	}
	
	

}
