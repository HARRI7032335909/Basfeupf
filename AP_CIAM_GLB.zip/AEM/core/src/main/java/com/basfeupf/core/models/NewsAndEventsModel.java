
package com.basfeupf.core.models;

import com.basfeupf.core.constants.Basf_Constant;
import com.basfeupf.core.services.AuthConfigService;
import com.basfeupf.core.services.EupfResourceHelper;
import com.day.cq.wcm.api.Page;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.RequestAttribute;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.osgi.service.component.annotations.Reference;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Model(adaptables = {Resource.class, SlingHttpServletRequest.class}, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class NewsAndEventsModel {

    @RequestAttribute
    private String pageType;
	
	@ValueMapValue
    private boolean hide;
    
    @Reference
    EupfResourceHelper eupfResourceHelper;

    private List list = new ArrayList();

    private JsonArray eventsArray = new JsonArray();

    @SlingObject
    private SlingHttpServletRequest request;
    
    @ScriptVariable
    private Page currentPage;
    
	@Inject
	AuthConfigService authConfigService;

    @PostConstruct
    protected void init() {
    }

    public List getList() {

       // String pagePath = "/content/basfeupf/us/en";
    	String queryString = "SELECT  child.* FROM [cq:Page] as parent INNER JOIN [cq:PageContent] AS child ON ISCHILDNODE(child,parent) WHERE ISDESCENDANTNODE(parent,'"+ getSiteRootPath() +"') and child.[cq:template] = '/conf/basfeupf/settings/wcm/templates/"+pageType+"-template' and child.[show]='true' order by child.[eventdate] asc";

       
        Query query = null;
        try {
        	 ResourceResolver resourceResolver = request.getResourceResolver();
             Session session = resourceResolver.adaptTo(Session.class);
            QueryManager queryManager = session.getWorkspace().getQueryManager();
            query = queryManager.createQuery(queryString, Query.JCR_SQL2);
            QueryResult queryResult = query.execute();
            NodeIterator nodes = queryResult.getNodes();

            while (nodes.hasNext()){
                Node node = nodes.nextNode();
                JsonObject pageJson = new JsonObject();

                if(node.hasProperty("title"))
                    pageJson.addProperty("name", node.getProperty("title").getString());
                if(node.hasProperty("description"))
                    pageJson.addProperty("description", node.getProperty("description").getString());
                if(node.hasProperty("eventdate")) {
                    String eventDate = parseToEventDateFormat(node.getProperty("eventdate").getString().split("\\+")[0] + 'Z');
                    pageJson.addProperty("date", eventDate);
                }
                if(node.hasProperty("redirectLink"))
                    pageJson.addProperty("redirectLink", node.getProperty("redirectLink").getString());
                if(node.hasProperty("imagelink"))
                    pageJson.addProperty("imagelink", node.getProperty("imagelink").getString());
                if(node.hasProperty("buttonLabel1"))
                    pageJson.addProperty("buttonLabel1", node.getProperty("buttonLabel1").getString());
                if(node.hasProperty("buttonLink1"))
                    pageJson.addProperty("buttonLink1", node.getProperty("buttonLink1").getString());
                if(node.hasProperty("buttonLabel2"))
                    pageJson.addProperty("buttonLabel2", node.getProperty("buttonLabel2").getString());
                if(node.hasProperty("buttonLink2"))
                    pageJson.addProperty("buttonLink2", node.getProperty("buttonLink2").getString());
                if(node.hasProperty("lms")){
                    pageJson.addProperty("lms", node.getProperty("lms").getString());
                }else{
                    pageJson.addProperty("lms", "false");
                }
                if(node.getParent().getParent().getParent().getNode("jcr:content").hasProperty("segmentid"))
                    pageJson.addProperty("segmentid", node.getParent().getParent().getParent().getNode("jcr:content").getProperty("segmentid").getString());
                eventsArray.add(pageJson);
            }
            return convertJsonArrayToListOfMap(eventsArray);
        } catch (RepositoryException e) {
            e.printStackTrace();
        } 
        return new ArrayList();
    }

    private List<Map<String,String>> convertJsonArrayToListOfMap(final JsonArray jsonArray){
        if(Objects.nonNull(jsonArray)){
            return new Gson().fromJson(jsonArray,new TypeToken<List<Map<String,String>>>(){}.getType());
        }
        return Collections.emptyList();
    }

    private String parseToEventDateFormat(String datestring){
    	if(datestring.length()>24) {
    		datestring=datestring.substring(0,23)+"Z";
    	}
        String targetFormat = "MMM dd, YYYY hh:mma";
        String currentFormat = "yyyy-MM-dd'T'hh:mm:ss.SSS'Z'";

        String timezone = "EST";
        DateFormat srcDf = new SimpleDateFormat(currentFormat);
        srcDf.setTimeZone(TimeZone.getTimeZone(timezone));
        DateFormat destDf = new SimpleDateFormat(targetFormat);
        try {
            Date date = srcDf.parse(datestring);
            String targetDate = destDf.format(date);
            return targetDate;
        } catch (ParseException ex) {
            ex.printStackTrace();
        }
        return new Date().toString();
    }

    private String getSiteRootPath() {
		if (Objects.nonNull(currentPage) && StringUtils.startsWith(currentPage.getPath(), "/content")) {
			String pagePath = currentPage.getPath();
			return pagePath.substring(0, StringUtils.ordinalIndexOf(pagePath, "/", 5));
		}
		return Basf_Constant.PAGE_PATH;
	}
    
    public String getSFCCRedirectURI() {
		if (Objects.nonNull(authConfigService) && StringUtils.isNotBlank(authConfigService.getSFCCRedirectURI())) {
			return authConfigService.getSFCCRedirectURI();
		}
		return StringUtils.EMPTY;
	}
	public boolean getHide() {
        return hide;
    }
}
