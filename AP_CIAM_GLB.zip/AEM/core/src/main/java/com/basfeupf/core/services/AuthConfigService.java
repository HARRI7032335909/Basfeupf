package com.basfeupf.core.services;

public interface AuthConfigService {

	// Azure
	String getAzure_clientId();

	String getAzure_tenant();

	String getAzure_tenant_id();
	
	String getAzure_client_secret();

	String getAzure_enduser_signupPolicy();

	String getAzure_liteuser_signupPolicy();
	
	String getAzure_partner_signupPolicy();

	String getAzure_signupRedirectUri();

	String getAzure_signupScope();

	String getAzure_signupResponseType();

	String getAzure_loginPolicy();

	String getAzure_loginRedirectUri();

	String getAzure_loginScope();

	String getAzure_loginResponseType();

	String getAzure_resetPasswordPolicy();

	String getAzure_resetPasswordRedirectUri();

	String getAzure_resetPasswordScope();

	String getAzure_resetPasswordResponseType();

	String getAzure_logoutPolicy();

	String getAzure_logoutRedirectUri();
	
	String getLogoutRedirectUri();

	// EUPF API
	String getEupfEndpointUrl();
	
	String getAzure_validateToken_selector();

	String getAwsEndpointUrl();
	
	// SMTP
	String getSmtpHost();

	String getSmtpPort();

	String getSmtpUsername();

	String getSmtpPassword();

	String getSmtpConfigset();

	boolean isSmtpSSl();

	String getSenderEmail();

	String getSenderName();

	String getSignupEmailSubject();
	
	String getSignupEmailBody();
	
	String getTalendEndpointUrl();
	
	String getSignup_forgot_password_subject();
	
	String getSignup_forgot_password_body();
	
	String getEupf_apigee_captivate_url();
	
	String getEupf_apigee_talend_key();

	String getEupf_apigee_talend_client_id();
	
	String getEupf_apigee_captivate_key();
	
	String getNonce();
	
	 String getCodeVerifier();

	
	 String getGrant_type();

	 String getOffline_access();
	 
	 String getAzure_extension_no();
	 
	 Boolean getDisable_mail();
	 
	 int getAzure_timeout();
	 
	 int getApigee_timeout();
	 
	 int getAws_timeout();
	 
	 String getCookie_domain_name();

    String getUser_group_url1();

	String getUser_group_url2();

	String get_email();

	String [] getBusinessSegment();

	String [] getAccounttype();

	String [] getAemBusinessSegment();

	String getSFCCRedirectURI();
	String getTalendEndpointUrlv1();
}
