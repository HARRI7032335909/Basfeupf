package com.basfeupf.core.jobs;

import java.util.Objects;

import javax.mail.internet.MimeBodyPart;

import org.apache.sling.event.jobs.Job;
import org.apache.sling.event.jobs.consumer.JobConsumer;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.basfeupf.core.constants.Basf_Constant;
import com.basfeupf.core.services.EupfService;
import com.google.gson.JsonObject;

@Component(service = JobConsumer.class, immediate = true, property = {
		JobConsumer.PROPERTY_TOPICS + "=" + Basf_Constant.JOB_TOPIC_EMAIL })
public class EmailJobConsumer implements JobConsumer {
	private static final Logger logger = LoggerFactory.getLogger(EmailJobConsumer.class);

	@Reference
	EupfService eupfService;

	@Override
	public JobResult process(Job job) {
		logger.debug("email job started");

		JsonObject jsonObject = new JsonObject();
		try {
			String senderEmail = (String) getValueOrNull(job.getProperty("senderEmail"));
			String senderName = (String) getValueOrNull(job.getProperty("senderName"));
			String toEmail = (String) getValueOrNull(job.getProperty("toEmail"));
			String subject = (String) getValueOrNull(job.getProperty("subject"));
			String body = (String) getValueOrNull(job.getProperty("body"));
			MimeBodyPart pdfBodyPart = (MimeBodyPart) getValueOrNull(job.getProperty("pdfBodyPart"));

			boolean status = eupfService.sendEmail(senderEmail, senderName, toEmail, subject, body, pdfBodyPart);

			jsonObject.addProperty("isEmailSend", status);

			if (status) {
				jsonObject.addProperty(Basf_Constant.STATUS, Basf_Constant.STATUS_SUCCESS);
				logger.debug("email job success");
				return JobResult.OK;
				
			} else {
				logger.debug("email job fail");
				jsonObject.addProperty(Basf_Constant.STATUS, Basf_Constant.STATUS_FAIL);
			}
		} catch (Exception e) {
			jsonObject.addProperty(Basf_Constant.STATUS, Basf_Constant.STATUS_FAIL);

			StackTraceElement[] sTElements = e.getStackTrace();
			for (StackTraceElement stackTraceEle : sTElements) {
				String corePackageName = this.getClass().getPackage().getName().split("core")[0] + "core";
				if (stackTraceEle.getClassName().contains(corePackageName)) {
					StringBuffer stringBuffer = new StringBuffer();
					stringBuffer.append("\n{").append("\n\t\"ClassName\" : \"" + stackTraceEle.getClassName() + "\"")
							.append("\n\t\"MethodName\" : \"" + stackTraceEle.getMethodName() + "\",")
							.append("\n\t\"LineNumber\" : \"" + stackTraceEle.getLineNumber() + "\",")
							.append("\n\t\"" + e.getClass().getSimpleName() + "\" : \"" + e.getMessage() + "\"")
							.append("\n}\n");
					logger.error(stringBuffer.toString());
					logger.debug("email job error"+e);
					jsonObject.addProperty(Basf_Constant.ERROR_MSG, stringBuffer.toString());
					break;
				}
			}
		}
		return JobResult.CANCEL;
	}

	public Object getValueOrNull(Object object) {
		return Objects.toString(object, null);
	}
}
