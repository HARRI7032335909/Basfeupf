package com.basfeupf.core.constants;

public final class Constants {
    public static final String METADATA_PROPERTY_DAM_SHA1 = "dam:sha1";
    public static final String JCR_PRIMARY_TYPE = "jcr:primaryType";
    public static final String JCR_PRIMARY_TYPE_DAM_ASSET = "dam:Asset";
    public static final String JCR_CONTENT_METADATA_PROPERTY_CQ_TAGS = "jcr:content/metadata/cq:tags";
    public static final String JCR_CONTENT_RENDITIONS_THUMBNAIL = "jcr:content/renditions/cq5dam.thumbnail.140.100.png/jcr:content";
    public static final String TAG_PREFIX_BASF_APPLICATION_BUSINESS_SEGMENTS = "basf:application/business-segments/";

    public static final String JCR_CONTENT_METADATA_DISPLAY_ORDER = "@jcr:content/metadata/displayOrder";

    private Constants() {
        // private constructor for class
    }
}
