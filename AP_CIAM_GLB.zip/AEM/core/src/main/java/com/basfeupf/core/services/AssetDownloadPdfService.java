package com.basfeupf.core.services;

import org.apache.sling.api.resource.ResourceResolver;

import java.io.IOException;
import java.util.List;

public interface AssetDownloadPdfService<E> {

    /**
     * This method makes the HTTP call on the given URL
     *
     * @param url
     * @return {@link String}
     */

    public String assetPath(String path);

    public List<E> getAssetList(ResourceResolver resourceResolver, String businessSegmentId, String assetPath) throws IOException;
}
