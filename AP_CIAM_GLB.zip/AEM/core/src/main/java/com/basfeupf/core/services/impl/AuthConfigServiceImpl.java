package com.basfeupf.core.services.impl;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.Designate;

import com.basfeupf.core.config.AuthConfiguration.AuthConfig;
import com.basfeupf.core.services.AuthConfigService;

@Component(service = AuthConfigService.class , immediate = true)
@Designate(ocd = AuthConfig.class)
public class AuthConfigServiceImpl implements AuthConfigService {

	// Azure
	private String azure_clientId;

	private String azure_tenant;

	private String azure_tenant_id;
	
	private String azure_client_secret;

	private String azure_enduser_signupPolicy;

	private String azure_liteuser_policy;
	
	private String azure_partner_signupPolicy;
	
	private String azure_signupRedirectUri;

	private String azure_signupScope;

	private String azure_signupResponseType;

	private String azure_loginPolicy;

	private String azure_loginRedirectUri;

	private String azure_loginScope;

	private String azure_loginResponseType;

	private String azure_resetPasswordPolicy;

	private String azure_resetPasswordRedirectUri;

	private String azure_resetPasswordScope;

	private String azure_resetPasswordResponseType;

	private String azure_logoutPolicy;

	private String azure_logoutRedirectUri;
	
	private String logoutRedirectUri;

	// EUPF API
	private String eupfEndpointUrl;
	
	private String awsEndpointUrl;
	
	private String azure_validateToken_selector;

	// SMTP
	private String smtpHost;

	private String smtpPort;

	private String smtpUsername;

	private String smtpPassword;

	private String smtpConfigset;

	private boolean smtpSSl;

	private String senderEmail;

	private String senderName;

	private String signupEmailBody;

	private String signupEmailSubject;
	
	private String talendEndpointUrl;
	private String talendEndpointUrlv1;
	
	private String signup_forgot_password_subject;
	
	

	private String signup_forgot_password_body;
	
	private String eupf_apigee_captivate_url;
	
	private String eupf_apigee_talend_key;

	private String eupf_apigee_talend_client_id;
	
	private String eupf_apigee_captivate_key;
	
	private String nonce;
	
	
	private String codeVerifier;
	private String grant_type;
	private String offline_access;
	
	private String azure_extension_no;
	
	private Boolean disable_mail;
	
	private int azure_timeout;
	
	private int apigee_timeout;
	
	private int aws_timeout;
	
	private String cookie_domain_name;
	
	private String usergroupurl1;

	private String usergroupurl2;

	private String email;

	private String [] businessSegment;

	private String [] accountType;

	private String [] aemBusinessSegment;

	private String sfccRedirectURI;



	@Activate
	@Modified
	protected void activate(AuthConfig config) {

		// Azure
		this.azure_clientId = config.azure_client_id();
		this.azure_tenant = config.azure_tenant();
		this.azure_tenant_id = config.azure_tenant_id();
		this.azure_client_secret = config.azure_client_secret();

		this.azure_enduser_signupPolicy = config.azure_enduser_signup_policy();
		this.azure_partner_signupPolicy = config.azure_partner_signup_policy();
		this.azure_liteuser_policy = config.azure_liteuser_signup_policy();
		this.azure_signupRedirectUri = config.azure_signup_Redirect_Uri();
		this.azure_signupScope = config.azure_signup_scope();
		this.azure_signupResponseType = config.azure_signup_response_type();

		this.azure_loginPolicy = config.azure_login_policy();
		this.azure_loginRedirectUri = config.azure_login_Redirect_Uri();
		this.azure_loginScope = config.azure_login_scope();
		this.azure_loginResponseType = config.azure_login_response_type();

		this.azure_resetPasswordPolicy = config.azure_reset_pswd_policy();
		this.azure_resetPasswordRedirectUri = config.azure_reset_pswd_Redirect_Uri();
		this.azure_resetPasswordScope = config.azure_reset_pswd_scope();
		this.azure_resetPasswordResponseType = config.azure_reset_pswd_response_type();

		this.azure_logoutPolicy = config.azure_logout_policy();
		this.azure_logoutRedirectUri = config.azure_logout_Redirect_Uri();
		this.logoutRedirectUri = config.logout_Redirect_Uri();

		// EUPF API
		this.eupfEndpointUrl = config.eupf_endpoint_url();
		this.azure_validateToken_selector = config.azure_validate_token_selector();
		this.awsEndpointUrl = config.aws_endpoint_url();

		// SMTP
		this.smtpHost = config.smtp_host();
		this.smtpPort = config.smtp_port();
		this.smtpUsername = config.smtp_usename();
		this.smtpPassword = config.smtp_pswd();
		this.smtpConfigset = config.smtp_configset();
		this.smtpSSl = config.smtp_ssl();
		this.senderEmail = config.sender_email();
		this.senderName = config.sender_name();
		this.signupEmailBody = config.signup_email_body();
		this.signupEmailSubject = config.signup_email_subject();
		this.talendEndpointUrl = config.eupf_talend_url();
		this.talendEndpointUrlv1 = config.eupf_talend_url_v1();
		
		
		this.signup_forgot_password_subject = config.signup_forgot_pass_subject();
		this.signup_forgot_password_body = config.signup_forgot_pass_body();
		this.eupf_apigee_captivate_url = config.eupf_apigee_captivate_url();
		this.eupf_apigee_talend_key = config.eupf_apigee_talend_key();
		this.eupf_apigee_talend_client_id = config.eupf_apigee_talend_client_id();
		this.eupf_apigee_captivate_key = config.eupf_apigee_captivate_key();
		this.nonce = config.nonce();
		
		this.codeVerifier = config.codeVerifier();
		this.grant_type = config.grant_type();
		this.offline_access = config.offline_access();
		this.azure_extension_no = config.azure_extension_no();
		this.disable_mail = config.disable_mail();
		
		this.azure_timeout = config.azure_timeout();
		this.apigee_timeout = config.apigee_timeout();
		this.aws_timeout = config.aws_timeout();
		this.cookie_domain_name = config.cookie_domain_name();

		this.usergroupurl1 = config.user_group_url1();
		this.usergroupurl2 = config.user_group_url2();

		this.email = config.email();

		this.businessSegment = config.businessSegment();
		this.accountType = config.accountType();
		this.aemBusinessSegment = config.aemBusinessSegment();
		
		this.sfccRedirectURI = config.sfccRedirectURI();
	}

	// Azure
	@Override
	public String getAzure_clientId() {
		return azure_clientId;
	}

	@Override
	public String getAzure_tenant() {
		return azure_tenant;
	}

	@Override
	public String getAzure_tenant_id() {
		return azure_tenant_id;
	}
	
	@Override
	public String getAzure_client_secret() {
		return azure_client_secret;
	}

	@Override
	public String getAzure_enduser_signupPolicy() {
		return azure_enduser_signupPolicy;
	}

	@Override
	public String getAzure_liteuser_signupPolicy() {
		return 	azure_liteuser_policy;
	}

	@Override
	public String getAzure_partner_signupPolicy() {
		return azure_partner_signupPolicy;
	}

	@Override
	public String getAzure_signupRedirectUri() {
		return azure_signupRedirectUri;
	}

	@Override
	public String getAzure_signupScope() {
		return azure_signupScope;
	}

	@Override
	public String getAzure_signupResponseType() {
		return azure_signupResponseType;
	}

	@Override
	public String getAzure_loginPolicy() {
		return azure_loginPolicy;
	}

	@Override
	public String getAzure_loginRedirectUri() {
		return azure_loginRedirectUri;
	}

	@Override
	public String getAzure_loginScope() {
		return azure_loginScope;
	}

	@Override
	public String getAzure_loginResponseType() {
		return azure_loginResponseType;
	}

	@Override
	public String getAzure_resetPasswordPolicy() {
		return azure_resetPasswordPolicy;
	}

	@Override
	public String getAzure_resetPasswordRedirectUri() {
		return azure_resetPasswordRedirectUri;
	}

	@Override
	public String getAzure_resetPasswordScope() {
		return azure_resetPasswordScope;
	}

	@Override
	public String getAzure_resetPasswordResponseType() {
		return azure_resetPasswordResponseType;
	}

	@Override
	public String getAzure_logoutPolicy() {
		return azure_logoutPolicy;
	}

	@Override
	public String getAzure_logoutRedirectUri() {
		return azure_logoutRedirectUri;
	}
	
	@Override
	public String getLogoutRedirectUri() {
		return logoutRedirectUri;
	}

	// EUPF API
	@Override
	public String getEupfEndpointUrl() {
		return eupfEndpointUrl;
	}
	
	@Override
	public String getAzure_validateToken_selector() {
		return azure_validateToken_selector;
	}
	
	@Override
	public String getAwsEndpointUrl() {
		return awsEndpointUrl;
	}

	// SMTP
	@Override
	public String getSmtpHost() {
		return smtpHost;
	}

	@Override
	public String getSmtpPort() {
		return smtpPort;
	}

	@Override
	public String getSmtpUsername() {
		return smtpUsername;
	}

	@Override
	public String getSmtpPassword() {
		return smtpPassword;
	}

	@Override
	public String getSmtpConfigset() {
		return smtpConfigset;
	}

	@Override
	public boolean isSmtpSSl() {
		return smtpSSl;
	}

	@Override
	public String getSenderEmail() {
		return senderEmail;
	}

	@Override
	public String getSenderName() {
		return senderName;
	}
	
	@Override
	public String getSignupEmailSubject() {
		return signupEmailSubject;
	}

	@Override
	public String getSignupEmailBody() {
		return signupEmailBody;
	}
	
	@Override
	public String getTalendEndpointUrl() {
		return talendEndpointUrl;
	}
	
	@Override
	public String getSignup_forgot_password_subject() {
		return signup_forgot_password_subject;
	}

	@Override
	public String getSignup_forgot_password_body() {
		return signup_forgot_password_body;
	}

	@Override
	public String getEupf_apigee_captivate_url() {
		return eupf_apigee_captivate_url;
	}

	@Override
	public String getEupf_apigee_talend_key() {
		return eupf_apigee_talend_key;
	}

	@Override
	public String getEupf_apigee_talend_client_id() {
		return eupf_apigee_talend_client_id;
	}

	@Override
	public String getEupf_apigee_captivate_key() {
		return eupf_apigee_captivate_key;
	}
	
	@Override
	public String getNonce() {
		return nonce;
	}
	
	@Override

	public String getCodeVerifier() {
		return codeVerifier;
	}

	@Override

	public String getGrant_type() {
		return grant_type;
	}

	@Override

	public String getOffline_access() {
		return offline_access;
	}
	
	@Override

	public String getAzure_extension_no() {
		return azure_extension_no;
	}

	@Override
	public Boolean getDisable_mail() {
		return disable_mail;
	}

	@Override
	public int getAzure_timeout() {
		return azure_timeout;
	}

	@Override
	public int getApigee_timeout() {
		return apigee_timeout;
	}
	
	@Override
	public int getAws_timeout() {
		return aws_timeout;
	}

	@Override
	public String getCookie_domain_name() {
		return cookie_domain_name;
	}

	@Override
	public String getUser_group_url1() {
		return usergroupurl1;
	}

	@Override
	public String getUser_group_url2() {
		return usergroupurl2;
	}

	@Override
	public String get_email() { return email;	}

	@Override
	public String[] getBusinessSegment() {
		return businessSegment;
	}

	@Override
	public String[] getAccounttype() {
		return accountType;
	}

	@Override
	public String[] getAemBusinessSegment() {
		return aemBusinessSegment;
	}

	@Override
	public String getSFCCRedirectURI() {
		return sfccRedirectURI;
	}
	@Override
	public String getTalendEndpointUrlv1() {
		return talendEndpointUrlv1;
	}

}
