package com.basfeupf.core.models;

public interface CxmSupport {

    String getPhoneSupportHeading();
    String getPhoneSupportDescription();
    String getEmailSupportHeading();
    String getLeftColumnTitle();
    String getRightColumnTitle();
    String getCustomerServiceLabel();
    String getRepSupportDescription();
    String getRepImagePath();
    String getCallus();
    String getGonow();

    String getBusinessSegments();

}
