package com.basfeupf.core.services;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

public interface PkceService {

	String generateCodeVerifier() throws Exception;

	String generateCodeChallange(String codeVerifier) throws Exception;

}
