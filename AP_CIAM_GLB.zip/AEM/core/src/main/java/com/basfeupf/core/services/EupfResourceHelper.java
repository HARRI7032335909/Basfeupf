package com.basfeupf.core.services;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.ResourceResolver;

public interface EupfResourceHelper {
	
	ResourceResolver getResourceResolver() throws LoginException;

}
