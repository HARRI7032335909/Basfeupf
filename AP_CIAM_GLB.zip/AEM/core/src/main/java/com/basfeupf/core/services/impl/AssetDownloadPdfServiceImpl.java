package com.basfeupf.core.services.impl;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.Designate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.basfeupf.core.models.AssetModel;
import com.basfeupf.core.services.AssetDownloadPdfService;
import com.basfeupf.core.servlets.AssetsConfig;

import static com.basfeupf.core.constants.Constants.*;

import com.day.cq.search.PredicateGroup;
import com.day.cq.search.Query;
import com.day.cq.search.QueryBuilder;
import com.day.cq.search.result.Hit;
import com.day.cq.search.result.SearchResult;

@Component(service = AssetDownloadPdfServiceImpl.class, immediate = true)
@Designate(ocd = AssetsConfig.class)
public class AssetDownloadPdfServiceImpl implements AssetDownloadPdfService<AssetModel> {

    private static final Logger log = LoggerFactory.getLogger(AssetDownloadPdfServiceImpl.class);

    @Reference
    private QueryBuilder builder;

    private AssetsConfig configuration;

    @Activate
    protected void activate(AssetsConfig configuration){
        this.configuration = configuration;
    }

    @Override
    public String assetPath(String path) {
        try {
            if (path.indexOf("promotion") > 0) {
                return configuration.assetPromotionPath();
            } else if (path.indexOf("program") > 0) {
                return configuration.assetSearchPath();
            } else if (path.indexOf("supply-reports") > 0) {
                return configuration.assetSupplyReportPath();
            } else if (path.indexOf("price-sheets") > 0) {
                return configuration.assetPriceSheetsPath();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return "Error Occurred" + e.getMessage();
        }
        return StringUtils.EMPTY;
    }

    @Override
    public List<AssetModel> getAssetList(ResourceResolver resourceResolver, String businessSegmentId, String servletPath) throws IOException{

        List<AssetModel> unOrderedAssetModelList = new ArrayList<>();

        List<AssetModel> orderedAssetModelList = new ArrayList<>();

        String assetPath = assetPath(servletPath);

        Query query = getAssetListSearchQuery(resourceResolver, businessSegmentId, servletPath);
        log.debug("query predicates {}", query.getPredicates());

        SearchResult searchResult = getSearchResult(query);
        log.debug("getAssetList Search Query: {}", searchResult.getQueryStatement());

        if (searchResult != null) {
            for (Hit hit : searchResult.getHits()) {
                String path;
                AssetModel assetModel = new AssetModel();
                try {
                    path = hit.getPath();
                    Resource assetResource = resourceResolver.getResource(path);
                    Resource jcrRes = assetResource.getChild("jcr:content");
                    ValueMap jcrProperties = jcrRes.getValueMap();
                    if (jcrProperties != null) {
                        assetModel.setName(jcrProperties.get("cq:name", String.class));
                    }

                    assetModel.setAssetPath(assetPath);

                    Resource childRes = assetResource.getChild("jcr:content/metadata");
                    ValueMap properties = childRes.getValueMap();
                    if (properties != null) {
                        assetModel.setDescription(properties.get("dc:description", String.class));
                        assetModel.setTitle(properties.get("dc:title", String.class));
                        assetModel.setShaId(properties.get(METADATA_PROPERTY_DAM_SHA1, String.class));
                        assetModel.setSize(properties.get("dam:size", String.class));
                        assetModel.setFormat(properties.get("dc:format", String.class));
                        assetModel.setProgramStartDate(properties.get("programStartDate", String.class));
                        assetModel.setProgramEndDate(properties.get("programEndDate", String.class));
                        assetModel.setDisplayOrder(properties.get("displayOrder", String.class));

                    }

                    if (configuration.showAssetThumbnail()) {
                        getAssetThumbnail(assetResource, assetModel);
                    }

                    if (assetModel.getDisplayOrder() !=null) {

                        orderedAssetModelList.add(assetModel);
                    }else {
                        unOrderedAssetModelList.add(assetModel);
                    }

                    log.info("description {}", assetModel.getDescription());
                } catch (RepositoryException e) {
                    log.error("Exception while writing json data for AssetServlet. Message: {}", e.getMessage());
                    throw new IOException(e);
                }
            }
            for(AssetModel am: unOrderedAssetModelList) {
                orderedAssetModelList.add(am);
            }
        }
        log.info("list size {}", orderedAssetModelList.size());
        return orderedAssetModelList;
    }

    public Hit getDownloadAsset(ResourceResolver resourceResolver, Map<String,String[]> parameterMap, String assetPath) {

        Query query = getDownloadAssetQuery(resourceResolver, parameterMap, assetPath);

        SearchResult searchResult = getSearchResult(query);
        log.debug("Search Result: {}", searchResult==null?"":searchResult.getQueryStatement());

        if (searchResult != null) {
            List<Hit> hits = searchResult.getHits();

            if (hits != null && !hits.isEmpty()) {
                return hits.get(0);
            }
        }
        return null;

    }

    private SearchResult getSearchResult(Query query) {

        if (query != null) {
            return query.getResult();
        } else {
            return null;
        }

    }

    private Query getAssetListSearchQuery(ResourceResolver resourceResolver, String businessSegmentId, String servletPath) {

        Map<String, String> map = new HashMap<>();
        map.put("path", assetPath(servletPath));
        map.put("1_property", JCR_PRIMARY_TYPE);
        map.put("1_property.value", JCR_PRIMARY_TYPE_DAM_ASSET);
        map.put("2_property", JCR_CONTENT_METADATA_PROPERTY_CQ_TAGS);
        map.put("2_property.value", TAG_PREFIX_BASF_APPLICATION_BUSINESS_SEGMENTS + businessSegmentId);
        map.put("orderby", JCR_CONTENT_METADATA_DISPLAY_ORDER);

        return builder.createQuery(PredicateGroup.create(map), resourceResolver.adaptTo(Session.class));

    }

    private Query getDownloadAssetQuery(ResourceResolver resourceResolver, Map <String, String[]> propertyMap, String assetPath) {

        Map<String, String> map = new HashMap<>();
        map.put("path", assetPath);
        map.put("1_property", METADATA_PROPERTY_DAM_SHA1);
        map.put("1_property.value", propertyMap.get("sha")==null ? "" : propertyMap.get("sha")[0]);

        return builder.createQuery(PredicateGroup.create(map), resourceResolver.adaptTo(Session.class));

    }

    private void getAssetThumbnail(Resource assetResource, AssetModel assetModel) throws RepositoryException {

        Resource renditionRes = assetResource
                .getChild(JCR_CONTENT_RENDITIONS_THUMBNAIL);
        ValueMap renditionProperties = renditionRes.getValueMap();
        Node thumbnailNode = renditionRes.adaptTo(Node.class);
        javax.jcr.Binary binaryData = thumbnailNode.getProperty("jcr:data").getBinary();
        InputStream is = null;
        try {
            is = binaryData.getStream();
            byte[] bytes = IOUtils.toByteArray(is);
            String base64Thumbnail = Base64.getEncoder().encodeToString(bytes);
            assetModel.setThumbnailBase64(base64Thumbnail);
            assetModel.setThumbnailType(renditionProperties.get("jcr:mimeType", String.class));
        } catch (IOException e) {
            log.error("Asset thunbnail exception: {}", e.getMessage());
        } finally {
            IOUtils.closeQuietly(is);
        }

    }


}
