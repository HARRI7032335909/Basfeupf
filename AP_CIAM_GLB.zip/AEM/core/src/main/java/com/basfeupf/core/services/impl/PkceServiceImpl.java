package com.basfeupf.core.services.impl;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

import org.osgi.service.component.annotations.Component;

import com.basfeupf.core.services.PkceService;

@Component(service=PkceService.class)
public class PkceServiceImpl implements PkceService {

	@Override
	public String generateCodeVerifier() throws Exception {
		SecureRandom secureRandom = new SecureRandom();
		byte[] codeVerifier = new byte[32];
		secureRandom.nextBytes(codeVerifier);

		return Base64.getUrlEncoder().withoutPadding().encodeToString(codeVerifier);
	}

	@Override
	public String generateCodeChallange(String codeVerifier) throws Exception {
		byte[] bytes = codeVerifier.getBytes("US-ASCII");
		MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
		messageDigest.update(bytes, 0, bytes.length);
		byte[] digest = messageDigest.digest();

		return Base64.getUrlEncoder().withoutPadding().encodeToString(digest);
	}

}
