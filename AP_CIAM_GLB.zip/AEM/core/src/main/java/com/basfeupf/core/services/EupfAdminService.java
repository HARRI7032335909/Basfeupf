package com.basfeupf.core.services;

import com.google.gson.JsonObject;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;

public interface EupfAdminService {

    JsonObject getAttrbutesList(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject getSegmentsList(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject getAppsList(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject insertAttributeDetails(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject updateAttributeDetails(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject insertSegmentDetails(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject updateSegmentDetails(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject getAttributeSegmentMap(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject insertAttributeSegmentMap(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject insertApplicationDetails(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject updateApplicationDetails(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject getAppSegmentAttributeMap(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject insertAppSegmentAttributeMap(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject deleteSegmentAttributeMap(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject deleteAppSegmentAttributeMap(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject deleteAttributeDetail(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject deleteSegmentDetail(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject deleteAppDetail(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject insertUserGroup(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject deleteusergroup(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject updateusergroup(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject getUserGroupList(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;

    JsonObject insertAttributeLocaleMap(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;
    
    JsonObject deleteAttributeLocaleMap(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;
    
    JsonObject getAttributeLocaleMap(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;
    JsonObject getReportDetails(SlingHttpServletRequest request, SlingHttpServletResponse response) throws Exception;
 
}
