/*
 *  Copyright 2015 Adobe Systems Incorporated
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package com.basfeupf.core.schedulers;

import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.basfeupf.core.constants.Basf_Constant;
import com.basfeupf.core.services.EupfService;
import com.basfeupf.core.services.HttpCallerService;
import com.basfeupf.core.services.StatusPendingSchedulerService;
import com.basfeupf.core.services.TalendServise;
import com.google.gson.JsonObject;

@Designate(ocd=StatusPendingScheduler.Config.class)
@Component(service= {Runnable.class})
public class StatusPendingScheduler implements Runnable {
	
	@Reference
	EupfService eupfService;
	
	@Reference
	TalendServise talendServise;
	
	@Reference
	HttpCallerService httpCallerService;

    @ObjectClassDefinition(name="EUPF User Update Scheduler",
                           description = "Scheduled Task For User Status Update")
    public static @interface Config {

		@AttributeDefinition(name = "Scheduler Enable", description = "Check to Enable the Scheduler")
		boolean scheduler_enable() default false;

		@AttributeDefinition(name = "Cron-job expression")
		String scheduler_expression() default "* */30 * * * ?";

        @AttributeDefinition(name = "Concurrent task",
                             description = "Whether or not to schedule this task concurrently")
        boolean scheduler_concurrent() default false;

		@AttributeDefinition(name = "User Update Limit", description = "Enter User Update Limit", type = AttributeType.INTEGER, required = false)
		int user_update_limit() default 100;
    }

    private final Logger logger = LoggerFactory.getLogger(getClass());

    private int userUpdateLimit;
    private boolean is_Scheduler_enable;
    
    @Override
    public void run() {
        
        JsonObject responseJson = new JsonObject();
        try {
//        	JsonObject requestJson = new JsonObject();
//            requestJson.addProperty("type", "get_status_pending_users");
//            requestJson.addProperty("limit", getUserUpdateLimit());
//            if (is_Scheduler_enable) {
//            	responseJson = eupfService.callAwsRestService(requestJson);
//			}
        	if (is_Scheduler_enable) {
        	logger.debug("scheduler started");
        	talendServise.batchUpdate(userUpdateLimit);
        	logger.debug("scheduler ended");
        	}
			
		} catch (Exception e) {
			responseJson.addProperty(Basf_Constant.ERROR_MSG, e.getClass().getSimpleName() + " : " + e.getMessage());
			StackTraceElement[] sTElements = e.getStackTrace();
			for (StackTraceElement stackTraceEle : sTElements) {
				String corePackageName = this.getClass().getPackage().getName().split("core")[0] + "core";
				if (stackTraceEle.getClassName().contains(corePackageName)) {
					StringBuffer stringBuffer = new StringBuffer();
					stringBuffer.append("\n{").append("\n\t\"ClassName\" : \"" + stackTraceEle.getClassName() + "\"")
							.append("\n\t\"MethodName\" : \"" + stackTraceEle.getMethodName() + "\",")
							.append("\n\t\"LineNumber\" : \"" + stackTraceEle.getLineNumber() + "\",")
							.append("\n\t\"" + e.getClass().getSimpleName() + "\" : \"" + e.getMessage() + "\"")
							.append("\n}\n");
					logger.error(stringBuffer.toString());
					JsonObject errorJson = new JsonObject();
					errorJson.addProperty("ClassName", stackTraceEle.getClassName());
					errorJson.addProperty("MethodName", stackTraceEle.getMethodName());
					errorJson.addProperty("LineNumber", stackTraceEle.getLineNumber());
					errorJson.addProperty(e.getClass().getSimpleName(), e.getMessage());
					responseJson.add(Basf_Constant.ERROR_JSON, errorJson);
					break;
				}
			}
		}
    }

    @Activate
    @Modified
    protected void activate(final Config config) {
        this.userUpdateLimit = config.user_update_limit();
        this.is_Scheduler_enable = config.scheduler_enable();
    }

    
    
}
