package com.basfeupf.core.services.impl;

import com.basfeupf.core.config.TealiumAuthConfiguration.TealiumConfig;
import com.basfeupf.core.services.TealiumConfigService;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.Designate;

@Component(service = TealiumConfigService.class, immediate = true)
@Designate(ocd = TealiumConfig.class)
public class TealiumConfigServiceImpl implements TealiumConfigService{

    private String tealiumDomain;

    @Activate
    @Modified
    protected void activate(TealiumConfig tealiumConfig){
        this.tealiumDomain = tealiumConfig.tealium_domain();
    }

    @Override
    public String getTealiumDomain() {
        return tealiumDomain;
    }
}