package com.basfeupf.core.jobs;

import com.basfeupf.core.constants.Basf_Constant;
import com.basfeupf.core.services.AuthConfigService;
import com.basfeupf.core.services.TalendServise;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.apache.sling.event.jobs.Job;
import org.apache.sling.event.jobs.consumer.JobConsumer;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

@Component(service = JobConsumer.class, immediate = true, property = {
            JobConsumer.PROPERTY_TOPICS + "=" + Basf_Constant.JOB_TOPOC_PROFILE_UPDATE })

public class ProfileUpdateJobConsumer implements JobConsumer{

//    @Reference
//    AuthConfigService authConfigService;
//    @Reference
//    TalendServise talendServise;

    private static final Logger logger = LoggerFactory.getLogger(ProfileUpdateJobConsumer.class);

    @Override
    public JobResult process(Job job) {
        logger.debug("Profile Job Started");
        JsonObject jsonObject = new JsonObject();
        try{
            JsonObject userJson = (JsonObject) job.getProperty("userData");

            JsonObject profileObj = new JsonObject();
            profileObj.addProperty("EUPF_ID", userJson.get("sub").getAsString());
            profileObj.addProperty("Request_Attribute", "Profile");
            profileObj.addProperty("Request_Type", "Update");
            profileObj.addProperty("Lead_ID", userJson.get("prospect_id").getAsString());
            profileObj.addProperty("Email_Address", userJson.get("email").getAsString());

            JsonArray attributeArray = new JsonArray();
            Gson gson = new Gson();
            String attributeObjString = "[{\"attr_key\":\"Contact_First_Name\",\"attr_value\":\""+userJson.get("firstname").getAsString()+"\"},{\"attr_key\":\"Contact_Last_Name\",\"attr_value\":\""+userJson.get("lastname").getAsString()+"\"},{\"attr_key\":\"Email_Address\",\"attr_value\":\""+userJson.get("email").getAsString()+"\"},{\"attr_key\":\"Account_Sub_Type\",\"attr_value\":\""+userJson.get("businessType").getAsString()+"\"},{\"attr_key\":\"Mailing_Address\",\"attr_value\":\""+userJson.get("extension_mailing_address").getAsString()+"\"},{\"attr_key\":\"City\",\"attr_value\":\""+userJson.get("extension_mailing_city").getAsString()+"\"},{\"attr_key\":\"State\",\"attr_value\":\""+userJson.get("extension_mailing_state").getAsString()+"\"},{\"attr_key\":\"Zipcode\",\"attr_value\":\""+userJson.get("extension_mailing_postalCode").getAsString()+"\"},{\"attr_key\":\"Country\",\"attr_value\":\""+userJson.get("country").getAsString()+"\"},{\"attr_key\":\"Mobile_Phone\",\"attr_value\":\""+userJson.get("mobile").getAsString()+"\"},{\"attr_key\":\"Preferred_Language\",\"attr_value\":\""+userJson.get("preferredLanguage").getAsString()+"\"},{\"attr_key\":\"Business_Name\",\"attr_value\":\""+userJson.get("extension_business_name").getAsString()+"\"},{\"attr_key\":\"Email_Opt_In\",\"attr_value\":\""+(userJson.get("extension_email_communication_consent").getAsString().equalsIgnoreCase("true")?"Yes":"No")+"\"},{\"attr_key\":\"Text_Opt_In\",\"attr_value\":\""+(userJson.get("extension_MobileConsent").getAsString().equalsIgnoreCase("true")?"Yes":"No")+"\"}]";
            attributeArray = gson.fromJson(attributeObjString, JsonArray.class);
            logger.debug("Attributes before filter"+attributeArray);
            for (int i = 0; i < attributeArray.size(); i++){
                if(attributeArray.get(i).getAsJsonObject().get("attr_value") == null){
                    attributeArray.remove(i);
                }
            }
            logger.debug("Attributes after filter"+attributeArray);
//            profileObj.add("Attributes", attributeArray);
//            String url = authConfigService.getTalendEndpointUrl()+Basf_Constant.TALEND_PROFILE_ENDPOINT;
//            JsonObject headerJson = new JsonObject();
//            String xApiKey = authConfigService.getEupf_apigee_talend_key();// config
//            String talendApiClientIds = authConfigService.getEupf_apigee_talend_client_id();
//            headerJson.addProperty("client_secret", xApiKey);
//            headerJson.addProperty("client_id", talendApiClientIds);
//            logger.debug("Profile update Request "+profileObj);
//            JsonObject talendresponseJson = talendServise.callPost(profileObj, url, headerJson);
//            logger.debug("Profile update response: "+talendresponseJson);
//            logger.debug("Profile Job Ended");

        }catch (Exception e){
            jsonObject.addProperty(Basf_Constant.STATUS, Basf_Constant.STATUS_FAIL);

            StackTraceElement[] sTElements = e.getStackTrace();
            for (StackTraceElement stackTraceEle : sTElements) {
                String corePackageName = this.getClass().getPackage().getName().split("core")[0] + "core";
                if (stackTraceEle.getClassName().contains(corePackageName)) {
                    StringBuffer stringBuffer = new StringBuffer();
                    stringBuffer.append("\n{").append("\n\t\"ClassName\" : \"" + stackTraceEle.getClassName() + "\"")
                            .append("\n\t\"MethodName\" : \"" + stackTraceEle.getMethodName() + "\",")
                            .append("\n\t\"LineNumber\" : \"" + stackTraceEle.getLineNumber() + "\",")
                            .append("\n\t\"" + e.getClass().getSimpleName() + "\" : \"" + e.getMessage() + "\"")
                            .append("\n}\n");
                    logger.error(stringBuffer.toString());
                    logger.debug("email job error"+e);
                    jsonObject.addProperty(Basf_Constant.ERROR_MSG, stringBuffer.toString());
                    break;
                }
            }
        }
        return JobResult.CANCEL;
    }
}
