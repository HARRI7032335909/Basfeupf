package com.basfeupf.core.services;

import com.google.gson.JsonObject;

public interface UserDetailsService {
    JsonObject updateUser(String userId, JsonObject userObject, String appAccessToken);
}
