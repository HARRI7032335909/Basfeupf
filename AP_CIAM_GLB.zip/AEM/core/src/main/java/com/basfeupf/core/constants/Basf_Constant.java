package com.basfeupf.core.constants;

public interface Basf_Constant {

	public final static String STATUS_CODE = "statuscode";
	public final static String STATUS = "status";
	public final static String ERROR_CODE = "errorcode";
	public final static String ERROR_MSG = "errormsg";
	public final static String SUCCESS_MSG = "successmsg";
	public final static String DATA = "data";
	public final static String STATUS_CODE_200 = "200";
	public final static String STATUS_SUCCESS = "success";
	public final static String STATUS_FAIL = "fail";
	public final static String SUB_SERVICE = "subServiceName";
	public final static String PAGE_PATH="/content/basfeupf/us/en";

	public final static String APPLICATION_JSON = "application/json";
	public final static String APPLICATION_PDF = "application/pdf";
	
	public final static String SUB_SERVICE_NAME = "subServiceName";
	
	public final static String JOB_TOPIC_EMAIL = "basf/eupf/email/job";
	public final static String JOB_TOPOC_PROFILE_UPDATE = "basf/eupf/profileUpdate/job";
	public static final String ERROR_JSON = "errorjson";
	
	public final static String LOGIN = "login";
	public final static String FORGOT_PASSWORD = "forgotpassword";
	public final static String PARTNER = "partner";
	public final static String REGISTER = "register";
	public final static String LITE_REGISTER = "registerAsLite";
	public final static String ABORT = "abort";
	public final static String TALEND_LOGIN_REG_ENDPOINT = "login";
	public final static String TALEND_LMX_ENDPOINT = "users";
	public final static String TALEND_APP_ENDPOINT = "app";
	public final static String TALEND_BATCH_UPDATE_ENDPOINT = "batch";
	public final static String TALEND_SEGMENT_ENDPOINT = "segment";
	public final static String TALEND_CAPTIVATE_ENDPOINT = "ap/captivateprime/v1/users";
	public final static String TALEND_PROFILE_ENDPOINT = "profile";
	public final static String LINKED = "Linked";
}
