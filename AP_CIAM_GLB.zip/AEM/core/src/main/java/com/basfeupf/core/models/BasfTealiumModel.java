package com.basfeupf.core.models;
import com.basfeupf.core.services.TealiumConfigService;
import com.day.cq.wcm.api.Page;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.apache.jackrabbit.commons.JcrUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.jcr.Node;
import java.util.*;

@Model(adaptables = {Resource.class, SlingHttpServletRequest.class}, defaultInjectionStrategy = DefaultInjectionStrategy.REQUIRED)

public class BasfTealiumModel {

    @OSGiService
    TealiumConfigService tealiumConfigService;

    @SlingObject
    SlingHttpServletRequest request;

    @Inject
    @Default(values = "")
    String pagePath;

    String pageCategory = "";
    String pageSubCategory = "";
    String pageType = "";
    String pageIdentifier = "";
    String pageLanguage = "";


    Map<String, String> map = new HashMap<>();

    @PostConstruct
    public Map<String , String> getMap() {
        JsonObject jsonObject = new JsonObject();
        ResourceResolver resourceResolver = null;
        try {
            resourceResolver = request.getResourceResolver();
            Node node = resourceResolver.resolve(pagePath+"/jcr:content").adaptTo(Node.class);
            if (node.hasProperty("page_category")) {
                jsonObject.addProperty("page_category", node.getProperty("page_category").getString());
                pageCategory = node.getProperty("page_category").getString();
            }
            if (node.hasProperty("page_subcategory")) {
                jsonObject.addProperty("page_subcategory", node.getProperty("page_subcategory").getString());
                pageSubCategory = node.getProperty("page_subcategory").getString();
            }
            if (node.hasProperty("page_type")) {
                jsonObject.addProperty("page_type", node.getProperty("page_type").getString());
                pageType = node.getProperty("page_type").getString();
            }
            if (node.hasProperty("page_identifier")) {
                jsonObject.addProperty("page_identifier", node.getProperty("page_identifier").getString());
                pageIdentifier = node.getProperty("page_identifier").getString();
            }
            Resource resource = resourceResolver.getResource(pagePath);
            Page page = resource.adaptTo(Page.class);
            Locale pageLocale = page.getLanguage(true);
            pageLanguage = pageLocale.toString();

            map = convertJsonObjectToMap(jsonObject);
        } catch (Exception e) {
        }
        return map;
    }


    public String getPageCategory() {
        return pageCategory;
    }

    public String getPageSubCategory() {
        return pageSubCategory;
    }

    public String getPageType() {
        return pageType;
    }

    public String getPageIdentifier() { return pageIdentifier;}

    public String getTealiumDomain(){
        return tealiumConfigService.getTealiumDomain();
    }

    public String getPageLanguage() { return pageLanguage; }

    private Map<String, String> convertJsonObjectToMap(JsonObject jsonObject) {
        if (Objects.nonNull(jsonObject)) {
            Gson gson = new Gson();
            Map map = gson.fromJson(jsonObject.toString(),Map.class);
            return map;
        }
        return null;
    }

}