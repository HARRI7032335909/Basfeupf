package com.basfeupf.core.services;

import org.apache.sling.api.SlingHttpServletRequest;

import com.google.gson.JsonObject;
import org.apache.sling.api.SlingHttpServletResponse;

public interface AzureAuthService {

	JsonObject isValidToken(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws Exception;

	JsonObject getPayloadJson(String id_token) throws Exception;

	boolean isValidToken(JsonObject jsonObject) throws Exception;

	JsonObject validateThirdPartyClaims(String id_token, String nonce, String state) throws Exception;

}
