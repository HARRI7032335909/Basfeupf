package com.basfeupf.core.models;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.WCMMode;
import java.util.Date;
import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;

@Model(adaptables = {Resource.class, SlingHttpServletRequest.class},
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class BreadcrumbModel {

    private static final Logger LOG = LoggerFactory.getLogger(BreadcrumbModel.class);

@Inject
private Page currentPg;
@ScriptVariable
private ResourceResolver resolver;
@SlingObject
private Resource currentResource;
@Inject
SlingHttpServletRequest request;
    private String errorMessage;
    private String	idPrefix;
    public final void activate() throws Exception {
        this.idPrefix = StringUtils.defaultString("idPrefix", String.valueOf(String.class));
        try {
            init();
        } catch (Exception e) {
            LOG.error("\n ERROR ",e.getMessage());
        }
    }

    protected void init() throws Exception {
        //To be overridden in Inherited Classes
    }

    /**
     * Gets an unique id for the component markup.
     *
     * @return unique id for the id attribute.
     */
    public String getId() {
        String id = getPropertyAsString("id");
        if (id == null || id.isEmpty()) {
            id = getIdPrefix() + Math.abs(getResource(id).getPath().hashCode() - 1);
        }
        return id;
    }

    protected String getIdPrefix() {
        return this.idPrefix;
    }

    /**
     * Checks to see if there is any error in the component.
     *
     * @return true if there is an error, false otherwise.
     */
    public boolean getHasError() {
        return StringUtils.isNotBlank(this.errorMessage);
    }

    /**
     * Gets the error message.
     *
     * @return the error message if any.
     */
    public String getErrorMessage() {
        return this.errorMessage;
    }

    public WCMMode isAuthor() {
        WCMMode mode = WCMMode.fromRequest(request);
        return mode;
    }

public Resource getResource(final String resourceName){
    while(currentPg != null){
        Resource contentRes = currentPg.getContentResource();
        if (contentRes != null){
            Resource tempRes = contentRes.getChild(resourceName);
            if (tempRes != null){
                return tempRes;
            }
        }
        currentPg = currentPg.getParent();
    }
    return null;
}

protected Resource getResourceWithChildren(String resourceName){
    while(currentPg != null){
        Resource contentRes = currentPg.getContentResource();
        if (contentRes != null) {
            Resource tempRes = contentRes.getChild(resourceName);
            if (tempRes != null && tempRes.hasChildren()) {
                return tempRes;
            }
        }
        currentPg = currentPg.getParent();
    }
    return null;
}

protected Resource getResourceWithChildren(String resourceName, String childResourceName){
    while(currentPg != null){
        Resource contentRes = currentPg.getContentResource();
        if (contentRes != null){
            Resource tempRes = contentRes.getChild(resourceName);
            if (tempRes != null && tempRes.hasChildren()) {
                Resource childRes = tempRes.getChild(childResourceName);
                if (childRes != null){
                    return tempRes;
                }
            }
        }
        currentPg = currentPg.getParent();
    }
    return null;
}

protected Resource getResourceWithChildrenAndPagePropertyChecked(String resourceName, String checkBoxPropertyName) {
    Resource navRes = null;
    while(currentPg != null){
        Resource contentRes = currentPg.getContentResource();
        Resource tempRes = contentRes.getChild(resourceName);
        if(tempRes != null && tempRes.hasChildren()) {
            Resource headerRes = tempRes.getResourceResolver().getResource(resourceName);
            Page tempResPage = headerRes.adaptTo(Page.class);
            if (tempResPage != null) {
                ValueMap pageVm = tempResPage.getProperties();
                Boolean isNavInheritanceOveride = pageVm.get(checkBoxPropertyName, Boolean.FALSE);
                if (isNavInheritanceOveride.booleanValue()){
                    return headerRes;
                }
                else {
                    navRes = headerRes;
                }
            }
        }
        currentPg = currentPg.getParent();
    }
    return navRes;
}

    /**
     * Gets the property as string.
     *
     * @param propertyName
     *            the property name
     * @return the property as string
     */
    protected String getPropertyAsString(final String propertyName) {
        return getPropertyValue(propertyName, String.class);
    }

    /**
     * Gets the property as string.
     *
     * @param propertyName
     *            the property name
     * @return the property as string
     */
    protected String getInheritedPropertyAsString(final String resourceName, final String propertyName) {
        return getInheritedPropertyValue(resourceName, propertyName, String.class);
    }

    /**
     * Gets the property as string array.
     *
     * @param propertyName
     *            the property name
     * @return the property as string
     */
    protected String[] getInheritedPropertyAsStringArray(final String resourceName, final String propertyName) {
        return getInheritedPropertyValue(resourceName, propertyName, String[].class);
    }

    /**
     * Gets the property as int.
     *
     * @param propertyName
     *            the property name
     * @return the property as int
     */
    protected Integer getPropertyAsInt(final String propertyName) {
        return getPropertyValue(propertyName, Integer.class);
    }

    /**
     * Gets the property as date.
     *
     * @param propertyName
     *            the property name
     * @return the property as date
     */
    protected Date getPropertyAsDate(final String propertyName) {
        return getPropertyValue(propertyName, Date.class);
    }

    /**
     * Gets the property as boolean.
     *
     * @param propertyName
     *            the property name
     * @return the property as boolean
     */
    protected Boolean getPropertyAsBoolean(final String propertyName) {
        return getPropertyValue(propertyName, Boolean.class);
    }

    /**
     * Gets the property as string array.
     *
     * @param propertyName
     *            the property name
     * @return the property as string array
     */
    protected String[] getPropertyAsStringArray(final String propertyName) {
        return getPropertyValue(propertyName, String[].class);
    }

    /**
     * Gets the property as string.
     *
     * @param propertyName
     *            the property name
     * @param defaultValue
     *            the default value
     * @return the property as string
     */
    protected String getPropertyAsString(final String propertyName, final String defaultValue) {
        return getPropertyValue(propertyName, String.class, defaultValue);
    }

    /**
     * Gets the property as int.
     *
     * @param propertyName
     *            the property name
     * @param defaultValue
     *            the default value
     * @return the property as int
     */
    protected int getPropertyAsInt(final String propertyName, final int defaultValue) {
        return getPropertyValue(propertyName, Integer.class, defaultValue);
    }

    /**
     * Gets the property as date.
     *
     * @param propertyName
     *            the property name
     * @param defaultValue
     *            the default value
     * @return the property as date
     */
    protected Date getPropertyAsDate(final String propertyName, final Date defaultValue) {
        return getPropertyValue(propertyName, Date.class, defaultValue);
    }

    /**
     * Gets the property as boolean.
     *
     * @param propertyName
     *            the property name
     * @param defaultValue
     *            the default value
     * @return the property as boolean
     */
    protected boolean getPropertyAsBoolean(final String propertyName, final boolean defaultValue) {
        return getPropertyValue(propertyName, Boolean.class, defaultValue);
    }

    /**
     * Gets the property as string array.
     *
     * @param propertyName
     *            the property name
     * @param defaultValue
     *            the default value
     * @return the property as string array
     */
    protected String[] getPropertyAsStringArray(final String propertyName, final String[] defaultValue) {
        return getPropertyValue(propertyName, String[].class, defaultValue);
    }

    /**
     * Gets the property as string.
     *
     * @param propertyName
     *            the property name
     * @return the property as string
     */
    protected String getInheritedPropertyAsString(final String resourceName, final String propertyName, final String climbupProperty) {
        return getInheritedPropertyValue(resourceName, propertyName, climbupProperty, String.class);
    }

private <T>T getInheritedPropertyValue(final String resourceName, final String propertyName, final String climbupProperty,
                                       final Class<T> classType){
    while (currentPg != null){
        Resource contentRes = currentPg.getContentResource();
        if (contentRes != null) {
            Resource tempRes = contentRes.getChild(resourceName);
            if (tempRes != null) {
                ValueMap vm = tempRes.getValueMap();
                T val = vm.get(propertyName, classType);
                Boolean inherit = vm.get(climbupProperty, Boolean.FALSE);
                if (!inherit.booleanValue() && val != null) {
                    return val;
                }
            }
        }
        currentPg = currentPg.getParent();
    }

    return (T) null;
}

    private <T> Resource getInhertitedResourceWithPropertyNotNull(final String resourceName, final String propertyName,
                                                                  final Class<T> classType) {
        while (currentPg != null) {
            Resource contentRes = currentPg.getContentResource();
            if (contentRes != null) {
                Resource tempRes = contentRes.getChild(resourceName);
                if (tempRes != null) {
                    ValueMap vm = tempRes.getValueMap();
                    if (null != vm.get(propertyName, classType)) {
                        return tempRes;
                    }
                }
            }
            currentPg = currentPg.getParent();
        }

        return null;
    }

    private <T> ValueMap getInheritedValueMap(final String resourceName, final String propertyName, final Class<T> classType) {
        Resource res = getInhertitedResourceWithPropertyNotNull(resourceName, propertyName, classType);
        return res != null ? res.getValueMap() : null;
    }

    private <T> T getPropertyValue(final String propertyName, final Class<T> classType) {
        final ValueMap vm = currentPg.getProperties();
        return vm != null ? vm.get(propertyName, classType) : null;
    }

    private <T> T getInheritedPropertyValue(final String resourceName, final String propertyName, final Class<T> classType) {
        final ValueMap vm = getInheritedValueMap(resourceName, propertyName, classType);
        return vm != null ? vm.get(propertyName, classType) : null;
    }

    private <T> T getPropertyValue(final String propertyName, final Class<T> classType, final T defaultValue) {
        final ValueMap vm = currentPg.getProperties();
        final T value = vm != null ? vm.get(propertyName, classType) : defaultValue;
        return (value != null) ? value : defaultValue;
    }
}
