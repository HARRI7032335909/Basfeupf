package com.basfeupf.core.services;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.osgi.framework.ServiceException;

import com.google.gson.JsonObject;

public interface HttpCallerService {

	JsonObject createRequest(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException;

	JsonObject callPost(JsonObject requestBody, String url) throws ServiceException, IOException;

	JsonObject callGet(String string) throws ClientProtocolException, IOException, ServiceException;

}
