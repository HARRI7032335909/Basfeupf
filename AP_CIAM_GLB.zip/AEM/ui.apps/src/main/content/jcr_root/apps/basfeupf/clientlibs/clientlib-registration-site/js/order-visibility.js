/** ORDER VISIBILITY REPORT SCRIPT ( OVR ) **/
(function() {
  // START ORDER VISIBILITY 
  const REPORT_ENDPOINT = "order-visibility.get_report_details.json";
  const EMBED_REPORT_URL_ENDPOINT = "accountoverview.get_embedded_report.json";
  const CHECK_PAGE_NAME = "order-visibility";
  
  const _METHOD_OF_CALLING = postAjaxRequest;
  const _TYPE_OF_HTTP_CALL = "POST";
  const _SERVLET_BASE_PATH = "/content/basfeupf/us";
  const getBusSegIDForOVR = localStorage.getItem("businesssegmentid");
  const getBusinessUnitID = (getBusSegIDForOVR == "22") ? $('cxm-report-dashboard').attr('data-uscrop-bus-unit-id') : $('cxm-report-dashboard').attr('data-pss-bus-unit-id');
  
  const getAccTypeNameForOVR = localStorage.getItem("businessgroup");
    const reportStatusMsg = {
        'noAccess' : $('cxm-powerbi-embed').attr('no-access-label'),
        'error' : $('cxm-powerbi-embed').attr('error-message')
    } 

  const buildReportspayload = function () {
      return { busUnitId: getBusinessUnitID, busSegId: getBusSegIDForOVR, accTypeName:  getAccTypeNameForOVR};
  };
  
  const pbi = window['powerbi-client']
  
  function embedPowerBIReport(data) {

    // Set up the configuration object that determines what to embed and how to embed it.
    const embedConfiguration = {
      accessToken: data.embedToken,
      embedUrl: data.embedUrl,
      id: data.reportId,
      permissions: pbi.models.Permissions.All,
      tokenType: pbi.models.TokenType.Embed,
      type: "report",
    };
  
    // Get a reference to the HTML element that contains the embedded report.
    const embedContainer = $("#embed-report-article");
  
    // Embed the report.
    const powerbii = new pbi.service.Service(
      pbi.factories.hpmFactory,
      pbi.factories.wpmpFactory,
      pbi.factories.routerFactory
    );
  
    powerbii.reset(embedContainer);
    //   scrollToTopOf(embedContainer, 600);
    $("#no-reports-loaded-yet").hide();
    const report = window.powerbi.embed(embedContainer.get(0), embedConfiguration);
  
    // report.on will add an event handler
    report.on("loaded", function () {
        console.log("loaded");
      report.off("loaded");
    });
  
    // report.off removes all event handlers for a specific event
   report.off("error");
  
    report.on("error", function (event) {
        console.log("Report error ", event.detail);
      this.reportError = true;
  
    });
  
    // report.off removes all event handlers for a specific event
    report.off("rendered");
  
    // report.on will add an event handler
    report.on("rendered", function () {
        console.log("rendered");
      this.loading = false;
      report.off("rendered");
    });
  }
  
  
  function embedCallBack(embedData) {
    console.log('embed data', embedData);
      const embedReportData = JSON.parse(embedData);
      if(!embedReportData || embedReportData.errormsg) {
      console.log("embed api error, show on ui ,something went wrong");
         $('.order-visibility-section #status-of-report').text(reportStatusMsg.error);
      } else {
      embedPowerBIReport(embedReportData);
      }
  
  }
  
  function returnValidArrayOfUsrRole(grpROle) {
      const resArr = [];
      const arrayOfGrpNdRole = grpROle.split(',').filter(n => n);
      for (var i = 0; i < arrayOfGrpNdRole.length; i++) {
           resArr.push(arrayOfGrpNdRole[i].split(":")[1]);
  
      }
      return resArr.filter(n => n);
  }
  
  function trimAlphabets(inputString) {
    // Remove alphabets using regex
    const trimmedString = inputString.replace(/[a-zA-Z]/g, '');
  
    return trimmedString;
  }

  function reportCallBack(reportsData) {
      const reports = JSON.parse(reportsData);
    const getUserEmail = JSON.parse(localStorage.getItem('userloggedindata'))?.userinfo?.email || '';
    const getUsrGrpRoleStr = JSON.parse(localStorage.getItem('userloggedindata'))?.userinfo?.groups;
    const getRolesArr = returnValidArrayOfUsrRole(getUsrGrpRoleStr);

  
      var prepareEmbedReqBody = {
       "busUnitId": getBusinessUnitID,
        "busSegId": parseInt(getBusSegIDForOVR),
        "reportId": reports.reportDetails[0].reportid,
        "datasetId": reports.reportDetails[0].datasetid,
        "emailAddress": getUserEmail,
        "accTypeName": getAccTypeNameForOVR,
        "accountBasfId": String(parseInt(trimAlphabets(localStorage.getItem("businessaccountid"))))
      };

      /** SET user Role **/
      if (getRolesArr.length > 0) { 
          for (let i = 0; i < getRolesArr.length; i++) { 
            if (
              getRolesArr[i] == 'Sold_to_Viewer' ||
              getRolesArr[i] == 'Ship_to_Viewer'
            ) {
              prepareEmbedReqBody["role"] = getRolesArr[i]; // false
            }
          }
      } 
      else {
          prepareEmbedReqBody["role"] = 'noaccess';

          $('.order-visibility-section #status-of-report').text(reportStatusMsg.noAccess);
          console.log("dont call embed api , show report error msg to ui");
      }
  
  
  if(prepareEmbedReqBody["role"] != 'noaccess')
    _METHOD_OF_CALLING(
        _TYPE_OF_HTTP_CALL,
        `${_SERVLET_BASE_PATH}/${EMBED_REPORT_URL_ENDPOINT}`,
        prepareEmbedReqBody,
        embedCallBack
      );
  
  }
  
  /**
   * INIT the order visibility report flow
   */
  function initOrderVisibilityReportFlow() {
      _METHOD_OF_CALLING(
        _TYPE_OF_HTTP_CALL,
        `${_SERVLET_BASE_PATH}/${REPORT_ENDPOINT}`,
        buildReportspayload(),
        reportCallBack
      );
  }
  
  // START
  // Init order visibility  flow only if the user is on the order visibility page
  if ($("#order-visibility-page").length) {
    initOrderVisibilityReportFlow();
  }

  })();