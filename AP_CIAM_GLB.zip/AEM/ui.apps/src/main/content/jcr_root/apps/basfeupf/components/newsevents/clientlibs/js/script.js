var appTools = {
    "type": "get_app_id",
    "segment_id": 30,
    "account_type": ""
}

// $(".news-event-selection select").change(function (e) {

//     var selectedSegment = $(this).val();
//     if (selectedSegment != null) {
//         localStorage.setItem("selectedSegment", selectedSegment);
//     }
//     $(".news-section").find(".news-component").addClass("hide");
//     $(".events-section").find(".events-container").addClass("hide");
//     $(".news-section").find("[data-segmentid=" + selectedSegment + "]").removeClass("hide");
//     $(".events-section").find("[data-segmentid=" + selectedSegment + "]").removeClass("hide");
//     var data = JSON.parse(localStorage.getItem('userloggedindata'));
//     if (data.userinfo.hasOwnProperty("groups")) {
//         if (data.userinfo.groups != "") {
//             var usergroupname = "";
//             var usergroupset = data.userinfo.groups.split(",");
//             for (var i = 0; i < usergroupset.length; i++) {
//                 var usergroup = usergroupset[i].split(":");
//                 usergroupname += usergroup[0] + ",";
//             }
//             appTools.user_group = usergroupname.substring(0, usergroupname.length - 1);
//         } else {
//             var usergroupset = data.userinfo.groups;
//             appTools.user_group = usergroupname;
//         }
//     }

//     /*var usergroupname="";
//     var usergroupset = data.userinfo.groups.groups.split(",");
//     for(var i=0; i<usergroupset.length; i++){
//         var usergroup = usergroupset[i].split(":");
//         usergroupname += usergroup[1]+",";
//     }
//     appTools.user_group=usergroupname.substring(0,usergroupname.length-1);}*/
//     if (data.talendstatus == 'Acknowledged') {
//         appTools.type = "get_app_data_acknowledged_status";
//     }
//     appTools.segment_id = $(this).val();
//     appTools.account_type = $("#changeusertypeheader").val() == null ? (localStorage.getItem('userselectedaccount') == null ? JSON.parse(localStorage.getItem('userloggedindata'))['selected_account_type'] : localStorage.getItem('userselectedaccount')) : $("#changeusertypeheader").val();
//     postAjaxRequest("POST", "/content/basfeupf/us/formdata.json", appTools, populateTools);
//     $('.eupf-loader').hide();
// });


$(".news-event-selection select").change(function (e) {
    $('.eupf-loader').show();
    var data = JSON.parse(localStorage.getItem('userloggedindata'));
    window.scrollTo(0, 0);
    $('.segment-div').niceSelect('update');
    let seg = e.target.selectedOptions[0].getAttribute('value');
    localStorage.setItem('selectedSegment', seg);
    localStorage.setItem('selectedSegmentName', e.target.selectedOptions[0].text);
    segmentEvents(seg);
    // segmentNews(seg);
    if (localStorage.getItem("dcMultiAccountUser")) {
        localStorage.setItem("businessgroup", data.talendjson.Profile_Data.Account_Types[0].account_type);
        localStorage.setItem("businesssegmentid", data.talendjson.Profile_Data.Account_Types[0].Segment[0].bus_segment_id);
        localStorage.removeItem("dcMultiAccountUser")
    }
    var neweventsegmentid,neweventaccounttype;
    if (data.userinfo != undefined) {

        if (data.talendjson.Profile_Data.Accounts != undefined && data.talendjson.Profile_Data.Accounts != "") {
            neweventsegmentid =  data.talendjson.Profile_Data.Account_Types[0].Segment[0].bus_segment_id;
            neweventaccounttype = data.talendjson.Profile_Data.Account_Types[0].account_type;
        } else {
            neweventsegmentid =  data.userinfo.extension_user_Registration_bs;
            neweventaccounttype = data.userinfo.extension_user_type;
        }
    }

    if(localStorage.getItem('businesssegmentid') != null && localStorage.getItem('businesssegmentid') != ""){
    appTools.segment_id = localStorage.getItem('businesssegmentid');
    }else{
	appTools.segment_id = neweventsegmentid;
    }

    appTools.country = getCountry();
    if (data.talendstatus != 'Linked') {
        appTools.type = "get_app_data_acknowledged_status";
    }
     if(localStorage.getItem('businessgroup') != null && localStorage.getItem('businessgroup') != ""){
       appTools.account_type = localStorage.getItem('businessgroup');
    }else{
	    appTools.account_type = neweventaccounttype;
    }

    var UserGroupRegexp = /^[a-zA-Z0-9-,]+$/;
    if (data.userinfo.hasOwnProperty("groups")) {
        //var usergroup = data.userinfo.groups;
        if (data.userinfo.groups != "") {
            var usergroupname = "";
            var usergroupset = data.userinfo.groups.split(",");
            for (var i = 0; i < usergroupset.length - 1; i++){
                var usergroup = usergroupset[i].split(":");
                usergroupname += usergroup[0] + ",";
            }
            var usergroupcheck = usergroupname.substring(0, usergroupname.length - 1);
            if (usergroupcheck.search(UserGroupRegexp) !== -1)
                { 
                    appTools.view_apps = encodeURIComponent(usergroupname.substring(0, usergroupname.length - 1));
                }
            } else {
            var usergroupset = data.userinfo.groups;
            var usergroupcheck = usergroupset;
            if (usergroupcheck.search(UserGroupRegexp) !== -1)
                { 
                    appTools.view_apps = encodeURIComponent(usergroupset);
                }
           
        }

    }
    postAjaxRequest("POST", "/content/basfeupf/us/formdata.json", appTools, populateTools);
    $('.eupf-loader').hide();
});

function segmentEvents(segID) {
    $('.landing-right.events-section [data-segmentid]').addClass('hide');
    const segEvents = $('.landing-right.events-section [data-segmentid="' + segID + '"]');
    if (segEvents.length > 0) {
        segEvents.removeClass('hide');
        $('.landing-right.events-section').removeClass('hide');
    } else {
        $('.landing-right.events-section').addClass('hide');
    }
}

function segmentNews(segID) {
    $('.owl-carousel').owlCarousel('destroy');
    $('.hero-banner-component .owl-carousel').html('');
    $.each(newsListArray, (ind, ele) => {
        if (ele.getAttribute('data-segmentid') == segID) {
            $('.hero-banner-component .owl-carousel').append(ele)
        }
    })
    newsCarouselInit();
}

function newRedirect(data) {
    let isLms = data.getAttribute("data-lms");
    if (isLms == 'true') {
        let lmsObj = generateLMSRequest();
        lmsObj['id_token'] = JSON.parse(localStorage.getItem("userloggedindata")).login.id_token;
        postAjaxRequest("POST", "/content/basfeupf/us/talendsavelms.json", lmsObj, () => {

            let link = data.getAttribute("data-href");
            window.open(link, '_blank');
            toggleLoader(false);
        });
    } else {
        let link = data.getAttribute("data-href");
        window.open(link, '_self');
    }

}

$(document).ready(function () {
    //$(".news-event-selection select").change();
});