var isUserLogin = false;
function checkUserSignIn() {
    var idToken = getUrlParameter("id_token");
    var userInfo;
    validateTokenURL = "/content/basfeupf/us/en/api.validatetoken.json";

    if (idToken != "") {

        $.ajax({
            "url": validateTokenURL+"?id_token=" + idToken+"&nonce="+localStorage.getItem("nonce"),
            "method": "GET",
            "timeout": 0,
            success: function (result, status, xhr) {
                // var res = JSON.parse(result);
                if (result.isvalidtoken) {
                    localStorage.setItem("id_token", idToken);
                    $("#before-login").hide();
                    $("#after-login").show();
                    userInfo = decodeToken(idToken);
            		var email = userInfo.emails != null ? userInfo.emails[0] : userInfo["signInNames.emailAddress"];
                    $(".user-id").find("span").text(userInfo.given_name + " " + userInfo.family_name);
                    $(".login-floater").find("h2").text(userInfo.given_name + " " + userInfo.family_name);
                    $(".login-floater").find("p").text(email);
                    isUserLogin = true;
            		// create user call
            		// userInsertCall();

                } else {
                    localStorage.removeItem("id_token");
                    $("#before-login").show();
                    $("#after-login").hide();
                    $(".user-id").find("span").text("Sign in");
                    $(".login-floater").hide();
                    $(".login-floater").find("h2").text("");
                    $(".login-floater").find("h2").text("");
                    isUserLogin = false;
                }
            },
            error: function (xhr, status, error) {
                alert("Something went wrong");
                localStorage.removeItem("id_token");
                $("#before-login").show();
                $("#after-login").hide();
                $(".user-id").find("span").text("Sign in");
                $(".login-floater").hide();
                $(".login-floater").find("h2").text("");
                $(".login-floater").find("h2").text("");
                isUserLogin = false;
            }
        });
    } else {
        // check from local storage pending
        var idToken = localStorage.getItem("id_token");
        if (idToken == null || idToken == undefined) {
        //  localStorage.removeItem("id_token");
            $("#before-login").show();
            $("#after-login").hide();
            $(".user-id").find("span").html("Sign in");
            isUserLogin = false;
        } else {
            $.ajax({
                "url": validateTokenURL+"?id_token="+idToken+"&nonce="+localStorage.getItem("nonce"),
                "method": "GET",
                "timeout": 0,
                success: function (result, status, xhr) {
                    // var res = JSON.parse(result);
                    if (result.isvalidtoken) {
                        localStorage.setItem("id_token", idToken);
                        $("#before-login").hide();
                        $("#after-login").show();
                        var userInfo = decodeToken(idToken);
                		var email = userInfo.emails != null ? userInfo.emails[0] : userInfo["signInNames.emailAddress"];
                        $(".user-id").find("span").text(userInfo.given_name + " " + userInfo.family_name);
                        $(".login-floater").find("h2").text(userInfo.given_name + " " + userInfo.family_name);
                        $(".login-floater").find("p").text(email);
                        isUserLogin = true;
                        // create user call
            			userInsertCall();
                    } else {
                        localStorage.removeItem("id_token");
                        $("#before-login").show();
                        $("#after-login").hide();
                        $(".user-id").find("span").text("Sign in");
                        $(".login-floater").hide();
                        $(".login-floater").find("h2").text("");
                        $(".login-floater").find("h2").text("");
                        isUserLogin = false;
                    }
                },
                error: function (xhr, status, error) {
                    alert("Something went wrong");
                    localStorage.removeItem("id_token");
                    $("#before-login").show();
                    $("#after-login").hide();
                    $(".user-id").find("span").text("Sign in");
                    $(".login-floater").hide();
                    $(".login-floater").find("h2").text("");
                    $(".login-floater").find("h2").text("");
                    isUserLogin = false;
                }
            });
        }
    }
}

function getUrlParameter(seachParamName) {

    var queryParamsKeyValues = getAllUrlParameters();

    for (var i = 0; i < queryParamsKeyValues.length; i++) {
        var parameterNameAndValue = queryParamsKeyValues[i].split('=');

        if (parameterNameAndValue[0] === seachParamName) {
            return parameterNameAndValue[1] === undefined ? true :
                decodeURIComponent(parameterNameAndValue[1]);
        }
    }
    return "";
}

function getAllUrlParameters() {
    var queryParams = window.location.search.substring(1);

    if (queryParams.length == 0 && window.location.href.split('#').length > 1) {
        queryParams = window.location.href.split('#')[1];
    }
    return queryParams.length == 0 ? [] : queryParams.split('&');
}

function decodeToken(idToken) {
    var id_token = {};
    if (idToken.length > 0) {
    	id_token = JSON.parse(atob(idToken.split('.')[1]));
    }
    return id_token;
}