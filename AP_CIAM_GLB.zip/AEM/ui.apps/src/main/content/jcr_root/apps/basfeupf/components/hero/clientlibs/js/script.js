var newsListArray = $('.hero-banner-component').find('.item');
// let currentSegmentId = $('.segment-div .selected')[0].getAttribute('data-value');

var newsCarouselInit = function(){
    if($('.hero-banner-component').find('.item').length > 0){
        $('.owl-carousel').owlCarousel({
            loop: true,
            margin: 0,
            autoplay: true,
            nav:false,
            dots: true,
            mouseDrag: false,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1
                },
                767: {
                    items: 1
                }
            }
        })
    }

    
}



// $(document).ready(function() {
//     $('.owl-carousel').owlCarousel({
//         loop: true,
//         margin: 0,
//         autoplay: true,
//         nav:false,
//         dots: true,
//         responsiveClass: true,
//         responsive: {
//             0: {
//                 items: 1
//             },
//             767: {
//                 items: 1
//             }
//         }
//     })
// })
// let currentSegmentId = $('.segment-div .selected')[0].getAttribute('data-value');
// $('.hero-banner-component').find('.item[data-segmentid!="'+currentSegmentId+'"]').remove();
// $(document).ready(function() {
//     $('.owl-carousel').owlCarousel({
//         loop: true,
//         margin: 0,
//         autoplay: true,
//         nav:false,
//         dots: true,
//         responsiveClass: true,
//         responsive: {
//             0: {
//                 items: 1
//             },
//             767: {
//                 items: 1
//             }
//         }
//     })
// })