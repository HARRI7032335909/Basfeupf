// Google address validation api start
var placeSearch, autocomplete;
var componentForm = {
    city: 'long_name',
    zipcode: 'short_name',
    country: 'long_name'
};

function initAutocomplete() {
    var options = {
        types: ['(regions)'],
        componentRestrictions: {
            country: ["us"]
        }
    };
    autocomplete = new google.maps.places.Autocomplete(
        document.getElementById('mailaddress'), {
            types: ['geocode'],
            componentRestrictions: {
                country: ["us"]
            }
        });
    autocomplete.setFields(['address_components']);
    autocomplete.addListener('place_changed', fillInAddress);
}

function fillInAddress() {
    var place = autocomplete.getPlace();
    for (var component in componentForm) {
        document.getElementById(component).value = '';
        document.getElementById(component).disabled = false;
    }
    var val = "";
    for (var i = 0; i < place.address_components.length; i++) {
        var addressType = place.address_components[i].types[0];
        if (addressType == "street_number" || addressType == "route") {
            val += place.address_components[i]["short_name"] + " ";
            document.getElementById("mailaddress").value = val;
        } else if (addressType == "country") {
            val = place.address_components[i]["long_name"];
            document.getElementById("country").value = val;
        } else if (addressType == "locality") {
            val = place.address_components[i]["long_name"];
            document.getElementById("city").value = val;
        } else if (addressType == "administrative_area_level_1") {
            val = place.address_components[i]["short_name"];
            $("#state option[value=" + val + "]").attr("selected", true);
        } else if (addressType == "postal_code") {
            val = place.address_components[i]["short_name"];
            document.getElementById("zipcode").value = val;
        }
    }
}

// Google address validation api end


function callresetpassword(data) {
    var val = data.getAttribute("data-href");
    var appUri = window.location.href;
    val += "&appUri=" + appUri;
    //sessionStorage.setItem("updatepassword", "true");
    window.location.href = val;
}