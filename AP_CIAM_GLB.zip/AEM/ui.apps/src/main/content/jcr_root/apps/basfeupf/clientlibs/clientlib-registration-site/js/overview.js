if (document.getElementById("dc-accountOverview") != null) {

    var accountID, businessSegmentID, hierarchyLevel, contactID;
	accountID = localStorage.getItem("businessaccountid");
	businessSegmentID = parseInt(localStorage.getItem("businesssegmentid"));
	hierarchyLevel = localStorage.getItem("businessgroup");
    contactID = localStorage.getItem("businesscontactid");

    const accountoverviewPayload = {
        "accountId": accountID,
        "hierarchyLevel": hierarchyLevel,
        "accBusSegId": businessSegmentID
    }

    postAjaxRequest("POST", "/content/basfeupf/us/accountoverview.get_account_overview.json", accountoverviewPayload, accountOverviewDetails);

    $(".form-button-area .submit-button").click(function() {

        const accountUpdatePayload = {
            "accountId": accountID,
            "contactId": contactID,
            "accBusSegId": businessSegmentID,
            "hierarchyLevel": hierarchyLevel,
            "type": "all",
            "communications": []
        };

        var communicationsValue = accountUpdatePayload.communications;

        $(".mocInput").each(function () {
            var comItem = {
                "methodOfContact": $(this).attr("data-method"),
                "value": $(this).val()
            };
            communicationsValue.push(comItem);
        });

        $("#update-account-form").validate({ 
            rules: {
                email: {
                    required: true,
                    emailFormat: true
                },
                workphone: {
                    required: true,
                    workPhoneNumberFormat: true
                },
                mobilephone: {
                    required: false,
                    mobilePhoneNumberFormat: true
                }
            },
            messages: {
                email: {
                    required: emptyLabel
                },
                workphone: {
                    required: emptyLabel
                }
            },
            errorClass: 'warning-message empty-warning-message',
            validClass: 'success',
            errorElement: 'div',
            highlight: function(element, errorClass, validClass) {
                $(element).parents("div.field-wrapper").addClass("invalid");
            },
            unhighlight: function(element, errorClass, validClass) {
                $(element).parents("div.field-wrapper").removeClass("invalid");
            }
        });

        let emailValue = $("#emailLabelundefined").val();
        jQuery.validator.addMethod("emailFormat", function (emailValue, element) {
            return this.optional(element) || emailValue.match(/^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i);
        }, emailValidation);

        let workPhoneValue = $("#workphoneundefined").val();
        jQuery.validator.addMethod("workPhoneNumberFormat", function (workPhoneValue, element) {
            return this.optional(element) || workPhoneValue.match(/^\(?[\d\s]{3}-[\d\s]{3}-[\d\s]{4}$/);
        }, phoneValidation);

        let mobilePhoneValue = $("#mobileundefined").val();
        jQuery.validator.addMethod("mobilePhoneNumberFormat", function (mobilePhoneValue, element) {
            return this.optional(element) || mobilePhoneValue.match(/^\(?[\d\s]{3}-[\d\s]{3}-[\d\s]{4}$/);
        }, phoneValidation);

        if($("#update-account-form").valid()) {   
            postAjaxRequest("POST", "/content/basfeupf/us/accountoverview.account_update.json", accountUpdatePayload, accountUpdateDetails);
        } 
        else {
        }
    });

	$(".form-button-area .cancel-button").click(function() {
        $( "#update-account-form" ).validate().resetForm();
        closeModal();
    });
}

function accountUpdateDetails(response) {
    var data = JSON.parse(response);
    $("#workPhoneValue").html(data.primaryContact.phoneNumbers);
    $("#workPhoneValue").attr("href", "tel:"+data.primaryContact.phoneNumbers);
    $("#mobilePhoneValue").html(data.primaryContact.mobilephone);
    $("#mobilePhoneValue").attr("href", "tel:"+data.primaryContact.mobilephone);
    $("#accountEmailValue").html(data.primaryContact.emails);
    $("#accountEmailValue").attr("href", "mailto:"+data.primaryContact.emails);

    if(data.primaryContact.mobilephone == null) {
        $("#overviewMobilePhoneLabel").hide();
    }
    else {
        $("#overviewMobilePhoneLabel").show();
    }
    
    closeModal();
    $("#accountUpdateSuccess").show();
    setTimeout(function() { 
        $("#accountUpdateSuccess").fadeOut();
    }, 5000);
}

var methodOfContactLabel = $("#methodOfContactLabel").attr("data-label");
var phoneLabel = $("#phoneLabel").attr("data-label");
var phoneNumberLabel = $("#phoneNumberLabel").attr("data-label");
var mobileLabel = $("#mobileLabel").attr("data-label");
var mobileNumberLabel = $("#mobileNumberLabel").attr("data-label");
var enableTextMessagingLabel = $("#enableTextMessagingLabel").attr("data-label");
var enableTextMessagingMessage = $("#enableTextMessagingMessage").attr("data-label");
var emailLabel = $("#emailLabel").attr("data-label");
var emailAddressLabel = $("#emailAddressLabel").attr("data-label");
var preferredLabel = $("#preferredLabel").attr("data-label");
var homePhone = $("#homePhone").attr("data-label");
var mobilePhone = $("#mobilePhone").attr("data-label");
var emptyLabel = $("#emptyLabel").attr("data-label");
var phoneValidation = $("#phoneValidation").attr("data-label");
var emailValidation = $("#emailValidation").attr("data-label");
var contactOverviewPageUrl = $("#contactOverviewPageUrl").attr("data-label");

function accountOverviewDetails(datas) {
    var detailsResponse = JSON.parse(datas);

    if(detailsResponse.message?.toLowerCase() == "no account record found") {
        $("#modalContent").insertAfter(".footer").show();
    }
    else {
        $("#doingBusinessAsValue").append(detailsResponse.name);
        $("#doingBusinessCity").append(detailsResponse.physical.city);
        $("#doingBusinessProvince").append(detailsResponse.physical.province);
        $("#accBasfId").append(detailsResponse.accBasfId);
        $("#physicalAddressLine1").append(detailsResponse.physical.line1);
        $("#physicalAddressLine2").append(detailsResponse.physical.line2);
        $("#physicalAddressCity").append(detailsResponse.physical.city);
        $("#physicalAddressProvince").append(detailsResponse.physical.province);
        $("#physicalAddressPostal").append(detailsResponse.physical.postal);
        $("#mailingAddressLine1").append(detailsResponse.mailing.line1);
        $("#mailingAddressLine2").append(detailsResponse.mailing.line2);
        $("#mailingAddressCity").append(detailsResponse.mailing.city);
        $("#mailingAddressProvince").append(detailsResponse.mailing.province);
        $("#mailingAddressPostal").append(detailsResponse.mailing.postal);
        $("#navigatoToLink").attr("href", "https://www.google.com/maps/dir/?api=1&destination="+ detailsResponse.physical.latitude +"," + detailsResponse.physical.longitude);
        $("#accountEmailValue").append(detailsResponse.primaryContact.emails);
        $("#accountEmailValue").attr("href", "mailto:"+detailsResponse.primaryContact.emails);
        $("#workPhoneValue").append(detailsResponse.primaryContact.phoneNumbers);
        $("#workPhoneValue").attr("href", "tel:"+detailsResponse.primaryContact.phoneNumbers);
        $("#mobilePhoneValue").append(detailsResponse.primaryContact.mobilephone);
        $("#mobilePhoneValue").attr("href", "tel:"+detailsResponse.primaryContact.mobilephone);

        //Business Rep details
        if(detailsResponse.businessRepresentative != null || detailsResponse.businessRepresentativeEmail != null || detailsResponse.businessRepresentativePhone != null) {
            $("#business-rep").show();
            $("#businessRepresentativeName").append(detailsResponse.businessRepresentative);
            (detailsResponse.businessRepresentativeEmail != null ? ($("#businessRepresentativeEmail").append(detailsResponse.businessRepresentativeEmail).attr("href", "mailto:"+detailsResponse.businessRepresentativeEmail)) : "");
            (detailsResponse.businessRepresentativePhone != null ? ($("#businessRepresentativePhone").append(detailsResponse.businessRepresentativePhone).attr("href", "tel:"+detailsResponse.businessRepresentativePhone)) : "");
        }

        // Sales Rep details
        if(detailsResponse.salesRepresentative != null || detailsResponse.salesRepresentativeEmail != null || detailsResponse.salesRepresentativePhone != null) {
            $("#sales-rep").show();
            $("#salesRepresentativeName").append(detailsResponse.salesRepresentative);
            (detailsResponse.salesRepresentativeEmail != null ? ($("#salesRepresentativeEmail").append(detailsResponse.salesRepresentativeEmail).attr("href", "mailto:"+detailsResponse.salesRepresentativeEmail)) : ($("#salesRepresentativeEmail").hide()));
            (detailsResponse.salesRepresentativePhone != null ? ($("#salesRepresentativePhone").append(detailsResponse.salesRepresentativePhone).attr("href", "tel:"+detailsResponse.salesRepresentativePhone)) : ($("#salesRepresentativePhone").hide()));
        }

        //Tech Rep details
        if(detailsResponse.techRepresentative != null || detailsResponse.techRepresentativeEmail != null || detailsResponse.techRepresentativePhone != null) {
            $("#tech-rep").show();
            $("#techRepresentativeName").append(detailsResponse.techRepresentative);
            (detailsResponse.techRepresentativeEmail != null ? ($("#techRepresentativeEmail").append(detailsResponse.techRepresentativeEmail).attr("href", "mailto:"+detailsResponse.techRepresentativeEmail)): ($("#techRepresentativeEmail").hide()));
            (detailsResponse.techRepresentativePhone != null ? ($("#techRepresentativePhone").append(detailsResponse.techRepresentativePhone).attr("href", "tel:"+detailsResponse.techRepresentativePhone)): ($("#techRepresentativePhone").hide()));
        }

        //SAM details
        if(detailsResponse.sam != null || detailsResponse.samEmail != null || detailsResponse.samPhone != null) {
            $("#sam-rep").show();
            $("#samName").append(detailsResponse.sam);
            (detailsResponse.samEmail != null ? ($("#samEmail").append(detailsResponse.samEmail).attr("href", "mailto:"+detailsResponse.samEmail)): ($("#samEmail").hide()));
            (detailsResponse.samPhone != null ? ($("#samPhone").append(detailsResponse.samPhone).attr("href", "tel:"+detailsResponse.samPhone)): ($("#samPhone").hide()));
        }

        //Seed Advisor Details
        if(detailsResponse.seedAdvisor != null || detailsResponse.seedAdvisorEmail != null || detailsResponse.seedAdvisorPhone != null) {
            $("#seed-rep").show();
            $("#seedAdvisorName").append(detailsResponse.seedAdvisor);
            (detailsResponse.seedAdvisorEmail != null ? ($("#seedAdvisorEmail").append(detailsResponse.seedAdvisorEmail).attr("href", "mailto:"+detailsResponse.seedAdvisorEmail)): ($("#seedAdvisorEmail").hide()));
            (detailsResponse.seedAdvisorPhone != null ? ($("#seedAdvisorPhone").append(detailsResponse.seedAdvisorPhone).attr("href", "tel:"+detailsResponse.seedAdvisorPhone)) : ($("#seedAdvisorPhone").hide()));
        }

        //Call Center Rep Details
        if(detailsResponse.callCenterRepresentative.C_CustService_MailID != null || detailsResponse.callCenterRepresentative.C_CustService_Phone != null || detailsResponse.callCenterRepresentative.C_CustCare_MailID != null || detailsResponse.callCenterRepresentative.C_CustCarePhone != null) {
            $("#customer-service").show();
            (detailsResponse.callCenterRepresentative.C_CustService_MailID != null ? ($("#customerServiceEmail").append(detailsResponse.callCenterRepresentative.C_CustService_MailID).attr("href", "mailto:"+detailsResponse.callCenterRepresentative.C_CustService_MailID)) : ($("#customerServiceEmail").hide()));
            (detailsResponse.callCenterRepresentative.C_CustService_Phone != null ? ($("#customerServicePhone").append(detailsResponse.callCenterRepresentative.C_CustService_Phone).attr("href", "tel:"+detailsResponse.callCenterRepresentative.C_CustService_Phone)) : ($("#customerServicePhone").hide()));
            (detailsResponse.callCenterRepresentative.C_CustCare_MailID != null ? ($("#customerCareEmail").append(detailsResponse.callCenterRepresentative.C_CustCare_MailID).attr("href", "mailto:"+detailsResponse.callCenterRepresentative.C_CustCare_MailID)) : ($("#customerCareEmail").hide()));
            (detailsResponse.callCenterRepresentative.C_CustCarePhone != null ? ($("#customerCarePhone").append(detailsResponse.callCenterRepresentative.C_CustCarePhone).attr("href", "tel:"+detailsResponse.callCenterRepresentative.C_CustCarePhone)): ($("#customerCarePhone").hide()));
        }

        // Regional Manager details
        if(detailsResponse.regionalManager != null) {
            $("#regional-manager").show();
            $("#regionalManagerName").append(detailsResponse.regionalManager);
        }

        // District Manager details
        if(detailsResponse.districtManager != null || detailsResponse.districtManagerEmail != null || detailsResponse.districtManagerPhone != null) {
            $("#district-manager").show();
            $("#districtManagerName").append(detailsResponse.districtManager);
            (detailsResponse.districtManagerEmail != null ? ( $("#districtManagerEmail").append(detailsResponse.districtManagerEmail).attr("href", "mailto:"+detailsResponse.districtManagerEmail)): ($("#districtManagerEmail").hide()));
            (detailsResponse.districtManagerPhone != null ? ($("#districtManagerPhone").append(detailsResponse.districtManagerPhone).attr("href", "tel:"+detailsResponse.districtManagerPhone)) : ($("#districtManagerPhone").hide()));
        }

        if(detailsResponse.primaryContact.mobilephone == null) {
            $("#overviewMobilePhoneLabel").hide();
        }

        //Modal Popup values
        $("#modalBusinessName").append(detailsResponse.name);
        $("#modalSubTitleCity").append(detailsResponse.physical.city);
        $("#modalSubTitleProvince").append(detailsResponse.physical.province);
        $("#modalSubHierarchy").append(hierarchyLevel);

        var primaryContactId = detailsResponse.primaryContact.cntId;

        // Primary Contact Section in Account Overview Page
        if(detailsResponse.primaryContact.isPrimary == "TRUE") {
            $("#contact-lastname").append(detailsResponse.primaryContact.lastName);
            $("#contact-firstname").append(detailsResponse.primaryContact.firstName);
            $("#userRole").append(detailsResponse.primaryContact.role);

            if(detailsResponse.preferredcommunication.length > 0) {
                $.each(detailsResponse.preferredcommunication, function (key, value) {
                    let UpdatePrimaryContactValues, isPreferred, checkMOC;
                    isPreferred = (value.preferred === "1" ? '<span class="preferred">'+ preferredLabel +'</span>': "");
                    checkMOC = (value.methodOfContact === "Email" ? 'mailto:'+value.value : 'tel:'+value.value);
                    UpdatePrimaryContactValues = $('<div class="contact-method"><span class="label">'+ value.label + isPreferred +'</span><a href='+ checkMOC +'>'+ value.value +'</a></div>');
                    $('#primaryContactValues').append(UpdatePrimaryContactValues);
                });
            }
        }
        else {
            $(".PrimaryContact").hide();
        }

        $(".account-primary a").click(function(event) {
            event.preventDefault();

            const objectToStore = {
                cntID: primaryContactId,
                hirarchyLevel: hierarchyLevel,
                cntAccId: accountID,
            };
        
            localStorage.setItem(
                "currContactMetaInfo",
                JSON.stringify(objectToStore),
            );
            location.href = contactOverviewPageUrl;
        });
    }
}

function openEditModal() {
    document.getElementById('editModal').style.display = 'block';
    $("#emailundefined").val($("#accountEmailValue").html() || '');
    $("#workphoneundefined").val($("#workPhoneValue").html() || '');
    $("#mobileundefined").val($("#mobilePhoneValue").html() || '');

    $(".mocInput").hover(function () {
        if($(this).attr("data-method") !== "EMAIL" && $(this).val().length === 0) {
            $(this).attr("placeholder",  "___-___-____");
        }
    }, function () {
        if($(this).is(":focus")) {
        }
        else {
           $(this).removeAttr("placeholder");
        }
    });

    $(".mocInput").focus(function(){
        if($(this).attr("data-method") !== "EMAIL") {
            if($(this).val().length === 0) {
                $(this).attr("placeholder",  "___-___-____");
            }
            $('input[name="workphone"], input[name="mobilephone"]').keyup(function () {
                this.value = this.value
                    .match(/\d*/g).join('')
                    .match(/(\d{0,3})(\d{0,3})(\d{0,4})/).slice(1).join('-')
                    .replace(/-*$/g, '');
            });
        }
    });
    $(".mocInput").blur(function(){
        $(this).removeAttr("placeholder");
    });
}

function closeModal() {
    $( "#update-account-form" ).validate().resetForm();
    document.getElementById('editModal').style.display = 'none';
}
