function attributeapicall() {
	var xhttp, i, attributemanagement, AMobj;
	xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {

		if (this.readyState == 4 && this.status == 200) {


			try {
				attributemanagement = this.responseText;
				AMobj = JSON.parse(attributemanagement);
				if (AMobj.errormsg.toLowerCase() == "success") {
					$('#attributelistcontent .attributelistcontentlist').remove();
                     $("#preattribute option,#preattributeapp option").remove();
                    $('#preattribute,#preattributeapp').append( '<option value="">- Choose One -</option>' );
					$(".attribute-loader").hide();
					for (i = AMobj.messgeId - 1; i >= 0; i--) {
						var AMrow = '<div class="attributelistcontentlist"><p>' + AMobj.attributesList[i].attrib_name + '</p><ul><li><a href="#attributepopup" class="addnew attributeedit" data-index="' + AMobj.attributesList[i].attrib_id + '"><img class="edit-icon" src="/apps/basfeupf/components/eupfAdmin/clientlibs/images/icon-edit.svg" alt=""> Edit</a></li><li><a href="#attributedeletepopup" data-index="' + AMobj.attributesList[i].attrib_id + '" class="deleteattribute addnew"><img class="delete-icon" src="/apps/basfeupf/components/eupfAdmin/clientlibs/images/icon-delete.svg" alt=""> Delete</a></li><li><a href="#" id="attributePreference" data-index="' + AMobj.attributesList[i].attrib_id + '" data-info="' + AMobj.attributesList[i].attrib_name + '" class=""><img class="delete-icon" src="/apps/basfeupf/components/eupfAdmin/clientlibs/images/icon-preferences.svg" alt=""> Preferences</a></li></ul></div>';
						$("#attributelistcontent").append(AMrow);

                        	 $('#preattribute,#preattributeapp').append( '<option value="' + AMobj.attributesList[i].attrib_id + '">' + AMobj.attributesList[i].attrib_name +'</option>' );

					}

				} else {
					alert(AMobj.errormsg.toLowerCase());
				}

			} catch (e) {
				$("#attributelistcontent").html(e.message);
			}
		}
	};
	xhttp.open("POST", "/content/basfeupf/us/admin.get_attributes_list.json", true);
	xhttp.setRequestHeader("Content-Type", "application/json");
	xhttp.send(null);
}

function decodeLocaleText(str) {
	return decodeURIComponent(str);
}

function attributepreferenceget(attrprefid) {
	$(".attribute-loader").show();
    var xhttpAttrp, i, attrpreferences, AttrPobj;
    xhttpAttrp = new XMLHttpRequest();
    xhttpAttrp.onreadystatechange = function () {
      $("#attrPreferencesForm .preferenceformlabel input").attr("data-index",attrprefid);
      if (this.readyState == 4 && this.status == 200) {
        try {
          attrpreferences = this.responseText;
          AttrPobj = AttrPobj = JSON.parse(attrpreferences);
          if (AttrPobj.errormsg.toLowerCase() == "success") {
            $("#attrpreferencedata .attrpreferencedata").remove();
            $("#attrpreferencedata .pline").remove();

            $(".attribute-loader").hide();
            for (i = AttrPobj.messgeId - 1; i >= 0; i--) {
              var AttrProw =
                '<div class="attrpreferencedata"><p>' +
                decodeLocaleText(AttrPobj.attributeMapLocaleList[i].attribute_locale_name) +
                "</p><p>" +
                AttrPobj.attributeMapLocaleList[i].locale +
                '</p><p><a href="#attrmngmntdeletepopup" class="deleteattribute addnew" id="attrdeletepreferences" data-index="' +
                AttrPobj.attributeMapLocaleList[i].id_attribute_locale_map +
                '"  data-info="' +
                attrprefid +
                '"><img class="delete-icon" src="/apps/basfeupf/components/eupfAdmin/clientlibs/images/icon-delete.svg" alt=""> Delete</a></p></div><div class="pline"></div>';
              $("#attrpreferencedata").append(AttrProw);
            }
          } else {
            alert(AttrPobj.errormsg.toLowerCase());
            $(".attribute-loader").hide();
          }
        } catch (e) {
          $("#attrpreferencedata").html(e.message);
          $(".attribute-loader").hide();
        }
      }
    };
    xhttpAttrp.open(
      "POST",
      "/content/basfeupf/us/admin.get_attribute_locale_map.json",
      true
    );
    xhttpAttrp.setRequestHeader("Content-Type", "application/json");
    xhttpAttrp.send(
      JSON.stringify({
        attribute_id: attrprefid,
      })
    );
  }

$(document).ready(function () {


	attributeapicall();

	// CD 
	$(".tabs-stagecontent").on(
		"click",
		"#attrdeletepreferences",
		function (event) {
		  var id = $(this).attr("data-index");
		  var attrpreferenceid = $(this).attr("data-info");
		  $("#attrmngmntdeletepopup .formbut .done").attr("data-index", id);
		  $("#attrmngmntdeletepopup .formbut .done").attr("data-info", attrpreferenceid);
		}
	  );

	// CD
	$("#attrmngmntdeletepopup .formbut .done").click(function () {
		$(".attribute-loader").show();
		var attrib_id = $(this).attr("data-index");
		var attrPrimaryID = $(this).attr("data-info");
		var xhttp, i, attrprefdeletemanagement, AttrDelResObj;
		xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function () {
		  if (this.readyState == 4 && this.status == 200) {
			try {
			  attrprefdeletemanagement = this.responseText;
			  AttrDelResObj = JSON.parse(  attrprefdeletemanagement);
			  if (AttrDelResObj.errormsg.toLowerCase() == "success") {
				// attributeapicall();
				attributepreferenceget(attrPrimaryID);
			  } else {
				alert(AttrDelResObj.errormsg.toLowerCase());
			  }
			  $(".attribute-loader").hide();
			  $(".cancel").click();
			} catch (e) {
				$(".attribute-loader").hide();
				$(".cancel").click();
			   console.log(e.message);
			}
		  }
		};
		xhttp.open(
		  "POST",
		  "/content/basfeupf/us/admin.delete_attribute_locale_map.json",
		  true
		);
		xhttp.setRequestHeader("Content-Type", "application/json");
		xhttp.send(
		  JSON.stringify({
			id_attribute_locale_map: attrib_id,
		  })
		);
	});

    $(".tabs-stagecontent").on("click", ".deleteattribute", function (event) {
		var id = $(this).attr("data-index");
        $('#attributedeletepopup .formbut .done').attr('data-index', id);

    });

    $("#attributedeletepopup .formbut .done").click(function(){
$(".attribute-loader").show();
		var attrib_id = $(this).attr("data-index");

        	var xhttp, i, attributedeletemanagement, ADobj;
	xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function () {

		if (this.readyState == 4 && this.status == 200) {


			try {
				attributedeletemanagement = this.responseText;
				ADobj = JSON.parse(attributedeletemanagement);
				if (ADobj.errormsg.toLowerCase() == "success") {
$(".attribute-loader").hide();
					attributeapicall();
                    $(".cancel").click();

				} else {
					alert(ADobj.errormsg.toLowerCase());
				}

			} catch (e) {
                alert(e.message);

			}
		}
	};
	xhttp.open("POST", "/content/basfeupf/us/admin.delete_attribute_detail.json", true);
	xhttp.setRequestHeader("Content-Type", "application/json");
	xhttp.send(JSON.stringify({
                    "attrib_id": attrib_id
                }));


    });

	/********edit attribute *********/

	$(".tabs-stagecontent").on("click", ".attributeedit", function (event) {
		event.preventDefault();
		$(".attribute-loader").show();

		var id = $(this).attr("data-index");
		$('#attributeForm .submit').attr('data-index', id);
		var getattribute = "/content/basfeupf/us/admin.get_attributes_list.json"
		editmanagement(id, getattribute);
	});


	function editmanagement(ids, getattributes) {

		var xhttp, i, editmanagement, EAMobj;
		xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function () {

			if (this.readyState == 4 && this.status == 200) {


				try {
					editmanagement = this.responseText;
					EAMobj = JSON.parse(editmanagement);
					if (EAMobj.errormsg.toLowerCase() == "success") {
						$(".attribute-loader").hide();
						for (i = EAMobj.messgeId - 1; i >= 0; i--) {
							if (ids == EAMobj.attributesList[i].attrib_id) {
								$("#attributelabel").val(EAMobj.attributesList[i].attrib_name);
								$("#attributemapid").val(EAMobj.attributesList[i].attrib_map_id);
								$("#attributetype").val(EAMobj.attributesList[i].attrib_type.toLowerCase());
								$("#attributevalue").val(EAMobj.attributesList[i].default_value);
								$("#locale").val(EAMobj.attributesList[i].locale);
								$("#crmattributetype").val(EAMobj.attributesList[i].crm_attrib_type);

								if (EAMobj.attributesList[i].editable == "No") {
									$(".editable input").prop("checked", true);
								} else {
									$(".editable input").prop("checked", false);
								}
							}
						}

					} else {
						alert(EAMobj.errormsg.toLowerCase());
					}

				} catch (e) {
					$("#attributelistcontent").html(e.message);
				}
			}
		};
		xhttp.open("POST", getattributes, true);
		xhttp.setRequestHeader("Content-Type", "application/json");
		xhttp.send(null);

	}
});