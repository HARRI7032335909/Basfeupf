function segmentapicall() {
    $(".attribute-loader").show();
    var xhttp, i, segmentmanagement, SAMobj;
    xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
      if (this.readyState == 4 && this.status == 200) {
        try {
          segmentmanagement = this.responseText;
          SAMobj = JSON.parse(segmentmanagement);
          if (SAMobj.errormsg.toLowerCase() == "success") {
            $("#segmentlistcontent .attributelistcontentlist").remove();
            $("#presegment option").remove();
            $("#presegment").append('<option value="">- Choose One -</option>');
            $(".attribute-loader").hide();
            for (i = SAMobj.messgeId - 1; i >= 0; i--) {
              var AMrow1 =
                '<div class="attributelistcontentlist"><p>' +
                SAMobj.segmentsList[i].segment_name +
                '</p><ul><li><a href="#segmentpopup" class="addnew segmentedit" data-index="' +
                SAMobj.segmentsList[i].segment_id +
                '"><img class="edit-icon" src="/apps/basfeupf/components/eupfAdmin/clientlibs/images/icon-edit.svg" alt=""> Edit</a></li><li><a href="#segmentdeletepopup" data-index="' +
                SAMobj.segmentsList[i].segment_id +
                '" class="deletesegment addnew"><img class="delete-icon" src="/apps/basfeupf/components/eupfAdmin/clientlibs/images/icon-delete.svg" alt=""> Delete</a></li><li> <a onclick="" href="#" id="segmentPreference" data-index="' +
                SAMobj.segmentsList[i].segment_id +
                '"  data-info="' +
                SAMobj.segmentsList[i].segment_name +
                '"><img class="preferences-icon" src="/apps/basfeupf/components/eupfAdmin/clientlibs/images/icon-preferences.svg" alt=""> Preferences</a></li></ul></div>';
              $("#segmentlistcontent").append(AMrow1);

              $("#presegment").append(
                '<option value="' +
                  SAMobj.segmentsList[i].segment_id +
                  '">' +
                  SAMobj.segmentsList[i].segment_name +
                  "</option>"
              );
            }
          } else {
            alert(SMobj.errormsg.toLowerCase());
          }
        } catch (e) {
          $("#segmentlistcontent").html(e.message);
        }
      }
    };
    xhttp.open("POST", "/content/basfeupf/us/admin.get_segments_list.json", true);
    xhttp.setRequestHeader("Content-Type", "application/json");
    xhttp.send(null);
  }
function geteditdata(usergroup){
    //usergroup.getattribute("data-usergroup");
    //usergroup.getattribute("data-userid");
    document.getElementById("autogroupid").value = usergroup.getAttribute("data-user_group_id");
    document.getElementById("groupid").value = usergroup.getAttribute("data-userid");
    document.getElementById("groupname").value = usergroup.getAttribute("data-usergroup");
  }
function usergroupapicall() {
      $(".attribute-loader").show();
      var xhttp, i, usergroupmanagement, SAMobj;
      xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
          try {

              $(".attribute-loader").hide();
              usergroupmanagement = this.responseText;
            SAMobj = JSON.parse(usergroupmanagement);
            if (SAMobj.errormsg.toLowerCase() == "success") {
              $("#usergrouplistcontent .attributelistcontentlist").remove();
              for (i = SAMobj.segmentsList.length-1; i >= 0; i--) {
                var AMrow1 =
                '<div class="attributelistcontentlist"><p>' +
                SAMobj.segmentsList[i].group_name +
                '</p><ul><li><a onclick="geteditdata(this)" data-usergroup="'+SAMobj.segmentsList[i].group_name+'" data-userid="'+SAMobj.segmentsList[i].group_id+'" data-user_group_id="'+SAMobj.segmentsList[i].user_group_id+'" href="#usergroupeditpopup" class="addnew segmentedit" data-index="' +
                SAMobj.segmentsList[i].user_group_id +
                '"><img class="edit-icon" src="/apps/basfeupf/components/eupfAdmin/clientlibs/images/icon-edit.svg" alt=""> Edit</a></li><li><a onclick="getdeldata(this)" data-userid="'+SAMobj.segmentsList[i].user_group_id+'" href="#usergroupdeletepopup" data-index="' +
                SAMobj.segmentsList[i].user_group_id +
                '" class="deletesegment addnew"><img class="delete-icon" src="/apps/basfeupf/components/eupfAdmin/clientlibs/images/icon-delete.svg" alt="" > Delete</a></li></ul></div>';
              $("#usergrouplistcontent").append(AMrow1);

              }

            } else {
              alert(SMobj.errormsg.toLowerCase());
            }
          } catch (e) {
            $("#usergrouplistcontent").html(e.message);
          }
        }
      };
      xhttp.open("POST", "/content/basfeupf/us/admin.get_user_group_list.json", true);
      xhttp.setRequestHeader("Content-Type", "application/json");
      xhttp.send(null);
    }



  function segmentpreferenceget(segprefid) {
    $(".attribute-loader").show();
    var xhttpSp, i, segmentpreferences, SPobj;
    xhttpSp = new XMLHttpRequest();
    xhttpSp.onreadystatechange = function () {
      if (this.readyState == 4 && this.status == 200) {
        try {
          segmentpreferences = this.responseText;
          SPobj = JSON.parse(segmentpreferences);
          if (SPobj.errormsg.toLowerCase() == "success") {
            $("#segpreferencedata .segpreferencedata").remove();
            $("#segpreferencedata .pline").remove();
            $("#segPreferencesForm .preferenceformlabel input").attr(
              "data-index",
              segprefid
            );
            $(".attribute-loader").hide();
            for (i = SPobj.messgeId - 1; i >= 0; i--) {
              var SProw =
                '<div class="segpreferencedata"><p>' +
                SPobj.attributeSegmentMapList[i].attrib_name +
                "</p><p>" +
                SPobj.attributeSegmentMapList[i].account_type +
                '</p><p><a href="#predeletepopup" class="deleteattribute addnew" id="segmentdeletepreferences" data-index="' +
                SPobj.attributeSegmentMapList[i].segment_attrib_id +
                '"  data-info="' +
                segprefid +
                '"><img class="delete-icon" src="/apps/basfeupf/components/eupfAdmin/clientlibs/images/icon-delete.svg" alt=""> Delete</a></p></div><div class="pline"></div>';
              $("#segpreferencedata").append(SProw);
            }
          } else {
            alert(SPobj.errormsg.toLowerCase());
          }
        } catch (e) {
          $("#segpreferencedata").html(e.message);
        }
      }
    };
    xhttpSp.open(
      "POST",
      "/content/basfeupf/us/admin.get_segment_attribute_map.json",
      true
    );
    xhttpSp.setRequestHeader("Content-Type", "application/json");
    xhttpSp.send(
      JSON.stringify({
        segment_id: segprefid,
      })
    );
  }

  $(document).ready(function () {
    $("select[multiple].active.3col").multiselect({
      columns: 1,
      texts: {
        selectAll: "Select all that apply",
        placeholder: "- Choose  -",
      },
      selectAll: true,
    });




    segmentapicall();
    usergroupapicall();
    $(".tabs-stagecontent").on("click", ".deletesegment", function (event) {
      var id = $(this).attr("data-index");
      $("#segmentdeletepopup .formbut .done").attr("data-index", id);
    });

    $(".tabs-stagecontent").on(
      "click",
      "#segmentdeletepreferences",
      function (event) {
        var id = $(this).attr("data-index");
        var segmentid = $(this).attr("data-info");
        $("#predeletepopup .formbut .done").attr("data-index", id);
        $("#predeletepopup .formbut .done").attr("data-info", segmentid);
      }
    );

    $("#predeletepopup .formbut .done").click(function () {
      event.preventDefault();
      $(".attribute-loader").show();
      var segmentdeleteid = $(this).attr("data-index");
      var segmentid = $(this).attr("data-info");

      var xhttp, i, segmentdeletemanagement, SDobj;
      xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
          try {
            segmentdeletemanagement = this.responseText;
            SDobj = JSON.parse(segmentdeletemanagement);
            if (SDobj.errormsg.toLowerCase() == "success") {
              $(".attribute-loader").hide();
              segmentpreferenceget(segmentid);
              $(".cancel").click();
            } else {
              alert(SDobj.errormsg.toLowerCase());
            }
          } catch (e) {
            alert(e.message);
          }
        }
      };
      xhttp.open(
        "POST",
        "/content/basfeupf/us/admin.delete_segment_attribute_map.json",
        true
      );
      xhttp.setRequestHeader("Content-Type", "application/json");
      xhttp.send(
        JSON.stringify({
          segment_attrib_id: segmentdeleteid,
        })
      );
    });

    $("#segmentdeletepopup .formbut .done").click(function () {
      $(".attribute-loader").show();
      var attrib_id = $(this).attr("data-index");

      var xhttp, i, segmentdeletemanagement, SDobj;
      xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
          try {
            segmentdeletemanagement = this.responseText;
            SDobj = JSON.parse(segmentdeletemanagement);
            if (SDobj.errormsg.toLowerCase() == "success") {
              $(".attribute-loader").hide();
              segmentapicall();
              $(".cancel").click();
            } else {
              alert(SDobj.errormsg.toLowerCase());
            }
          } catch (e) {
            alert(e.message);
          }
        }
      };
      xhttp.open(
        "POST",
        "/content/basfeupf/us/admin.delete_segment_detail.json",
        true
      );
      xhttp.setRequestHeader("Content-Type", "application/json");
      xhttp.send(
        JSON.stringify({
          segment_id: attrib_id,
        })
      );
    });

    //user delete api
    /* $("#usergroupdeletepopup .formbut .done").click(function () {
      $(".attribute-loader").show();
      var user_group_name = $(this).attr("data-index");

      var xhttp, i, usergroupdeletemanagement, SDobj;
      xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
          try {
              usergroupdeletemanagement = this.responseText;
            SDobj = JSON.parse(usergroupdeletemanagement);
            if (SDobj.errormsg.toLowerCase() == "success") {
              $(".attribute-loader").hide();
              segmentapicall();
              $(".cancel").click();
            } else {
              alert(SDobj.errormsg.toLowerCase());
            }
          } catch (e) {
            alert(e.message);
          }
        }
      };
      xhttp.open(
        "POST",
        "/content/basfeupf/us/admin.delete_user_group.json",
        true
      );
      xhttp.setRequestHeader("Content-Type", "application/json");
      xhttp.send(
        JSON.stringify({
          User_group: user_group_name,
        })
      );
    });
   */
    /********edit attribute *********/

    $(".tabs-stagecontent").on("click", ".segmentedit", function (event) {
      event.preventDefault();
      $(".attribute-loader").show();

      var id = $(this).attr("data-index");
      $("#segmentForm .submit").attr("data-index", id);
      var getattribute = "/content/basfeupf/us/admin.get_segments_list.json";
      segementeditmanagement(id, getattribute);
    });
  });

  function segementeditmanagement(ids, getattributes) {
    var xhttp, i, segmentmanagement, SMobj;
    xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
      if (this.readyState == 4 && this.status == 200) {
        try {
          segmentmanagement = this.responseText;
          SMobj = JSON.parse(segmentmanagement);
          if (SMobj.errormsg.toLowerCase() == "success") {
            $(".attribute-loader").hide();
            for (i = SMobj.messgeId - 1; i >= 0; i--) {
              if (ids == SMobj.segmentsList[i].segment_id) {
                $("#segmentid").val(SMobj.segmentsList[i].segment_id);
                $("#segmentid").attr("disabled", "disabled");
                $("#segmentname").val(SMobj.segmentsList[i].segment_name);
                $("#segmentdesc").val(SMobj.segmentsList[i].segment_description);
              }
            }
          } else {
            alert(SMobj.errormsg.toLowerCase());
          }
        } catch (e) {
          $("#segmentlistcontent").html(e.message);
        }
      }
    };
    xhttp.open("POST", getattributes, true);
    xhttp.setRequestHeader("Content-Type", "application/json");
    xhttp.send(null);
  }
