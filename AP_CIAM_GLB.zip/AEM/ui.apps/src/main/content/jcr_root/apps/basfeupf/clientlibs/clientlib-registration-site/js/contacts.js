$(function () {
  // CONSTS
   const _PAGE = "_page";
   const _PER_PAGE = "_per_page";
   const _CONTACT_LIST_ARR = "data";
   const _CONTACT_LIST_IDENTIFIER = "list";
   const _CONTACT_LIST_TOTAL_RECORDS = "items";
   const _TOTAL_RECORD_IDENTIFIER = "totalRecords";
   const _NAME_FILTER_PARAM = "firstName";
   const _PHONE_FILTER_PARAM = "phoneNumber";
   const _EMAIL_FILTER_PARAM = "email";
   const _METHOD_OF_CALLING = postAjaxRequest;
   const _TYPE_OF_HTTP_CALL = "POST";
   const _SERVLET_BASE_PATH = `/content/basfeupf/us`;
   const _GET_ALL_CONTACTS_ENDPOINT = `accountoverview.get_account_contacts.json`;
   const _SEARCH_CONTACTS_ENDPOINT = `contactdetails.apply_contact_filter.json`;
   const _CONTACT_ALPHABET_ENDPOINT = `contactdetails.get_contact_alphabet.json`;
 
   // global states
   let pageNumber = 1;
   let perPage = 10;
   let currPrevBtnState = null;
   let currNextBtnState = null;

   // state declaration
   let currSelectedAlphabet = "";
   let currContactState = "ALL";
   const currSearchTermsObj = {"searchByName" : "", "searchByPhone": "", "searchByEmail" : ""};
   const GET_API_NAME_TO_BE_CALLED = {
      "ALL" : { 'endpoint' : _GET_ALL_CONTACTS_ENDPOINT},
      "ALPHABET" : { 'endpoint' : _CONTACT_ALPHABET_ENDPOINT , extraPayload : {"alphabet" : "B"}},
      "SEARCH"  :  { 'endpoint' : _SEARCH_CONTACTS_ENDPOINT , extraPayload : {"alphabet" : "B"}},
   };
   // UTILITY FUNCTIONS
   const isArrayEmpty = (arr) => {
     return (
       arr.length === 0 ||
       arr.every((subArr) => Array.isArray(subArr) && subArr.length === 0)
     );
   };

   function getBusSegID() {
      return Number(localStorage.getItem("businesssegmentid"));
   }
   
   function getAccID() {
      return localStorage.getItem("businessaccountid");
   }

   function fetchCorrespondingPayloadOf(contactStatePassd) {
    let finalPayload = {};
    switch (contactStatePassd) {
     case 'ALL' : 
     finalPayload = {
       startCount: calcItemCount(),
        pageSize: Number(perPage),
        type: "list",
        accountId: getAccID(),
        accBusSegId: getBusSegID(),
        sortBy: "",
        sortOrder: "",
        showArchived: false,
     }; 
     currContactState = "ALL";
     break;
     case 'ALPHABET' : 
     finalPayload = {
       accountId: getAccID(),
       accBusSegId: getBusSegID(),
       alphabet: currSelectedAlphabet,
       startCount: calcItemCount(),
       pageSize: Number(perPage),
       sortBy: "",
       sortOrder: "",
       showArchived: false,
     };
     currContactState = "ALPHABET";
     break;
     case 'SEARCH' : 
     finalPayload = {
      pageNumber: 0,
      pageSize: Number(perPage),
      type: "contacts",
      accountId: getAccID(),
      accBusSegId: getBusSegID(),
      sortBy: "",
      sortOrder: "",
      showArchived: false, // searchByName : "", searchByPhone: "", searchByEmail : ""
      filterPreferredPhone: currSearchTermsObj['searchByPhone'],
      filterPreferredEmail: currSearchTermsObj['searchByEmail'],
      filterContact: currSearchTermsObj['searchByName'],
      startCount: calcItemCount()
    };
     currContactState = "SEARCH";
     break;
    };

    return finalPayload;
   }

   function registerPaginationevents() {
     $("#next-page").on("click", function () {
  
       pageNumber = $("#next-page").attr("data-pageid");
       const api_name = GET_API_NAME_TO_BE_CALLED[currContactState]["endpoint"];
       _METHOD_OF_CALLING(
         _TYPE_OF_HTTP_CALL,
         `${_SERVLET_BASE_PATH}/${api_name}`,
         fetchCorrespondingPayloadOf(currContactState),
         fetchAllContactsTablePlugin,
         { pageNumber: $("#next-page").attr("data-pageid"), perPage, stateOfContact : currContactState},
       );
     });
 
     // PREV btn click
     $("#prev-page").on("click", function () {
       pageNumber = $("#prev-page").attr("data-pageid");
       const api_name = GET_API_NAME_TO_BE_CALLED[currContactState]["endpoint"];
       _METHOD_OF_CALLING(
         _TYPE_OF_HTTP_CALL,
         `${_SERVLET_BASE_PATH}/${api_name}`,
         fetchCorrespondingPayloadOf(currContactState),
         fetchAllContactsTablePlugin,
         { pageNumber: $("#prev-page").attr("data-pageid"), perPage, stateOfContact : currContactState },
       );
     });
   }
 
   function registerPageSizeEvents() {
     $("#pageSize").change(function () {
      const api_name = GET_API_NAME_TO_BE_CALLED[currContactState]["endpoint"];
       perPage = $(this).val();
       pageNumber = 1;
       // Perform fetch call with the selected value
       _METHOD_OF_CALLING(
         _TYPE_OF_HTTP_CALL,
         `${_SERVLET_BASE_PATH}/${api_name}`,
         fetchCorrespondingPayloadOf(currContactState),
         fetchAllContactsTablePlugin,
         { pageNumber: 1, perPage , stateOfContact : currContactState},
       );
     });
   }
 
   function registerPageSelectBoxEvents() {
     $(".page-dropdown").change(function () {
      const api_name = GET_API_NAME_TO_BE_CALLED[currContactState]["endpoint"];
       pageNumber = $(this).val();
       _METHOD_OF_CALLING(
         _TYPE_OF_HTTP_CALL,
         `${_SERVLET_BASE_PATH}/${api_name}`,
         fetchCorrespondingPayloadOf(currContactState),
         fetchAllContactsTablePlugin,
         { pageNumber, perPage, stateOfContact : currContactState },
       );
     });
   }
   
   function emitCurrentContactSaveEvent() {
    const getCurrContactRow = $("a.currentContactID");
    $(getCurrContactRow).click(function (event) {
      event.preventDefault(); // Stop the default behavior of anchor tags

      const cntID = $(this).data("cnt-id");
      const hirarchyLevel = $(this).data("cnt-acc-hierarchy-level");
      const cntAccId = $(this).data("cnt-acc-id");

      const objectToStore = {
        cntID: cntID,
        hirarchyLevel: hirarchyLevel,
        cntAccId: cntAccId,
      };

      localStorage.setItem(
        "currContactMetaInfo",
        JSON.stringify(objectToStore),
      );
      location.href = $('.cxm-list').attr('data-overview-url');
    });
  }

   function generateTable(contactListArr, isNotParsed) {
     let finalTableBodyStr = "";

     isNotParsed
       ? (contactListArr = JSON.parse(contactListArr))
       : (contactListArr = contactListArr);
     console.log(
       "contactListArr on search",
       contactListArr,
       contactListArr.length,
     );

     if (!Array.isArray(contactListArr)) {
       contactListArr = contactListArr["list"];
       $(".pagination-container, #page-size-section").hide();
     } else {
       $(".pagination-container, #page-size-section").show();
     }
 
     for (let i = 0; i < contactListArr.length; i++) {
       let getPrefferedEmail = "";
       let getPrefferedPhoneNumber = "";
       const prefferedCommunicationList =
         contactListArr[i]?.preferredCommunications;

       	const isPrimary =
         contactListArr[i]?.isPrimary?.toLowerCase() === "true"
           ? `<span class="primary-contact-span">Primary</span>`
           : `<span></span>`;
       if (!isArrayEmpty(prefferedCommunicationList)) {
         // GET EMAIL ID FROM OBJ
         const filterOutPrefferedEmail = prefferedCommunicationList.filter(
           (mode) =>
           /email/gi.test(mode["methodOfContact"]) &&
             mode.preferred == 1,
         )[0]?.value;
         getPrefferedEmail = filterOutPrefferedEmail
           ? filterOutPrefferedEmail
           : "";
         console.log("getEmail", getPrefferedEmail);
 
         // get phone number
         const filterOutPrefferedPhone = prefferedCommunicationList.filter(
           (mode) =>
           /phone|mobile/gi.test(mode["methodOfContact"]) &&
            mode.preferred == 1,
         )[0]?.value;
 
         getPrefferedPhoneNumber = filterOutPrefferedPhone
           ? filterOutPrefferedPhone
           : "";
         console.log("getPrefferedPhoneNumber", getPrefferedPhoneNumber);
       }
       const sendTextMSg = getPrefferedPhoneNumber ? `<div class="send-text"><a href="sms:(${getPrefferedPhoneNumber})">Send Text</a></div>` : ``;
 
       // refactoring needed here
       const contactRowStr = `<div class="contact-row">
                                       <section class="contact-info">
                                           <div class="col contact">
                                               <span class="value">
                                               <a href="#" class="currentContactID" data-cnt-id=${contactListArr[i].cntId} data-cnt-acc-hierarchy-level=${contactListArr[i].cntAccHierarchyLevel} data-cnt-acc-id=${contactListArr[i].cntAccId}>${contactListArr[i].firstName}  ${contactListArr[i].lastName}</a>
                                                   <span>${isPrimary}</span>
                                                   <div class="role">${contactListArr[i].role}</div>
                                               </span>
                                           </div>
                                           <div class="col preferred-phone">
                                               <span class="call-now"><a href="tel:(${getPrefferedPhoneNumber})">${getPrefferedPhoneNumber}</a></span>
                                               ${sendTextMSg}
                                           </div>
                                           <div class="col preferred-email">
                                               <span class="value"><a href="mailTo:${getPrefferedEmail}" class="account-name" data-tealium-value="mailto||Simplot.Basf%40mailinator.com" data-tealium-category="contact" data-tealium-action="click mailto-link" data-tealium-type="action">${getPrefferedEmail}</a></span>
                                           </div>
                                       </section>
                                   </div>`;
 
       finalTableBodyStr += contactRowStr;
     }
 
     // load table according to pagesize
     $(".results-wrapper").empty().append(finalTableBodyStr);
     emitCurrentContactSaveEvent();
   }
   function buildPageSelectBox(possibleNoOfpages, pageNo) {
     // Loop to create two select boxes with two random values each
 
     const selectBox = document.createElement("select");
     selectBox.className = "page-dropdown";
     selectBox.id = "pager-dropdown";
     for (let i = 1; i <= possibleNoOfpages; i++) {
       const option = document.createElement("option");
       option.text = `Page ${i} of ${possibleNoOfpages}`;
       option.value = i;
       if (option.value == pageNo) {
         option.selected = true;
         option.setAttribute("selected", "selected");
       }
       selectBox.appendChild(option);
     }
 
     $(".middle-column").empty().append(selectBox);
   }
 
   // CONTACT SEARCH : CHANGE
   function sendSearchCallWith(searchTerm1, searchTerm2, searchTerm3) {
     _METHOD_OF_CALLING(
       _TYPE_OF_HTTP_CALL,
       `${_SERVLET_BASE_PATH}/${_SEARCH_CONTACTS_ENDPOINT}`,
       {
         pageNumber: 0,
         pageSize: Number(perPage),
         type: "contacts",
         accountId: getAccID(),
         accBusSegId: getBusSegID(),
         sortBy: "",
         sortOrder: "",
         showArchived: false,
         filterPreferredPhone: searchTerm2,
         filterPreferredEmail: searchTerm3,
         filterContact: searchTerm1,
         startCount: 0
       },
       fetchAllContactsTablePlugin,
           { pageNumber: 1, perPage: Number(perPage) , stateOfContact : "SEARCH" }
     );
     
   }
 
   // CONTACT SEARCH : CHANGE
   function debounce(func, delay) {
     let timeoutId;
     return function () {
       const context = this;
       const args = arguments;
       clearTimeout(timeoutId);
       timeoutId = setTimeout(() => func.apply(context, args), delay);
     };
   }
   // WATCH ALL INPUT FIELDS FOR BACKSPACE EVENT
 
   function watchSearchFieldForBackspace() {
     $("#search-by-name, #search-by-phone, #search-by-email").keyup(
       function (event) {
         if (event.which === 8) {
           console.log("Backspace key pressed");
           // Add your logic here for handling Backspace key press
           const searchByName = $("#search-by-name").val();
           const searchByPhone = $("#search-by-phone").val();
           const searchByEmail = $("#search-by-email").val();
           const wordLength = 0;
           // fetchData(searchByName, searchByPhone, searchByEmail);
           if (
             searchByName.length == wordLength ||
             searchByPhone.length == wordLength ||
             searchByEmail.length == wordLength
           ) {
             // TODO: Instead of calling api here try to store lastest values in localstorage
             window.setTimeout(() => {
               _METHOD_OF_CALLING(
                 _TYPE_OF_HTTP_CALL,
                 `${_SERVLET_BASE_PATH}/${_GET_ALL_CONTACTS_ENDPOINT}`,
                 {
                   startCount: calcItemCount(),
                   pageSize: Number(perPage),
                   type: "list",
                   accountId: getAccID(),
                   accBusSegId: getBusSegID(),
                   sortBy: "",
                   sortOrder: "",
                   showArchived: false,
                 },
                 fetchAllContactsTablePlugin,
                 { pageNumber, perPage, stateOfContact: "ALL" },
               );
               $(".pagination-container, #page-size-section").show();
             }, 800);
           }
         }
       },
     );
   }
   // CONTACT SEARCH : CHANGE
   function bindSearchEvent() {
     $("#search-by-name, #search-by-phone, #search-by-email").on(
       "keyup",
       debounce(function () {
         const searchByName = $("#search-by-name").val();
         const searchByPhone = $("#search-by-phone").val();
         const searchByEmail = $("#search-by-email").val();
         const wordLength = 2;

         if (
           searchByName.length > wordLength ||
           searchByPhone.length > wordLength ||
           searchByEmail.length > wordLength
         ) {
           sendSearchCallWith(searchByName, searchByPhone, searchByEmail);
           currSearchTermsObj ["searchByName"] = searchByName ;
           currSearchTermsObj["searchByPhone"] = searchByPhone;
           currSearchTermsObj["searchByEmail"] = searchByEmail;
         }
       }, 300),
     ); // Debounce time interval in milliseconds (e.g., 300ms)
   }
 
   function emptyAllFilterFields() {
     $("#search-by-name").val("");
     $("#search-by-phone").val("");
     $("#search-by-email").val("");
   }

   function fetchAllContactsTablePlugin(contacts, paramObj) {
     console.log("call bck paramObj param", paramObj);
     const { pageNumber, perPage, stateOfContact } = paramObj;
     const parseContacts = JSON.parse(contacts);
     console.log("perpage", perPage);
     console.log("pageNumber", pageNumber);
	   stateOfContact ? currContactState = stateOfContact : currContactState = "ALL";
     // BUSINESS LOGIC TO CONSTRUCT WHOLE TABLE WITH PAGINATION AND PAGE SIZE
     // const totalRecordsFound = contacts.totalRecords;
     const totalRecordsFound = parseContacts[_TOTAL_RECORD_IDENTIFIER];
     const possibleNoOfPages = Math.ceil(totalRecordsFound / perPage);
     console.log("no of pages possible servlet", possibleNoOfPages);
     const contactListArr = parseContacts[_CONTACT_LIST_IDENTIFIER];

     // emoty all filter data
     if (currContactState !== "SEARCH") emptyAllFilterFields();
     if(currContactState == "SEARCH")  $(".contact-page-alphabet-holder").removeClass("alphabet-active");
     // call construct table function with the above array of contact list
     generateTable(contactListArr, false);
       if(totalRecordsFound > perPage) {
			     buildPageSelectBox(possibleNoOfPages, pageNumber);
     console.log($(".page-dropdown").val());
     const getCurrSelectedPage = Number($(".page-dropdown").val());
     currPrevBtnState =
       getCurrSelectedPage - 1 > 0 ? getCurrSelectedPage - 1 : null;
     currNextBtnState =
       getCurrSelectedPage + 1 <= possibleNoOfPages
         ? getCurrSelectedPage + 1
         : null;
     console.log("prevBtnWatcher", currPrevBtnState, currNextBtnState);
     registerPageSelectBoxEvents();
     // check for next and prev btn state
     if (typeof currNextBtnState == "number")
       $("#next-page").removeAttr("disabled");
     else $("#next-page").attr("disabled", "disabled");

     if (typeof currPrevBtnState == "number")
       $("#prev-page").removeAttr("disabled");
     else $("#prev-page").attr("disabled", "disabled");

     $("#next-page").attr("data-pageid", currNextBtnState);
     $("#prev-page").attr("data-pageid", currPrevBtnState);
           $('.contact-table-footer').show();
       } else {
			$('.contact-table-footer').hide();
       }


   }
   function callContactAlphabetAPI(sortViaAlphabet) {
     _METHOD_OF_CALLING(
       _TYPE_OF_HTTP_CALL,
       `${_SERVLET_BASE_PATH}/${_CONTACT_ALPHABET_ENDPOINT}`,
       {
         accountId: getAccID(),
         accBusSegId: getBusSegID(),
         alphabet: sortViaAlphabet,
         startCount: 0,
         pageSize: Number(perPage),
         sortBy: "",
         sortOrder: "",
         showArchived: false,
       },
       fetchAllContactsTablePlugin,
           { pageNumber: 1, perPage: Number(perPage) , stateOfContact : "ALPHABET" },
     );
   }

   function resetContactTable(stateOfCnt) {
     _METHOD_OF_CALLING(
       _TYPE_OF_HTTP_CALL,
       `${_SERVLET_BASE_PATH}/${_GET_ALL_CONTACTS_ENDPOINT}`,
       {
         startCount: 0,
         pageSize: Number(perPage),
         type: "list",
         accountId: getAccID(),
         accBusSegId: getBusSegID(),
         sortBy: "",
         sortOrder: "",
         showArchived: false,
       },

       fetchAllContactsTablePlugin,
       { pageNumber: 1, perPage: perPage , stateOfContact : stateOfCnt},
     );
   }

   function initAlphabetEventCapturing() {
     $(".contact-page-alphabet-holder").click(function () {
       const content = $(this).text().trim();
       console.log("Content of clicked span:", content);
       $(".contact-page-alphabet-holder").removeClass("alphabet-active");
       $(this).addClass("alphabet-active");
       emptyAllFilterFields();
       if (content == "All") resetContactTable("ALL");
       else {
        currSelectedAlphabet = content;
        callContactAlphabetAPI(content);
      }
     });
   }

   function generateAlphabets() {
     const alphabetList = $(
       '<div class="alphabet-list"><span class="contact-page-alphabet-holder alphabet-active">All</span></div>',
     );
     for (let i = 65; i <= 90; i++) {
       const letter = String.fromCharCode(i);
       const span = $(
         "<span class='contact-page-alphabet-holder'>" + letter + "</span>",
       );
       alphabetList.append(span);
     }
     $("#alphabetContainer").append(alphabetList);
     initAlphabetEventCapturing();
   }

   // TODO
   function calcItemCount() {
     return perPage * pageNumber - perPage;
   }

   async function initContactPageFlow() {
     generateAlphabets();
     // Make a default inital call with default value wrt pageNumber and Perpage on first load
     _METHOD_OF_CALLING(
       _TYPE_OF_HTTP_CALL,
       `${_SERVLET_BASE_PATH}/${_GET_ALL_CONTACTS_ENDPOINT}`,
       {
         startCount: calcItemCount(),
         pageSize: Number(perPage),
         type: "list",
         accountId: getAccID(),
         accBusSegId: getBusSegID(),
         sortBy: "",
         sortOrder: "",
         showArchived: false,
       },

       fetchAllContactsTablePlugin,
       { pageNumber, perPage, stateOfContact: "ALL" },
     );
     registerPaginationevents();
     registerPageSizeEvents();
     bindSearchEvent();
     watchSearchFieldForBackspace();
   }

   // check if account contact html dom element is present
   if ($("#account-contacts_list").length > 0) {
     // if true then only initiate contact page flow
     initContactPageFlow();
   } 
 });
