var accountDetails;
if(localStorage.hasOwnProperty('userloggedindata') && JSON.parse(localStorage.getItem('userloggedindata')).talendstatus != 'Acknowledged'){
    accountTypeDetails = JSON.parse(localStorage.getItem('userloggedindata')).talendjson.Profile_Data.Account_Types;
    if(accountTypeDetails?.length > 1){
        accountTypeDetails.forEach(element => {
            let option = document.createElement('option');
            option.setAttribute('data-id',element.Segment[0].bus_segment_id);
            option.text = element.account_type;
            $('.customerType').find('select').append(option);
        });

    }
}