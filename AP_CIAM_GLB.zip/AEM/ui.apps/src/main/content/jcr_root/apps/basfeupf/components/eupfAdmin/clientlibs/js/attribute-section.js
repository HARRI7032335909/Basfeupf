/*****************validation***************/


$().ready(function() {

    $.validator.setDefaults({

        submitHandler: function() {

            if ($("#tab-2").css('display') == 'flex') {

                if ($("#segmentpreferencescontent").css('display') != 'flex') {
                    if ($("#segmentForm .submit").attr("data-index") == '') {
                        var segmentid = $("#segmentForm input[name=segmentid]").val();
                    } else {
                        var segmentid = $("#segmentForm .submit").attr("data-index");
                    }

                    var segmentname = $("#segmentForm input[name=segmentname]").val();
                    var segmentdescription = $("#segmentForm textarea[name=segmentdesc]").val();

                    var segment_InfoObj = {
                        "segment_id": segmentid,

                        "segment_name": segmentname,
                        "segment_description": segmentdescription,

                    }

                    var xhttpinsert, insertsegmentmanagement, SAMobj;
                    xhttpinsert = new XMLHttpRequest();
                    xhttpinsert.onreadystatechange = function() {

                        if (this.readyState == 4 && this.status == 200) {


                            try {
                                insertsegmentmanagement = this.responseText;
                                SAMobj = JSON.parse(insertsegmentmanagement);
                                if (SAMobj.errormsg.toLowerCase() == "success") {
                                    $(".attribute-loader").hide();

                                    $(".cancel").click();
                                    segmentapicall();


                                } else {
                                    $(".attribute-loader").hide();
                                    alert(SAMobj.errormsg);

                                }

                            } catch (e) {
                                $(".attribute-loader").hide();
                                $("#segmentlistcontent").html(e.message);

                            }
                        }
                    };
                    if ($("#segmentForm .submit").attr("data-index") == '') {
                        xhttpinsert.open("POST", "/content/basfeupf/us/admin.insert_segment_detail.json", true);
                    } else {
                        xhttpinsert.open("POST", " /content/basfeupf/us/admin.update_segment_detail.json", true);
                    }
                    xhttpinsert.setRequestHeader("Content-Type", "application/json");
                    xhttpinsert.send(JSON.stringify(segment_InfoObj));


                } else {

                    $(".attribute-loader").show();
                    var segmentattribute = $("#segPreferencesForm select[name=preattribute]").val();
                    var segmentcustomertype = $(".ms-has-selections span").text();
                    var segmentpreid = $("#segPreferencesForm .preferenceformlabel input").attr("data-index");

                    var segmentPre_InfoObj = {
                        "segment_id": segmentpreid,
                   
                        "attrib_id": segmentattribute,

                        "account_type": segmentcustomertype

                    }


                    var xhttpspinsert, insertsegmentpmanagement, SPAMobj;
                    xhttpspinsert = new XMLHttpRequest();
                    xhttpspinsert.onreadystatechange = function() {

                        if (this.readyState == 4 && this.status == 200) {


                            try {
                                insertsegmentpmanagement = this.responseText;
                                SPAMobj = JSON.parse(insertsegmentpmanagement);
                                if (SPAMobj.errormsg.toLowerCase() == "success") {

                                    segmentpreferenceget(segmentpreid);
                                    $(".attribute-loader").hide();
                                    $("#segPreferencesForm")[0].reset();
                                    $('select[multiple]').multiselect('reset');



                                } else {
                                    $(".attribute-loader").hide();
                                    alert(SPAMobj.errormsg);

                                }

                            } catch (e) {
                                $(".attribute-loader").hide();
                                $("#segmentlistcontent").html(e.message);

                            }
                        }
                    };

                    xhttpspinsert.open("POST", " /content/basfeupf/us/admin.insert_segment_attribute_map.json", true);
                    xhttpspinsert.setRequestHeader("Content-Type", "application/json");
                    xhttpspinsert.send(JSON.stringify(segmentPre_InfoObj));

                }


            }


            if ($("#tab-3").css('display') == 'flex') {


                if ($("#applicationpreferencescontent").css('display') != 'flex') {

                    if ($('#applicationForm .editable input[type=checkbox]').prop('checked')) {
                        var editable = "Yes"
                    } else {
                        var editable = "No"
                    }

                    var applicationname = $("#applicationForm input[name=applicationname]").val();
                    var appredirecturl = $("#applicationForm input[name=appreurl]").val();
                    var appimageurl = $("#applicationForm input[name=appimageurl]").val();
                    var appdescription = $("#applicationForm textarea[name=appdesc]").val();
                    var clientsecret = $("#applicationForm input[name=clientsecret]").val();
                    var clientid = $("#applicationForm input[name=clientid]").val();
                    var apptype = $("#applicationForm select[name=apptype]").val();
                    var windowopenoption = $("#applicationForm select[name=openoption]").val();
                    var responsemode = $("#applicationForm input[name=responsemode]").val();
                    var responsetype = $("#applicationForm input[name=responsetype]").val();
                    var scope = $("#applicationForm input[name=scope]").val();
                    var state = $("#applicationForm input[name=state]").val();
                    var theme = $("#applicationForm input[name=theme]").val();
                    var policy = $("#applicationForm input[name=policy]").val();
                    var azurelink = $("#applicationForm input[name=azurelink]").val();
                    var nonce = $("#applicationForm input[name=nonce]").val();
                    var linkedstatus = $("#applicationForm select[name=linkedstatus]").val();
                    var app_id = $("#applicationForm .submit").attr("data-index");

                    var group_id = "";
                    var user_group = $("#ms-list-3 span").text();
                    var a = user_group.split(",");
                    if (a.length > 1) {
                        for (var i = 0; i < a.length; i++) {
                            for (var b = 0; b < $("#ms-list-3 ul li").length; b++) {
                                if (($("#ms-list-3 ul li label input")[b].title) == (a[i].trimStart())) {
                                    group_id += $("#ms-list-3 ul li label input")[b].value + ",";
                                }
                            }
                        }
                        group_id = group_id.slice(0, -1);
                    } else {
                        for (var i = 0; i < $("#ms-list-3 ul li").length; i++) {
                            if (($("#ms-list-3 ul li label input")[i].title) == a[0]) {
                                group_id = $("#ms-list-3 ul li label input")[i].value;
                            }
                        }
                    }


                    if ($('.apppopuplist .isexternal input[type=checkbox]').prop('checked')) {

                        var isexternal = "Yes";

                    } else {
                        var isexternal = "No";
                    }
                    var applogourl = $("#applicationForm input[name=applogourl]").val();
                    var useState = $('.apppopuplist .appstate input[type=checkbox]').prop('checked') ? 'Yes' : 'No';
                    var appState = $('.apppopuplist .appState input[type=checkbox]').prop('checked') ? 'Yes' : 'No';
                    var b2cNonapplicable = $('#applicationForm .b2cdisabled input[type=checkbox]').prop('checked') ? 'Yes' : 'No';
                    var $selected = $('#selectCountries').find('option:selected');

                    var $selectedCountryCode='';
                    for(var i = 0; i < $selected.length; i++) {
                       $selectedCountryCode = $selected[i]['value'] + "," + $selectedCountryCode;
                    }

                    var application_InfoObj = {
                        "app_id": app_id,
                        "app_name": applicationname,
                        "app_link": appredirecturl,
                        "app_image_path": appimageurl,
                        "app_logo": applogourl,
                        "app_description": appdescription,
                        "client_secret": clientsecret,
                        "client_id": clientid,
                        "response_mode": responsemode,
                        "response_type": responsetype,
                        "scope": scope,
                        "state": state,
                        "theme": theme,
                        "policy": policy,
                        "azure_link": azurelink,
                        "nonce": nonce,
                        "app_type": apptype,
                        "linked_status": linkedstatus,
                        "active": editable,
                        "group_role": group_id,
                        "group_check": isexternal,
                        "use_state": useState,
                        "app_state":appState,
                        "country" :$selectedCountryCode.slice(0, -1),
                        "b2c_non_applicable": b2cNonapplicable,
                        "window_open_option": windowopenoption
                    }

                    var xhttappinsert, insertappinsertmanagement, APPobj;
                    xhttappinsert = new XMLHttpRequest();
                    xhttappinsert.onreadystatechange = function() {

                        if (this.readyState == 4 && this.status == 200) {


                            try {
                                insertappinsertmanagement = this.responseText;
                                APPobj = JSON.parse(insertappinsertmanagement);

                                if (APPobj.errormsg.toLowerCase() == "success") {
                                    $(".attribute-loader").hide();

                                    $(".cancel").click();
                                    applicationapicall();


                                } else {
                                    $(".attribute-loader").hide();
                                    alert(APPobj.errormsg);

                                }

                            } catch (e) {
                                $(".attribute-loader").hide();
                                $("#applistcontent").html(e.message);
                            }
                        }
                    };
                    if ($("#applicationForm .submit").attr("data-index") == '') {

                        xhttappinsert.open("POST", "/content/basfeupf/us/admin.insert_app_detail.json", true);
                        unselectoption();
                    } else {
                        var data = $("#usergroup").attr("data-usergroup");
                        if (isexternal == "Yes" && group_id == "") {
                            alert("Please select atleast one Usergroup.");
                            return false;
                        } else {
                            xhttappinsert.open("POST", " /content/basfeupf/us/admin.update_app_detail.json", true);
                            unselectoption();
                        }

                    }

                    xhttappinsert.setRequestHeader("Content-Type", "application/json");
                    xhttappinsert.send(JSON.stringify(application_InfoObj));



                } else {

                    $(".attribute-loader").show();
                    var appattribute = $("#applicationpreferenceForm select[name=appattribute]").val();
                    var appsegment = $("#applicationpreferenceForm select[name=appsegment]").val();
                    //var appacoounttype = $(".ms-has-selections span").text();
                    var appacoounttype = $("#ms-list-2 span").text();
                    //var applinkedstatus =$("#applicationpreferenceForm select[name=applinkedstatus]").val();
                    var approle = $("#applicationpreferenceForm select[name=role]").val();
                    //var group_role = $("#ms-list-3 span").text();

                    if ($('#applicationpreferenceForm .preeditable input[type=checkbox]').prop('checked')) {

                        var editable = "Yes";

                    } else {
                        var editable = "No";
                    }

                    /*if ($('#applicationpreferenceForm .isexternal input[type=checkbox]').prop('checked')) {

                    	var isexternal = "Yes";

                    } else {
                    	var isexternal = "No";
                    }*/



                    var apppreid = $("#applicationpreferenceForm .preferenceformlabel input").attr("data-index");
                    var $selectedLanguage = $('#appPreferedLanguage').find('option:selected');

                    var $selectedAppLanguage='';
                    for(var i = 0; i < $selectedLanguage.length; i++) {
                       $selectedAppLanguage = $selectedLanguage[i]['value'] + "," + $selectedAppLanguage;
                    }


                    var appPre_InfoObj = {

                        "app_id": apppreid,
                        "segment_id": appsegment,
                        "attrib_id": appattribute,
                        "account_type": appacoounttype,
                        //"role": approle,
                        //"linked_status": applinkedstatus,
                        "mandatory_attrib": editable,
                        //"group_role":group_role,
                        //"group_check": isexternal,
                        "language": $selectedAppLanguage.slice(0, -1)

                    }


                    var xhttpappinsert, insertapppmanagement, APAMobj;
                    xhttpappinsert = new XMLHttpRequest();
                    xhttpappinsert.onreadystatechange = function() {

                        if (this.readyState == 4 && this.status == 200) {


                            try {
                                insertapppmanagement = this.responseText;
                                APAMobj = JSON.parse(insertapppmanagement);
                                if (APAMobj.errormsg.toLowerCase() == "success") {
                                    applicationpreferenceget(apppreid)

                                    $(".attribute-loader").hide();
                                    $("#applicationpreferenceForm")[0].reset();
                                    $('select[multiple]').multiselect('reset');



                                } else {
                                    $(".attribute-loader").hide();
                                    alert(APAMobj.errormsg);

                                }

                            } catch (e) {
                                $(".attribute-loader").hide();
                                $("#apppreferencedata").html(e.message);

                            }
                        }
                    };

                    xhttpappinsert.open("POST", " /content/basfeupf/us/admin.insert_app_segment_attribute_map.json", true);
                    xhttpappinsert.setRequestHeader("Content-Type", "application/json");
                    xhttpappinsert.send(JSON.stringify(appPre_InfoObj));

                }



            }

            if ($("#tab-1").css('display') == 'flex') {
                if ($("#attributepreferencescontent").css('display') != 'flex') {
                    $(".attribute-loader").show();
                    //courseInformation
                    if ($('.editable input[type=checkbox]').prop('checked')) {
                        var editable = "No"
                    } else {
                        var editable = "Yes"
                    }
    
                    var attributelabel = $("#attributeForm input[name=attributelabel]").val();
                    var attributetype = $("#attributeForm select[name=attributetype]").val();
                    var attributevalue = $("#attributeForm input[name=attributevalue]").val();
                    var attributemapid = $("#attributeForm input[name=attributemapid]").val();
    
                    var locale = $("#attributeForm select[name=locale]").val();
                    var crmattributetype = $("#attributeForm select[name=crmattributetype]").val();
                    var updateindex = $("#attributeForm .submit").attr("data-index");
                    var attribute_InfoObj = {
                        "attrib_id": updateindex,
                        "attrib_name": attributelabel,
                        "attrib_type": attributetype,
                        "editable": editable,
                        "attrib_map_id": attributemapid,
                        "default_value": attributevalue,
                        "crm_attrib_type": crmattributetype,
                        "locale": locale
                    }
    
                    var xhttpinsert, insertattributemanagement, IAMobj;
                    xhttpinsert = new XMLHttpRequest();
                    xhttpinsert.onreadystatechange = function() {
    
                        if (this.readyState == 4 && this.status == 200) {
    
    
                            try {
                                insertattributemanagement = this.responseText;
                                IAMobj = JSON.parse(insertattributemanagement);
                                if (IAMobj.errormsg.toLowerCase() == "success") {
                                    $(".attribute-loader").hide();
    
                                    $(".cancel").click();
                                    attributeapicall();
    
    
                                } else {
                                    $(".attribute-loader").hide();
                                    alert(IAMobj.errormsg);
    
                                }
    
                            } catch (e) {
                                $(".attribute-loader").hide();
                                $("#attributelistcontent").html(e.message);
    
                            }
                        }
                    };
                    if ($("#attributeForm .submit").attr("data-index") == '') {
                        xhttpinsert.open("POST", "/content/basfeupf/us/admin.insert_attribute_detail.json", true);
                    } else {
                        xhttpinsert.open("POST", " /content/basfeupf/us/admin.update_attribute_detail.json", true);
                    }
                    xhttpinsert.setRequestHeader("Content-Type", "application/json");
                    xhttpinsert.send(JSON.stringify(attribute_InfoObj));
                } else {
                    $(".attribute-loader").show();
                    var attribute_id = $("#attrPreferencesForm .preferenceformlabel input[type=submit]").attr("data-index");
                    var attribute_name = $("#attrPreferencesForm input[name=attrtitle]").val();
                    var attribute_locale_name = encodeURIComponent($("#attrPreferencesForm input[name=localetext]").val());
                    var localeLang = $("#attrPreferencesForm select[name=attrlocaleoption]").val();

                    var attrMngmntPre_InfoObj = {
                        "attribute_id": attribute_id,
                        "attribute_name": attribute_name,
                        "attribute_locale_name": attribute_locale_name,
                        "locale": localeLang
                    }

                    var xhttpspinsert, rawResponse, AttrPAMobj;
                    xhttpspinsert = new XMLHttpRequest();
                    xhttpspinsert.onreadystatechange = function() {

                        if (this.readyState == 4 && this.status == 200) {
                            try {
                                rawResponse = this.responseText;
                                AttrPAMobj = JSON.parse(rawResponse);
                                if (AttrPAMobj.errormsg.toLowerCase() == "success") {

                                    attributepreferenceget(attribute_id);
                                    $(".attribute-loader").hide();
                                    $("#attrPreferencesForm #attrlocaleoption").val("");
                                    $("#attrPreferencesForm #localetext").val("");                 
                                    // $('select[multiple]').multiselect('reset');
                                } else {
                                    $(".attribute-loader").hide();
                                    alert(AttrPAMobj.errormsg);

                                }

                            } catch (e) {
                                $(".attribute-loader").hide();
                                // $("#attributelistcontent").html(e.message);
                                alert(e.message);

                            }
                        }
                    };

                    xhttpspinsert.open("POST", "/content/basfeupf/us/admin.insert_attribute_locale_map.json", true);
                    xhttpspinsert.setRequestHeader("Content-Type", "application/json");
                    xhttpspinsert.send(JSON.stringify(attrMngmntPre_InfoObj));
                }
            } 

        }


    });

    $(document).ready(function () {
        $('#disabledFieldsCheckbox').change(function () {
            disabledFieldCheckbox();
        });
    })

    jQuery.validator.addMethod("lettersonly", function(value, element) {
        return this.optional(element) || /^[a-z\s]+$/i.test(value);
    }, "Only alphabetical characters");


    var validator = $("#attributeForm").validate({
        rules: {
            attributelabel: {
                lettersonly: true,
                required: true
            },
            attributetype: "required",
            attributemapid: "required",
            locale: "required",
            crmattributetype: "required"
        },
        messages: {

            attributelabel: {
                lettersonly: "Please enter Only alphabetical characters",
                required: "Please enter Atrribute Label"
            },
            attributetype: "Please select Attribute Type",
            attributemapid: "Please enter Attribute Id",
            locale: "Please select Locale",
            crmattributetype: "Please Select CRM Attribute Type",
        }
    });


    /****segment form****/

    var segmentvalidator = $("#segmentForm").validate({
        rules: {
            segmentid: {
                required: true,
                digits: true
            },
            segmentname: {
                required: true,
                maxlength: 100
            },
            segmentdesc: {
                required: true,
                maxlength: 100
            }
        },
        messages: {

            segmentid: {
                digits: "Please enter Only Digits",
                required: "Please enter Segement ID"
            },
            segmentname: {
                required: "Please enter Segement Name",
                maxlength: "Please enter not  more than 100 characters."
            },
            segmentdesc: {
                required: "Please enter Segement Description",
                maxlength: "Please enter not  more than 100 characters."
            }

        }
    });

    /****User group form*****

	var usergroupvalidator = $("#UserGroupForm").validate({
		rules: {
			newgroupname: {
				required: true,
				maxlength: 100
			}
		},
		messages: {
			newgroupname: {
				required: "PLease enter User Group Name",
				maxlength: "Please enter not  more than 100 characters."
			}
		}
	}) */
    /*********application***********/



    var appvalidator = $("#applicationForm").validate({
        ignore: [],
        rules: {
             selectCountries: {
                needsSelection: true,
                required: true
            },
            applicationname: "required",
            appreurl: "required",
            appimageurl: "required",
            appdesc: {
                required: true,
                maxlength: 100
            },
            openoption: "required",
            clientid: "required",
            apptype: "required",
            selectCountries: "required"

        },
        messages: {
            selectcountries:{
                needsSelection: "Please enter Only alphabetical characters",
                required: "Please enter Atrribute Label"
            },
            applicationname: "Please enter Application Name",
            appreurl: "Please enter Application Redirect URL",
            appimageurl: "Please enter Application Image URL",
            appdesc: {
                required: "Please enter Short Description",
                maxlength: "Please enter not  more than 100 characters."
            },
            openoption: "Please select tab",
            clientid: "Please enter Client ID",
            apptype: "Please select App Type",
            selectCountries: "Please select country"

        }
    });


    var segPreferences = $("#segPreferencesForm").validate({
        ignore: [],
        rules: {
            preattribute: "required",
            prect: "required"

        },
        messages: {

            preattribute: "Please enter Attribute",
            prect: "Please enter Customer Type"



        }
    });

    var attrMngmntPreferences = $("#attrPreferencesForm").validate({
        ignore: [],
        rules: {
            localetext: "required",
            attrlocaleoption: "required"

        },
        messages: {

            localetext: "Please enter locale text",
            attrlocaleoption: "Please select a locale"



        }
    });

    var appprefvalidator = $("#applicationpreferenceForm").validate({
        ignore: [],
        rules: {
            appattribute: "required",
            appsegment: "required",
            prect: "required",
            appPreferedLanguage: "required"

        },
        messages: {

            appattribute: "Please select Attribute Name",
            appsegment: "Please select Segement Name",
            prect: "Please select Account Type",
            appPreferedLanguage: "Please select Language"
        }
    });


    $(".eupfAdmin").on("click", ".closepopup,.cancel", function(event) {

        event.preventDefault();
        validator.resetForm();
        segmentvalidator.resetForm();
        $("#segmentid").removeAttr("disabled");
        appvalidator.resetForm();
        $(".popupcontent,.popbackground").hide();
        $(window).scrollTop(window.body_scroll_pos);

    });


    /*******validation********/


    $("#attributetype").change(function() {
        var val = $(this).val();
        if (val == "text") {
            $("#attributevalue").attr("placeholder", "Please enter attribute value");
        } else if (val == "multiselect") {
            $("#attributevalue").attr("placeholder", "Please select multiple options");
        } else if (val == "select") {
            $("#attributevalue").attr("placeholder", "Please select option");
        } else if (val == "radio") {
            $("#attributevalue").attr("placeholder", "Please select option");
        } else if (val == "") {
            $("#attributevalue").attr("placeholder", "Please enter attribute value");
        }
    });


    $(".tabs-stagecontent").on("click", ".addnew", function(event) {
        event.preventDefault();
        $("#attributeForm")[0].reset();
        $("#segmentForm")[0].reset();
        $("#applicationForm")[0].reset();

        $('.popupcontent').hide();
        window.body_scroll_pos = $(window).scrollTop();
        window.scrollTo(0, 0);

        $($(this).attr('href')).show();
        $('.popbackground').show();
    });

    $(".newattribute").click(function() {
        $('#attributeForm .submit').attr('data-index', '');

    });

    $(".newsegment").click(function() {
        $('#segmentForm .submit').attr('data-index', '');

    });

    $(".newapplication").click(function() {
        $('#applicationForm .submit').attr('data-index', '');

    });


    /**********preferences***********/
    $(".tabs-stagecontent").on("click", "#applicationPreference", function(e) {

        e.preventDefault();
        $("#applicationpreferencescontent").css("display", "flex");
        $(".preferencebackcontent").css("display", "none");
        $("body").addClass("colorchange");
        var appprefid = $(this).attr("data-index");
        var apppreftitle = $(this).attr("data-info");
        $("#apptitle").text(apppreftitle);
        applicationpreferenceget(appprefid);

    });

    $(".tabs-stagecontent").on("click", ".preback a", function(e) {

        e.preventDefault();
        $("#applicationpreferenceForm")[0].reset();
        $("#applicationpreferenceForm select[multiple]").multiselect('reset');
        $("#applicationpreferencescontent").css("display", "none");
        $(".preferencebackcontent").css("display", "flex");
        $("body").removeClass("colorchange");
    });

    /**
     * Attribute Preference Button Behaviour
    */

    $(".tabs-stagecontent").on("click", "#attributePreference", function(e) {
        e.preventDefault();
        $("#attributepreferencescontent").css("display", "flex");
        $(".attributebackcontent").css("display", "none");
        $("body").addClass("colorchange");
        var attrprefid = $(this).attr("data-index");
        var attrpreftitle = $(this).attr("data-info");
        $("#attributetitle").text(attrpreftitle);
        $("#attrPreferencesForm #attrtitle").val(attrpreftitle);
        attributepreferenceget(attrprefid);
    });

    $(".tabs-stagecontent").on("click", ".attrpreback a", function(e) {

        e.preventDefault();
        $("#attrPreferencesForm")[0].reset();
        $("#attrPreferencesForm label.error").css("display", "none");
        $("#attributepreferencescontent").css("display", "none");
        $(".attributebackcontent").css("display", "flex");
        $("body").removeClass("colorchange");
    });

    $(".tabs-stagecontent").on("click", "#segmentPreference", function(e) {

        e.preventDefault();
        $("#segmentpreferencescontent").css("display", "flex");
        $(".segmentbackcontent").css("display", "none");
        $("body").addClass("colorchange");
        var segprefid = $(this).attr("data-index");
        var segpreftitle = $(this).attr("data-info");
        $("#segmentitle").text(segpreftitle);
        segmentpreferenceget(segprefid);

    });

    $(".tabs-stagecontent").on("click", ".segpreback a", function(e) {

        e.preventDefault();
        $("#segmentpreferencescontent").css("display", "none");
        $(".segmentbackcontent").css("display", "flex");
        $("body").removeClass("colorchange");
    });


    /********multiselect ********/
    /***tabs********/

    $('.tabs-nav a').on('click', function(event) {
        event.preventDefault();

        $('.tab-active').removeClass('tab-active');
        $(this).parent().addClass('tab-active');
        $('.tabs-stage .tabs-stagecontent').hide();
        $($(this).attr('href')).show();
        if ($("#tab-3").css('display') == 'flex' && $("#applicationpreferencescontent").css('display') == 'flex') {

            $("body").addClass("colorchange");
        } else if ($("#tab-2").css('display') == 'flex' && $("#segmentpreferencescontent").css('display') == 'flex') {

            $("body").addClass("colorchange");
        } else if ($("#tab-1").css('display') == 'flex' && $("#attributepreferencescontent").css('display') == 'flex') {

            $("body").addClass("colorchange");
        } else {
            $("body").removeClass("colorchange");

        }
    });

    $('.tabs-nav a:first').trigger('click');
});

function postAjaxRequestAdmin(method, endpoint, obj, callback) {
    toggleLoader(true);
    obj = JSON.stringify(obj);
    var xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function() {
        if (this.status == 200 & this.readyState == 4) {
            toggleLoader(false);
            try {
                callback(this.responseText);
            } catch (err) {

            }
        }
    };

    xhr.open(method, endpoint, true);
    xhr.setRequestHeader('Accept', 'application/json');
    xhr.send(obj);
}

function insertusergroupApi() {
    if ($('#newgroupname').val() !== "" && $('#newgroupid').val() !== "") {
        var insert_user_group = {
            "group_id": $('#newgroupid').val(),
            "group_name": $('#newgroupname').val()
        }
        postAjaxRequestAdmin("POST", "/content/basfeupf/us/admin.insert_user_group.json", insert_user_group, "");

        $(".attribute-loader").hide();
        document.querySelector('.popbackground').style.display = "none";
        usergroupapicall();
        document.querySelector('.popbackground').style.display = "none";
    } else {
        document.getElementById("usergroupid-error").style.display = "block";
        document.getElementById("usergroupname-error").style.display = "block";
    }


}
/* function geteditdata(usergroup){

	//usergroup.getattribute("group");
	//usergroup.getattribute("data-userid");
	document.getElementById("groupid").value = usergroup.getAttribute("data-userid");
	document.getElementById("groupname").value = usergroup.getAttribute("data-usergroup");
} */
function updateApi() {
    if ($('#groupname').val() == "" && $('#groupid').val() == "") {
        document.getElementById("userupdategroup-error").style.display = "block";
        document.getElementById("userupdateid-error").style.display = "block";
    } else {
        var insert_user_group = {
            "user_group_id": $('#autogroupid').val(),
            "group_name": $('#groupname').val(),
            "group_id": $('#groupid').val()
        }
        postAjaxRequestAdmin("POST", "/content/basfeupf/us/admin.update_user_group.json", insert_user_group, "");

        $(".attribute-loader").hide();
        document.getElementById("usergroupeditpopup").style.display = "none";
        usergroupapicall();
        document.querySelector('.popbackground').style.display = "none";
    }
}
var delgrpId = "";

function getdeldata(usergroup) {

    var groupid = usergroup.getAttribute("data-userid");
    delgrpId = groupid;
}

function deleteApi() {

    var delete_user_group = {
        "user_group_id": delgrpId
    }
    postAjaxRequestAdmin("POST", "/content/basfeupf/us/admin.delete_user_group.json", delete_user_group, "");
    $(".attribute-loader").hide();
    document.getElementById("usergroupdeletepopup").style.display = "none";
    usergroupapicall();
    document.querySelector('.popbackground').style.display = "none";

}

function unselectoption() {
    $("#usergroup option:selected").prop("selected", false);
    $("#usergroup").multiselect("reload");
    $("#selectCountries option:selected").prop("selected", false);
    $("#selectCountries").multiselect("reload");
}