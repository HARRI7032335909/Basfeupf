$(document).ready(function () {
    var getsegmentTilesVal = $(".support-list-email").attr("data-segmenttiles");
    if(getsegmentTilesVal != undefined){
    
        $.each(JSON.parse(getsegmentTilesVal), function( key, value ) {
            if(value.segmentId == localStorage.getItem("businesssegmentid") || value.segmentId == "99"){
                var supportHTML = $('<div class="support-item-container"><div class="support-item"><i class="icon-style email"></i><div class="support-item-title">' + value.segmentTitle + '</div><div class="support-item-description">' + value.segmentDescription + '</div><div class="support-item-detail"><a href="javascript:void(0);"  data-phoneno="'+value.segmentPhone+'" data-toemail="'+ value.segmentEmail+'" class="supportGonow">Go Now</a></div><div class="support-item-image"><img src="' + value.segmentImage + '" /></div></div></div>');
                $('#email-support-items').append(supportHTML);
            }
        });
    
    }


    $('body').on('click', 'a.supportGonow', function() {
        $(".support-modal").addClass("show");
        $(".support-modal-back").show();
        $("html, body").animate({ scrollTop: 0 }, "slow");

 		var data = JSON.parse(localStorage.getItem("userloggedindata"));
         const modalData = {
          userEmail: data.userinfo.email,
          userPhone:$(this).attr("data-phoneno"),
          toEmail: $(this).attr("data-toemail")
        };

		const event = new CustomEvent("openModalEvent", { detail: modalData });

		window.dispatchEvent(event);


    });
    $(".cancelButton").click(function(){
$(".support-modal").removeClass("show");
        $(".support-modal-back").hide();

    });


});
