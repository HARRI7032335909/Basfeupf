function dcLogin(data) {

    var data = JSON.parse(data);
    if (localStorage.getItem("dcMultiAccountUser")) {
        localStorage.setItem("businessgroup", data.talendjson.Profile_Data.Account_Types[0].account_type);
        localStorage.setItem("businesssegmentid", data.talendjson.Profile_Data.Account_Types[0].Segment[0].bus_segment_id);
        localStorage.removeItem("dcMultiAccountUser")
    }
    if (data.userinfo != undefined) {
        /**********login in busniess segment**************/
        if (data.talendjson.Profile_Data.Accounts != undefined && data.talendjson.Profile_Data.Accounts != "") {
            localStorage.setItem("businesssegmentid", localStorage.getItem("businesssegmentid") ? localStorage.getItem("businesssegmentid") : data.talendjson.Profile_Data.Account_Types[0].Segment[0].bus_segment_id);
            localStorage.setItem("businessgroup", localStorage.getItem("businessgroup") ? localStorage.getItem("businessgroup") : data.talendjson.Profile_Data.Account_Types[0].account_type);
            localStorage.setItem("businessaccountid", localStorage.getItem("businessaccountid") ? localStorage.getItem("businessaccountid") : data.talendjson.Profile_Data.Accounts[0].account_id);
            localStorage.setItem("businesscontactid", localStorage.getItem("businesscontactid") ? localStorage.getItem("businesscontactid") : data.talendjson.Profile_Data.Contact_Id);

        } else {
            localStorage.setItem("businesssegmentid", data.userinfo.extension_user_Registration_bs);
            localStorage.setItem("businessgroup", data.userinfo.extension_user_type);
            localStorage.setItem("businessaccountid", data.userinfo.extension_account_number);
            localStorage.setItem("businesscontactid", data.userinfo.extension_contact_id);
        }
        
        businesssegmentid = localStorage.getItem("businesssegmentid");
        businessgroup = localStorage.getItem("businessgroup");
        businessaccountid = localStorage.getItem("businessaccountid");
        businesscontactid = localStorage.getItem("businesscontactid");

        /***********eventsection function call only page has event-section class******** */
        if($('body').find('.events-section').length !== 0){
         segmentEvents(businesssegmentid);
        }
       var contactInfo =  JSON.parse(localStorage.getItem("currContactMetaInfo"));

       if(localStorage.getItem("currContactMetaInfo") != null){

        contactOverviewOb = { segmentid: parseInt(businesssegmentid), group: contactInfo.hirarchyLevel != null ? contactInfo.hirarchyLevel: "", accountid: businessaccountid, contactid: contactInfo.cntID };

        /******* calling contact overview************/

        dccontactOverview(contactOverviewOb);
        }
       

        /************slideout username firstname and lastname************/
        document.getElementsByClassName("login-name")[0].innerHTML = data.userinfo.firstname +"  "+ data.userinfo.lastname + "<span>" +data.userinfo.firstname.substring(0, 1) + data.userinfo.lastname.substring(0, 1) + "</span>";
        document.getElementsByClassName("title")[0].innerHTML = data.userinfo.firstname + " " + data.userinfo.lastname;
        /********variable declaration********/
        var fileDetail, apiUrl;
        var segment_id = localStorage.getItem("businesssegmentid");
        if (document.getElementById("showdoctype") != null) {
            var showdoctype = document.getElementById("showdoctype").innerHTML;
        }
        if (document.getElementById("nodata") != null) {
            var nodatamessage = document.getElementById("nodata").innerHTML;
        }
        /****************bannercalling */
        segmentNews1(segment_id);
        newsCarouselInit();

        /***********banner***************/

        /***** Restrict the options for End Users ******/
        if(localStorage.getItem("businessaccountid") == "undefined" || localStorage.getItem("businesscontactid") == "undefined" || localStorage.getItem("businessgroup") == "End User") {
            $(".getsupport").hide();
            $(".banner-left-innerContent button").hide();
            $('.eupf-loader').show();
            if(($('.dc-Container').find('.get-support').length != 0) || ($('.dc-Container').find('.dc-accountOverview').length != 0) || ($('.dc-Container').find("#account-contacts_list").length != 0) || ($('.dc-Container').find("#contact-form-container").length != 0) || ($('.dc-Container').find('.dc-ContactOverview').length != 0)) {
    			$("#modalContent").insertAfter(".footer").show();
                $('.eupf-loader').hide();
            }
            else {
				$("#modalContent").hide();
            }
        }
        /************** End ***************/
    }

    if (data.talendjson != undefined) {
        /****************account name check is exist or not*********************/
        if (data.talendjson.Profile_Data.Accounts != undefined && data.talendjson.Profile_Data.Accounts != "") {
            DCAccounthyphen = " - ";
            DCaccountName = data.talendjson.Profile_Data.Accounts[0].account_name
            DCaccountID = " BASF ID " + businessaccountid
        } else {
            DCAccounthyphen = "";
            DCaccountName = "";
            DCaccountID = "";
        }



        if (data.talendjson.Profile_Data.Account_Types != undefined) {
            document.getElementById('viewGroup').innerHTML = "";
            document.getElementById('radio-group').innerHTML = "";
            for (i = 0; i < data.talendjson.Profile_Data.Account_Types.length; i++) {
                var radiochecked;
                if (data.talendjson.Profile_Data.Account_Types[i].account_type == localStorage.getItem("businessgroup")) {
                    radiochecked = "checked";
                } else {
                    radiochecked = "";
                }
                var viewAs = `<div class="radio-wrapper group-wrapper">
                                        <div class="input-wrapper">
                                            <label>
                                                <input class="radio" type="radio"  name="modalgroup" onclick="businesssegment(this)"  ${radiochecked} value="${data.talendjson.Profile_Data.Account_Types[i].account_type}">
                                                <span class="input-radio"></span>
                                                <span>${data.talendjson.Profile_Data.Account_Types[i].account_type}</span>
                                            </label>
                                        </div>
                                    </div>`
                document.getElementById('viewGroup').innerHTML += viewAs;

            }



            for (i = 0; i < data.talendjson.Profile_Data.Account_Types.length; i++) {
                if (localStorage.getItem("businessgroup") == data.talendjson.Profile_Data.Account_Types[i].account_type) {
                    for (j = 0; j < data.talendjson.Profile_Data.Account_Types[i].Segment.length; j++) {
                        if (data.talendjson.Profile_Data.Account_Types[i].Segment[j].bus_segment_id == localStorage.getItem("businesssegmentid")) {
                            radiochecked = "checked";
                        } else {
                            radiochecked = "";
                        }
                        var radioGroup = `<div class="radio-wrapper">
                                            <div class="input-wrapper">
                                                <label for="20">
                                                    <input class="radio" type="radio"  name="modalwrap" ${radiochecked} value="${data.talendjson.Profile_Data.Account_Types[i].Segment[j].bus_segment_id}" >
                                                    <span class="input-radio"></span>
                                                    <span>${data.talendjson.Profile_Data.Account_Types[i].Segment[j].bus_segment_name}  ${DCAccounthyphen} ${DCaccountName} <br/>  ${DCaccountID}</span>
                                                </label>
                                            </div>
                                        </div>`;
                        document.getElementById('radio-group').innerHTML += radioGroup;
                    }
                }
            }

        } else {

            var viewAs = `<div class="radio-wrapper group-wrapper">
                                        <div class="input-wrapper">
                                            <label>
                                                <input class="radio" type="radio"  name="modalgroup"   checked value="${data.userinfo.extension_user_type}">
                                                <span class="input-radio"></span>
                                                <span>${data.userinfo.extension_user_type}</span>
                                            </label>
                                        </div>
                                    </div>`
            document.getElementById('viewGroup').innerHTML += viewAs;
            var radioGroup = `<div class="radio-wrapper">
                                            <div class="input-wrapper">
                                                <label for="20">
                                                    <input class="radio" type="radio"  name="modalwrap" checked value="$(data.userinfo.extension_user_Registration_bs)" >
                                                    <span class="input-radio"></span>
                                                    <span>${data.segmentdetails.data[0].segment_name}  -   ${data.talendjson.Profile_Data.Lead_Id}</span>
                                                </label>
                                            </div>
                                        </div>`;
            document.getElementById('radio-group').innerHTML += radioGroup;

        }

            /**********footer dynamic*********** */
        if (localStorage.getItem("businessaccountid") != "undefined" && localStorage.getItem("businesscontactid") != "undefined" && businessgroup != "End User") {
            const repDetails = {
                "accountId": businessaccountid,
                "busSegId": parseInt(localStorage.getItem("businesssegmentid"))
            };
            postAjaxRequest("POST", "/content/basfeupf/us/accountoverview.get_repo_details.json", repDetails, repDetailsCall);
        }

        $(".hero-banner-component .banner-content-left").each(function () {
            if ($(this).find("h1").text().length < 1) {
                var getAccountName = DCaccountName;
                $(this).find("h1").text(getAccountName);
            }
            if ($(this).find("p").text().length < 1) {
                var getBusinessInfo = "";
                var getBusinessstate = "";
                if (data['talendjson']["Profile_Data"]['City'] != "" && data['talendjson']["Profile_Data"]['City'] != undefined) {
                    getBusinessInfo = data['talendjson']["Profile_Data"]['City'] + " , ";
                } else {
                    getBusinessInfo = "";
                }
                if (data['talendjson']["Profile_Data"]['State'] != "" && data['talendjson']["Profile_Data"]['State'] != undefined) {
                    getBusinessstate = data['talendjson']["Profile_Data"]['State'] + " - ";
                } else {
                    getBusinessstate = "";
                }
                var getBusinessgroup = localStorage.getItem("businessgroup");
                $(this).find("p").text(getBusinessInfo + getBusinessstate + getBusinessgroup);
            }
        });

    }


    /***********Innerpage apiurl****************/
    if (typeof showdoctype !== "undefined") {
        if (showdoctype == "promotions") {
            apiUrl = "/bin/basf/eupfportal/portal-promotions/promotion-documents?busSegId=" + segment_id;

        } else if (showdoctype == "supplyReports") {
            apiUrl = "/bin/basf/eupfportal/portal-supply-reports/supply-reports-documents?busSegId=" + segment_id;

        } else if (showdoctype == "priceSheets") {
            apiUrl = "/bin/basf/eupfportal/portal-price-sheets/price-sheets-documents?busSegId=" + segment_id;

        } else {

            apiUrl = "/bin/basf/eupfportal/portal-programs/program-documents?busSegId=" + segment_id;

        }
    }


    /********* fetch api on page load***********/
    if (typeof apiUrl !== "undefined") {

        const request1 = fetch(apiUrl)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })

            .catch(error => {
                console.log('Error:', error);
            });



        Promise.all([request1])
            .then(([data1]) => {
                fileDetail = JSON.stringify(data1, null, 2);
                document.querySelector('.gif-loader').style.display = 'none'
                if (JSON.stringify([]) == JSON.stringify(data1)) {
                    document.getElementById('files-wrapper').innerHTML = '<span class="noactive">' + nodatamessage + '</span>';
                }
                fileinformation(fileDetail);

            })
            .catch(error => {
                console.log(error);
            });


    }

   
    function repDetailsCall(repDetailsResponse) {
        var repDetailsResponse = JSON.parse(repDetailsResponse);
        if (repDetailsResponse.repdetails.length > 0) {
            for (var i = 0; i < repDetailsResponse.repdetails.length; i++) {
                var repDetailgroup;
                if (repDetailsResponse.repdetails[i].primaryContact.physical != undefined) {
                    repDetailgroup = $('<li class="subnav-footer"><span>' + repDetailsResponse.repdetails[i].primaryContact.repTitle + '</span><span>' + repDetailsResponse.repdetails[i].fullName + '</span> <span> ' + repDetailsResponse.repdetails[i].primaryContact.physical.addressLine1 + " " +  repDetailsResponse.repdetails[i].primaryContact.physical.addressLine2 + ' </span><span>' +  (repDetailsResponse.repdetails[i].primaryContact.physical.city ? (repDetailsResponse.repdetails[i].primaryContact.physical.city  + ', ') : "")  + repDetailsResponse.repdetails[i].primaryContact.physical.province +" "+ repDetailsResponse.repdetails[i].primaryContact.physical.postal + '</span><span><a href=tel:'+repDetailsResponse.repdetails[i].primaryContact.Communications.phoneNumber+'>' + repDetailsResponse.repdetails[i].primaryContact.Communications.phoneNumber + '</a></span><span><a href=mailto:'+repDetailsResponse.repdetails[i].primaryContact.Communications.email+'>' + repDetailsResponse.repdetails[i].primaryContact.Communications.email + '</a></span></li>');
                } else {
                    repDetailgroup = $('<li class="subnav-footer"><span>' + repDetailsResponse.repdetails[i].primaryContact.repTitle + '</span><span>' + repDetailsResponse.repdetails[i].fullName + '</span> <span> ' + repDetailsResponse.repdetails[i].primaryContact.mailing.addressLine1 + " " + repDetailsResponse.repdetails[i].primaryContact.mailing.addressLine2 + ' </span><span>' +  (repDetailsResponse.repdetails[i].primaryContact.mailing.city ? (repDetailsResponse.repdetails[i].primaryContact.mailing.city  + ', ') : "") +  repDetailsResponse.repdetails[i].primaryContact.mailing.province +" "+ repDetailsResponse.repdetails[i].primaryContact.mailing.postal + '</span><span><a href=tel:'+repDetailsResponse.repdetails[i].primaryContact.Communications.phoneNumber +'>' + repDetailsResponse.repdetails[i].primaryContact.Communications.phoneNumber + '</span><span><a href=mailto:'+repDetailsResponse.repdetails[i].primaryContact.Communications.email+'>' + repDetailsResponse.repdetails[i].primaryContact.Communications.email + '</a></span></li>');
                }
                $('#repDetailsfooter').append(repDetailgroup);
            }
        } else {
            document.getElementById('repDetailsfooter').innerHTML = "No data for this user.";
        }
        /*******getsupport page ******/
        if ($('.dc-Container').find('.get-support').length != 0) {
            if (repDetailsResponse.repdetails.length > 0) {
                $.each(repDetailsResponse.repdetails, function (key, value) {
                    var repDetailValues,imageRepId, repPhoneNumber,repImagePath;
                    repImagePath = $("cxm-support").attr("rep-image-path") || "";
                    if(value.primaryContact.repId != null && value.primaryContact.repId !=""){
                     	imageRepId =  value.primaryContact.repId;
                    }
                    else{
 						imageRepId =  "default";
                    }
                    repPhoneNumber = ((value.primaryContact.Communications.phoneNumber) ? '<div class="rep-phone"><i class="icon-style telephone"></i><a href="tel:'+ value.primaryContact.Communications.phoneNumber +'">' + value.primaryContact.Communications.phoneNumber + '</a></div>' : "");
                    if (value.primaryContact.physical != undefined) {
                        repDetailValues = $('<div class="list-container"><div class="rep-list-item"><div class="rep-info-box"><img class="rep-image" src="'+repImagePath+'/'+imageRepId+'.jpg" alt="rep-image" /><div class="rep-details"><div class="rep-name h3">' + value.fullName + '</div><div class="rep-mailcity hide-city">' + value.primaryContact.repTitle + ', ' + value.primaryContact.physical.city + '</div>' + ((value.primaryContact.Communications.email) ? ('<div class="rep-email"><i class="icon-style email"></i><a href=mailto:'+ value.primaryContact.Communications.email +'>' + value.primaryContact.Communications.email + '</a></div>') : "") + repPhoneNumber + '</div></div></div></div>');
                    } else {
                        repDetailValues = $('<div class="list-container"><div class="rep-list-item"><div class="rep-info-box"><img class="rep-image" src="'+repImagePath+'/'+imageRepId+'.jpg" alt="rep-image" /><div class="rep-details"><div class="rep-name h3">' + value.fullName + '</div><div class="rep-mailcity hide-city">' + value.primaryContact.repTitle + ', ' + value.primaryContact.mailing.city + '</div>' + ((value.primaryContact.Communications.email) ? ('<div class="rep-email"><i class="icon-style email"></i><a href=mailto:'+ value.primaryContact.Communications.email +'>' + value.primaryContact.Communications.email + '</a></div>') : "") + repPhoneNumber + '</div></div></div></div>');
                    }
                    $('#rep-detail-content').append(repDetailValues);
                });
            } else {
                $('#rep-detail-content').append("<p>No data for this user.</p>");
            }
        }
    }
    var slides = document.getElementsByClassName("subnav-footer");


    for (var i = 0; i < slides.length; i++) {
        if (slides.item(i).getAttribute('data-href') == null) {
            slides.item(i).classList.add("label")
        };

        if (slides.item(i).getAttribute('data-segment-id') == 0 || slides.item(i).getAttribute('data-segment-id') == segment_id) {
            slides.item(i).style.display = 'block';
        } else {
            if (segment_id != 22 && slides.item(i).getAttribute('data-segment-id') == "pss_all") {
                slides.item(i).style.display = 'block';
            } else {
                slides.item(i).style.display = 'none';
            }
        }
    }







    /**********onload account overview fetch **************/


    const accountoverview = {
        "accountId": businessaccountid,
        "hierarchyLevel": businessgroup,
        "accBusSegId": parseInt(businesssegmentid)
    }
    if (document.getElementById("contact-form-container") != null) {
    /*********contact deatils should come from contatc page not from login***********/
    if (document.getElementById("contact-form-container").dataset.formtype == "edit") {

         var contacteditdetail = {
                "contactId": contactOverviewOb.contactid,
                "accountId": contactOverviewOb.accountid,
                "accBusSegId": parseInt(businesssegmentid),
                "hierarchyLevel": contactOverviewOb.group
            }
        }
    
        if (document.getElementById("contact-form-container").dataset.formtype == "add") {

            postAjaxRequest("POST", "/content/basfeupf/us/accountoverview.get_account_overview.json", accountoverview, accountOverview);
        } else {
            postAjaxRequest("POST", "/content/basfeupf/us/contactdetails.get_contact_detail.json", contacteditdetail, contactEditDetail);
        }
    }



    /****************editcontact************/
    $(".contact-form .toggle-steps").eq(0).click();

    function contactEditDetail(contactdetailsdata) {



        localStorage.removeItem('accountdatastore');
        $(".basicbuttons").hide();
        $(".contact-form .toggle-steps").eq(1).addClass("open");
        $(".contact-form .collapsible-panel").eq(1).show();
      
        var contactdata = JSON.parse(contactdetailsdata);

        $(".account-info h3").text($.trim(contactdata.cntAccName));
        $(".account-info .hierarchy").text((contactdata.physical.city ? contactdata.physical.city + "," : "") + (contactdata.physical.province ? contactdata.physical.province + "-" : "") + businessgroup);
        $("input[name=lastname]").val(contactdata.lastName);
        $("input[name=firstname]").val(contactdata.firstName);
        $('select[name="role"]').val(contactdata.role);
        $("input[name=contacttitle]").val(contactdata.title);
        if(contactdata.isPrimary !== null)
        $("input[name=isPrimary][value=" + (contactdata.isPrimary).toLowerCase() + "]").prop("checked",true);

        for (var i = 0; i < contactdata.communications.length; i++) {

            if (contactdata.communications[i].methodOfContact == "DIRECT_MAIL") {
                $("input[name=mpaddress][value=" + contactdata.communications[i].value + "]").attr('checked', 'checked');
            }

            if (contactdata.communications[i].methodOfContact == "EMAIL") {

                $("input[name=workEmail]").val(contactdata.communications[i].value);
                
                 if (contactdata.communications[i].preferred == 1) {
                     $("input[name=workEmail]").parents(".field-outer-wrapper").siblings(".email-checkbox").find(".input-wrapper").removeClass("disabled");
                     $("input[name=workEmail]").parents(".field-outer-wrapper").siblings(".email-checkbox").find(".radiocheckbox").prop('checked', true);
                 }else if(contactdata.communications[i].value != "" && contactdata.communications[i].value != null){
                         $("input[name=workEmail]").parents(".field-outer-wrapper").siblings(".email-checkbox").find(".input-wrapper").removeClass("disabled");
                         $("input[name=workEmail]").parents(".field-outer-wrapper").siblings(".email-checkbox").find(".radiocheckbox").removeAttr("disabled");
                }
                 if(contactdata.communications[i].value != "" && contactdata.communications[i].value != null){
                     $('input[name=workEmail]').attr('data-value', "edit");
                 }
 
 
 
             } 
 
             if (contactdata.communications[i].methodOfContact == "MOBILE") {
 
              $("input.mobile").val(contactdata.communications[i].value);
   
                 if (contactdata.communications[i].preferred == 1) {
                   //  $("input.mobile").parents(".field-outer-wrapper").siblings(".email-checkbox").find(".input-wrapper").removeClass("disabled");
                   //  $("input.mobile").parents(".field-outer-wrapper").siblings(".email-checkbox").find(".radiocheckbox").prop('checked', true);
                 }
                 if(contactdata.communications[i].value != "" && contactdata.communications[i].value != null){
                     $('input.mobile').attr('data-value', "edit");
                 }
 
             }
 

        }

        $('select[name="physicalState"]').val(contactdata.physical.province);
        $("input[name=physicalLine1]").val(contactdata.physical.line1);
        $("input[name=physicalLine2]").val(contactdata.physical.line2);
        $("input[name=physicalCity]").val(contactdata.physical.city);
        $("input[name=physicalPostalCode]").val(contactdata.physical.postal);
        $('select[name="mailingState"]').val(contactdata.mailing.province);
        $("input[name=mailingLine1]").val(contactdata.mailing.line1);
        $("input[name=mailingLine2]").val(contactdata.mailing.line2);
        $("input[name=mailingCity]").val(contactdata.mailing.city);
        $("input[name=mailingPostalCode]").val(contactdata.mailing.postal);
        var accountdatastore = {
            'physicalstate': contactdata.physical.province,
            'physicalline1': contactdata.physical.line1,
            'physicalline2': contactdata.physical.line2,
            'physicalcity': contactdata.physical.city,
            'physicalcode': contactdata.physical.postal
        };
        localStorage.setItem('accountdatastore', JSON.stringify(accountdatastore));


        if ($('#myForm')[0].checkValidity()) {
            $(".contact-steps").find(".icon-style").addClass("ok-validation");
            for (i = 0; i <= 3; i++) {
                $("#panel" + i).find(".icon-style-tab").addClass("ok-validation");
            }

        } else {
            $("#save-submit").click();
        }

        /******scroll down on page load**********/
        var addresshash = window.location.hash;
        if (addresshash != "") {
            $('html, body').animate({
                scrollTop: $(addresshash).offset().top
            }, 'slow');

            $("#panel3").click();

        }


    }


    /************************/

    function accountOverview(accountdata) {

        var accountdata = JSON.parse(accountdata);
        $(".account-info h3").text($.trim(accountdata.name));
        $(".account-info .hierarchy").text((accountdata.physical.city ? accountdata.physical.city + "," : "") + (accountdata.physical.province ? accountdata.physical.province + "-" : "") + businessgroup);
        if (accountdata.physical.line2 != null) {
            physicalline2 = accountdata.physical.line2
        } else {
            physicalline2 = ""
        }
        if (accountdata.mailing.line2 != null) {
            mailinglline2 = accountdata.mailing.line2
        } else {
            mailinglline2 = ""
        }

        $('select[name="physicalState"]').val(accountdata.physical.province);
        $("input[name=physicalLine1]").val(accountdata.physical.line1);
        $("input[name=physicalLine2]").val(physicalline2);
        $("input[name=physicalCity]").val(accountdata.physical.city);
        $("input[name=physicalPostalCode]").val(accountdata.physical.postal);
        $('select[name="mailingState"]').val(accountdata.mailing.province);
        $("input[name=mailingLine1]").val(accountdata.mailing.line1);
        $("input[name=mailingLine2]").val(mailinglline2);
        $("input[name=mailingCity]").val(accountdata.mailing.city);
        $("input[name=mailingPostalCode]").val(accountdata.mailing.postal);
        var accountdatastore = { 'physicalstate': accountdata.physical.province, 'physicalline1': accountdata.physical.line1, 'physicalline2': accountdata.physical.line2, 'physicalcity': accountdata.physical.city, 'physicalcode': accountdata.physical.postal };
        localStorage.setItem('accountdatastore', JSON.stringify(accountdatastore));




    }
    $(document).on('change', 'input[name="copyAccountAddress"]', function () {

        copyAccountOverview();

    });

    $(document).on('change', 'input[name="copyPhysicalAddress"]', function () {

        copyPhysicalAddress();

    });



    function copyAccountOverview() {
        var reAccountDatastore = localStorage.getItem('accountdatastore');
        var reAccountDatastore = JSON.parse(reAccountDatastore);
        console.log(reAccountDatastore);


        if ($("input[name=copyAccountAddress]").is(':checked')) {
            $('select[name="physicalState"]').val(reAccountDatastore.physicalstate);
            $("input[name=physicalLine1]").val(reAccountDatastore.physicalline1);
            $("input[name=physicalLine2]").val(reAccountDatastore.physicalline2);
            $("input[name=physicalCity]").val(reAccountDatastore.physicalcity);
            $("input[name=physicalPostalCode]").val(reAccountDatastore.physicalcode);
        }

    }
    function copyPhysicalAddress() {


        if ($("input[name=copyPhysicalAddress]").is(':checked')) {
            $('select[name="mailingState"]').val($('select[name="physicalState"]').val());
            $("input[name=mailingLine1]").val($("input[name=physicalLine1]").val());
            $("input[name=mailingLine2]").val($("input[name=physicalLine2]").val());
            $("input[name=mailingCity]").val($("input[name=physicalCity]").val());
            $("input[name=mailingPostalCode]").val($("input[name=physicalPostalCode]").val());
        }

    }

}




function segmentNews1(segID) {
    $('.owl-carousel').owlCarousel('destroy');
    $('.hero-banner-component .owl-carousel').html('');
    $.each(newsListArray, (ind, ele) => {
        if (ele.getAttribute('data-segmentid') == segID) {
            $('.hero-banner-component .owl-carousel').append(ele)
        }
    })
    newsCarouselInit();
}

function menutoggle() {
    var slideout = document.getElementById("slide-out");
    slideout.classList.toggle("open");
}


function businesssegment(radio) {
    var data = JSON.parse(localStorage.getItem("userloggedindata"));
    for (i = 0; i < data.talendjson.Profile_Data.Account_Types.length; i++) {

        if (radio.checked && radio.value === data.talendjson.Profile_Data.Account_Types[i].account_type) {
            document.getElementById('radio-group').innerHTML = "";
            for (j = 0; j < data.talendjson.Profile_Data.Account_Types[i].Segment.length; j++) {
                if (j == 0) {
                    radiochecked = "checked";
                } else {
                    radiochecked = "";
                }
                var radioGroup = `<div class="radio-wrapper">
                                    <div class="input-wrapper">
                                        <label for="20">
                                            <input class="radio" type="radio"  name="modalwrap" ${radiochecked} value="${data.talendjson.Profile_Data.Account_Types[i].Segment[j].bus_segment_id}" >
                                            <span class="input-radio"></span>
                                            <span>${data.talendjson.Profile_Data.Account_Types[i].Segment[j].bus_segment_name} ${DCAccounthyphen} ${DCaccountName} <br/>  ${DCaccountID}</span>
                                        </label>
                                    </div>
                                </div>`;
                document.getElementById('radio-group').innerHTML += radioGroup;
            }
        }
    }
}

function menucontinue() {
    localStorage.setItem("businesssegmentid", document.getElementById("radio-group").querySelectorAll('input[type="radio"]:checked')[0].value);
    localStorage.setItem("businessgroup", document.getElementById("viewGroup").querySelectorAll('input[type="radio"]:checked')[0].value);
    location.reload();
}




/*********************/
function formatFileSize(bytes, decimalPoint) {
    if (bytes == 0) return '0 Bytes';
    var k = 1000,
        dm = decimalPoint || 2,
        sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
        i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}


const monthNames = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

function formatDate(getDate){ 
      const formattedDate  = new Date(getDate);
      var d = ('0' + formattedDate.getDate()).slice(-2);
      var m =   monthNames[formattedDate.getMonth()]
      var y = formattedDate.getFullYear();
      return(m +" "+ d + ", " + y );
}

/******************Innerpage file information**********************/

function fileinformation(fileDetail) {
    const fileslabels = document.querySelector("#files-labels");
    if (fileDetail != undefined) {
        fileDetail = $.parseJSON(fileDetail);
        var fileInformation;
        fileDetail.forEach(function (file) {
            let filesize = formatFileSize(file.size, 2);

                fileInformation = `<div class="file-tile">
                    <div class="pdf-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 75.32 92.604"><path style="line-height:normal;font-variant-ligatures:normal;font-variant-position:normal;font-variant-caps:normal;font-variant-numeric:normal;font-variant-alternates:normal;font-feature-settings:normal;text-indent:0;text-align:start;text-decoration-line:none;text-decoration-style:solid;text-decoration-color:#000;text-transform:none;text-orientation:mixed;white-space:normal;shape-padding:0;isolation:auto;mix-blend-mode:normal;solid-color:#000;solid-opacity:1" d="M-29.633 123.947c-3.552 0-6.443 2.894-6.443 6.446v49.498c0 3.551 2.891 6.445 6.443 6.445h37.85c3.552 0 6.443-2.893 6.443-6.445v-40.702s.102-1.191-.416-2.351a6.516 6.516 0 0 0-1.275-1.844 1.058 1.058 0 0 0-.006-.008l-9.39-9.21a1.058 1.058 0 0 0-.016-.016s-.802-.764-1.99-1.274c-1.4-.6-2.842-.537-2.842-.537l.021-.002z" color="#000" font-weight="400" font-family="sans-serif" overflow="visible" fill="#ff2116" paint-order="markers fill stroke" transform="translate(53.548 -183.975) scale(1.4843)"></path><path style="line-height:normal;font-variant-ligatures:normal;font-variant-position:normal;font-variant-caps:normal;font-variant-numeric:normal;font-variant-alternates:normal;font-feature-settings:normal;text-indent:0;text-align:start;text-decoration-line:none;text-decoration-style:solid;text-decoration-color:#000;text-transform:none;text-orientation:mixed;white-space:normal;shape-padding:0;isolation:auto;mix-blend-mode:normal;solid-color:#000;solid-opacity:1" d="M-29.633 126.064h28.38a1.058 1.058 0 0 0 .02 0s1.135.011 1.965.368a5.385 5.385 0 0 1 1.373.869l9.368 9.19s.564.595.838 1.208c.22.495.234 1.4.234 1.4a1.058 1.058 0 0 0-.002.046v40.746a4.294 4.294 0 0 1-4.326 4.328h-37.85a4.294 4.294 0 0 1-4.326-4.328v-49.498a4.294 4.294 0 0 1 4.326-4.328z" color="#000" font-weight="400" font-family="sans-serif" overflow="visible" fill="#f5f5f5" paint-order="markers fill stroke" transform="translate(53.548 -183.975) scale(1.4843)"></path><path d="M18.804 55.136c-2.162-2.162.177-5.133 6.526-8.288l3.994-1.986 1.557-3.405a134.054 134.054 0 0 0 2.838-6.79l1.283-3.385-.884-2.506c-1.087-3.08-1.474-7.71-.785-9.374.934-2.255 3.993-2.024 5.205.393.946 1.888.849 5.306-.272 9.618l-.92 3.534.81 1.375c.445.756 1.746 2.55 2.89 3.989l2.152 2.675 2.677-.349c8.503-1.11 11.416.776 11.416 3.48 0 3.413-6.677 3.695-12.285-.243-1.261-.886-2.127-1.767-2.127-1.767s-3.513.715-5.243 1.182c-1.785.48-2.675.782-5.29 1.665 0 0-.918 1.332-1.516 2.3-2.224 3.605-4.821 6.591-6.676 7.678-2.077 1.217-4.254 1.3-5.35.204zm3.393-1.212c1.216-.751 3.676-3.661 5.378-6.361l.69-1.094-3.14 1.579c-4.848 2.438-7.066 4.735-5.913 6.125.648.78 1.423.716 2.985-.25zm31.494-8.84c1.189-.833 1.016-2.511-.328-3.188-1.045-.526-1.888-.634-4.606-.594-1.67.114-4.354.45-4.81.553 0 0 1.476 1.019 2.13 1.394.872.498 2.99 1.422 4.537 1.895 1.526.467 2.409.418 3.077-.06zM41.028 39.82c-.72-.756-1.943-2.334-2.719-3.507-1.014-1.331-1.523-2.27-1.523-2.27s-.742 2.385-1.35 3.82l-1.898 4.692-.55 1.064s2.925-.959 4.414-1.348c1.576-.411 4.776-1.04 4.776-1.04zm-4.081-16.365c.183-1.54.261-3.078-.233-3.853-1.373-1.5-3.03-.25-2.749 3.317.095 1.2.393 3.251.791 4.516l.725 2.298.51-1.73c.28-.953.71-3 .956-4.548z" fill="#ff2116"></path><path style="line-height:125%;-inkscape-font-specification:'Franklin Gothic Medium Cond'" d="M-20.93 167.839h2.365q1.133 0 1.84.217.706.21 1.19.944.482.728.482 1.756 0 .945-.392 1.624-.392.678-1.056.98-.658.3-2.03.3h-.818v3.73h-1.581zm1.58 1.224v3.33h.785q1.05 0 1.448-.391.406-.392.406-1.274 0-.657-.266-1.063-.266-.413-.588-.504-.315-.098-1-.098zm5.508-1.224h2.148q1.56 0 2.49.552.938.553 1.414 1.645.483 1.091.483 2.42 0 1.4-.434 2.499-.427 1.091-1.316 1.763-.881.672-2.518.672h-2.267zm1.58 1.266v7.018h.659q1.378 0 2-.952.623-.958.623-2.553 0-3.513-2.623-3.513zm6.473-1.266h5.304v1.266h-3.723v2.855h2.981v1.266h-2.98v4.164H-5.79z" transform="translate(53.548 -183.975) scale(1.4843)" font-weight="400" font-family="Franklin Gothic Medium Cond" letter-spacing="0" word-spacing="4.26" fill="#2c2c2c"></path></svg></div>

                      <div class="file-details">
                        <h2>${file.title || file.name}</h2>
                        <span>${fileslabels.dataset.informationLabel}</span>
                        
                        ${(file.description != undefined && file.description != "") ?
                            ` <div class="file-information file-description">
                                <span>${fileslabels.dataset.descriptionLabel}</span>
                                <p>${file.description}</p>
                            </div>`
                            : ""
                        }
                        <div class="file-information">
                            <span>${fileslabels.dataset.sizeLabel}</span>
                            <p>${filesize}</p>
                        </div>

                         ${(file.programStartDate != undefined && file.programStartDate != "") ?
                            ` <div class="file-information file-description">
                                <span>${fileslabels.dataset.startdateLabel}</span>
                                <p>${formatDate(file.programStartDate)}</p>
                            </div>`
                            : ""
                        }
                         ${(file.programEndDate != undefined && file.programEndDate != "") ?
                            ` <div class="file-information file-description">
                                <span>${fileslabels.dataset.enddateLabel}</span>
                                <p>${formatDate(file.programEndDate)}</p>
                            </div>`
                            : ""
                        }
                    </div>
                    <div class="action-buttons">
                        <span>${fileslabels.dataset.actionsLabel}</span>
                        <a href="/bin/basf/basfeupf/portal-programs/previewpdf?sha=${file.shaId}&assetPath=${file.assetPath}" target="_blank"><svg width="24px" height="24px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><title>Icon/Preview</title><desc>Created with Sketch.</desc><defs><path d="M12.0008481,17.1838227 C16.4193788,17.1838227 20,12.0919114 20,12.0919114 C20,12.0919114 16.4193788,7 12.0008481,7 C7.5823174,7 4,12.0919114 4,12.0919114 C4,12.0919114 7.5823174,17.1838227 12.0008481,17.1838227 M12.0008481,9.4068695 C13.4833033,9.4068695 14.68589,10.6094562 14.68589,12.0919114 C14.68589,13.5743666 13.4833033,14.7769532 12.0008481,14.7769532 C10.5166967,14.7769532 9.31411004,13.5743666 9.31411004,12.0919114 C9.31411004,10.6094562 10.5166967,9.4068695 12.0008481,9.4068695" id="path-1"></path></defs><g id="Icon/Preview" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><mask id="mask-2" fill="white"><use xlink:href="#path-1"></use></mask><use id="Preview" fill="#333333" xlink:href="#path-1"></use><g id="Color-Grey-1" mask="url(#mask-2)" fill="#333333" fill-rule="nonzero"><rect id="Rectangle" x="0" y="0" width="24" height="24"></rect></g></g></svg> ${fileslabels.dataset.previewLabel}</a>
                        <a href="/bin/basf/basfeupf/portal-programs/downloadpdf?sha=${file.shaId}&assetPath=${file.assetPath}"> <svg width="24px" height="24px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><title>Icon/Preview</title><desc>Created with Sketch.</desc><defs><path d="M12.0008481,17.1838227 C16.4193788,17.1838227 20,12.0919114 20,12.0919114 C20,12.0919114 16.4193788,7 12.0008481,7 C7.5823174,7 4,12.0919114 4,12.0919114 C4,12.0919114 7.5823174,17.1838227 12.0008481,17.1838227 M12.0008481,9.4068695 C13.4833033,9.4068695 14.68589,10.6094562 14.68589,12.0919114 C14.68589,13.5743666 13.4833033,14.7769532 12.0008481,14.7769532 C10.5166967,14.7769532 9.31411004,13.5743666 9.31411004,12.0919114 C9.31411004,10.6094562 10.5166967,9.4068695 12.0008481,9.4068695" id="path-1"></path></defs><g id="Icon/Preview" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><mask id="mask-2" fill="white"><use xlink:href="#path-1"></use></mask><use id="Preview" fill="#333333" xlink:href="#path-1"></use><g id="Color-Grey-1" mask="url(#mask-2)" fill="#333333" fill-rule="nonzero"><rect id="Rectangle" x="0" y="0" width="24" height="24"></rect></g></g></svg> ${fileslabels.dataset.downloadLabel}</a>
                    </div>
              </div>  `
          
            document.getElementById('files-wrapper').innerHTML += fileInformation;
        })
    }
}

var data = JSON.parse(localStorage.getItem("userloggedindata"));

if (document.getElementById('redirectUrl') != null) {

    redirectUrl = document.getElementById('redirectUrl').value;
}

if (document.getElementById('contactOverviewUrl') != null) {

    contactOverviewUrl = document.getElementById('contactOverviewUrl').value;
}

if (document.getElementById('cancelRedirectUrl') != null) {

    cancelRedirectUrl = document.getElementById('cancelRedirectUrl').value;
}

$(".contact-form .toggle-steps").click(function () {
    if ($(this).hasClass("open")) {
        $(this).removeClass("open");
        $(this).siblings(".collapsible-panel").slideUp(200);

    } else {
        $(".contact-form .toggle-steps").removeClass("open");
        $(this).addClass("open");
        $(".collapsible-panel").slideUp(200);
        $(this).siblings(".collapsible-panel").slideDown(200);
    }
});

$(".tabs-inner a").click(function (e) {
    e.preventDefault();
    var currentTab = $(this).attr("id");
    $(".tabs").removeClass("selected");
    $(this).parent().parent().toggleClass("selected");
    $(".tab-panel").removeClass("show");
    $("#" + currentTab + "Content").addClass("show");
});

$('.emailkeyup').keyup(function () {
    var emailPrefer = $(this).val();
    
    if (emailPrefer.length > 3) {
        if (document.getElementById("contact-form-container").dataset.formtype == "edit") {
            if($(this).attr("data-label") != "Mobile Phone"){
            
                $(this).parents(".field-outer-wrapper").siblings(".email-checkbox").find("input").removeAttr('disabled');
                $(this).parents(".field-outer-wrapper").siblings(".email-checkbox").find(".input-wrapper").removeClass('disabled');
                
            }
        } else{
            $(this).parents(".field-outer-wrapper").siblings(".email-checkbox").find("input").removeAttr('disabled');
            $(this).parents(".field-outer-wrapper").siblings(".email-checkbox").find(".input-wrapper").removeClass('disabled');
            
        }
    } else {
        $(this).parents(".field-outer-wrapper").siblings(".email-checkbox").find("input").attr('disabled', 'disabled');
        $(this).parents(".field-outer-wrapper").siblings(".email-checkbox").find("input").prop('checked', false);
        $(this).parents(".field-outer-wrapper").siblings(".email-checkbox").find(".input-wrapper").addClass('disabled');
    }
});


$('input[name="phone"]').keyup(function () {
    this.value = this.value
        .match(/\d*/g).join('')
        .match(/(\d{0,3})(\d{0,3})(\d{0,4})/).slice(1).join('-')
        .replace(/-*$/g, '');
});

$(".save-continue").click(function () {
    var validator = $('#myForm').validate({

        errorPlacement: function (error, element) {
            if (element.attr("name") == "prefEmail") {
                error.insertBefore($(".workmailerror"));
            } else if (element.attr("name") == "prefphone") {
                error.insertBefore($(".workphoneerror"));
            } else {
                error.insertAfter(element);
            }
        },


        rules: {
            phone: {

                phone: true,
            },
            mailingPostalCode: {
                number: true,
            },
            physicalPostalCode: {
                number: true,
            },
            prefEmail: {
                required: true
            },
            prefphone: {
                required: true,
            },workEmail:{
                validate_email:true,
            },
            personalEmail:{
                validate_email:true,

            }


        },

        messages: {

            phone: {
                phone: "This field is invalid",

            },

            mailingPostalCode: {
                number: "Zipcode not valid",
            },
            physicalPostalCode: {
                number: "Zipcode not valid",
            },
            prefEmail: {
                required: "A preferred method of contact is required"
            },
            prefphone: {
                required: "A preferred method of contact is required"
            }
        }

    });
    var valid = true;
    var i = 0;
    var $inputs = $(this).parent(".button-group").siblings(".field-wrapper").find(".contact-all");

    $inputs.each(function () {
        if (!validator.element(this) && valid) {
            valid = false;
            $('#myForm').validate().settings.ignore = "";
        }
    });

    $(".contact-steps:nth-child(1)").each(function () {
        if ($(this).find(".error").not("label").length > 0) {
            $(this).find(".icon-style").addClass("no-validation")
        } else {
            $(this).find(".icon-style").addClass("ok-validation");
        }

    });

    if (valid) {

        $(".contact-form .toggle-steps").eq(1).click();
        $('#myForm').validate().settings.ignore = "";

    }
});

jQuery.validator.addMethod("phone", function (phone_number, element) {
    phone_number = phone_number.replace(/\s+/g, "");
    return this.optional(element) || phone_number.length > 9 &&
        phone_number.match(/^\(?[\d\s]{3}-[\d\s]{3}-[\d\s]{4}$/);
}, "Invalid phone number");

$.validator.addMethod("validate_email", function (value, element) {
    // only test for email address validity if something is entered
    if (value.length > 1) {
        if (/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(value)) {
            return true;
        } else {
            return false;
        }
    } else {
        return true;
    }
}, "Please enter a valid email address.");

//use link to submit form instead of button
$("#save-submit").click(function () {
    $('#myForm').validate({

        errorPlacement: function (error, element) {
            if (element.attr("name") == "prefEmail") {
                error.insertBefore($(".workmailerror"));
            } else if (element.attr("name") == "prefphone") {
                error.insertBefore($(".workphoneerror"));
            } else {
                error.insertAfter(element);
            }
        },

        ignore: [],
        rules: {
            phone: {

                phone: true,
            },
            mailingPostalCode: {
                number: true,
            },
            physicalPostalCode: {
                number: true,
            },
            prefEmail: {
                required: true
            },
            prefphone: {
                required: true,
            },workEmail:{
                validate_email:true,
            },
            personalEmail:{
                validate_email:true,

            }


        },

        messages: {

            phone: {
                phone: "This field is invalid",

            },

            mailingPostalCode: {
                number: "Zipcode not valid",
            },
            physicalPostalCode: {
                number: "Zipcode not valid",
            },
            prefEmail: {
                required: "A preferred method of contact is required"
            },
            prefphone: {
                required: "A preferred method of contact is required"
            }
        }

    });
    $("#myForm").submit();
    var acccount = 0,
        tabcount = 0;
    $(".contact-steps").each(function () {
        if ($(this).find(".error").not("label").length > 0) {
            $(this).find(".icon-style").addClass("no-validation");
            if (acccount == 0 && $(this).find(".open").length == 0) {
                $(this).find(".toggle-steps").click();
                acccount = 1;
            }


        } else {
            $(this).find(".icon-style").addClass("ok-validation");
        }

    });


    $(".tab-panel").each(function () {
        if ($(this).find(".error").not("label").length > 0) {
            for (i = 1; i < 4; i++) {
                if ($(this).hasClass('panel' + i)) {
                    $("#panel" + i).find(".icon-style-tab").addClass("no-validation");
                    if (tabcount == 0) {
                        $("#panel" + i).click();
                        tabcount = 1;
                    }
                }
            }
        } else {
            if ($(this).find("input").val() != "") {
                for (i = 1; i < 4; i++) {
                    if ($(this).hasClass('panel' + i)) {
                        $("#panel" + i).find(".icon-style-tab").addClass("ok-validation");
                    }
                }
            } else {
                for (i = 1; i < 4; i++) {
                    if ($(this).hasClass('panel' + i)) {
                        $("#panel" + i).find(".icon-style-tab").removeClass("no-validation");
                        $("#panel" + i).find(".icon-style-tab").removeClass("ok-validation");
                    }
                }
            }
        }

    });


});

if(document.getElementById("contact-form-container") !=null){
    if (document.getElementById("contact-form-container").dataset.formtype == "edit") {
         $(".emailkeyup").each(function () { 
            if($(this).attr('data-method') != "EMAIL" && $(this).attr('data-method') != "MOBILE") {
                $(this).attr("disabled","disabled");$(this).css("opacity","0.5");
                $(this).attr('placeholder', '');
            }
           
        
        });
    $('input[name$="mpaddress"]').parents(".basf-modal-wrap").css("opacity","0.5");
        $('input[name$="mpaddress"]').attr("disabled","disabled");
    }
}


$("#myForm").on("submit", function (event) {
    event.preventDefault();
    if ($("#myForm").valid()) {
        var contactAccountid, contactsegid, contacthierarchyLevel, contacttype, isprimary;
        if (document.getElementById("contact-form-container").dataset.formtype == "add") {

            contactAccountid = businessaccountid;
            contactsegid = parseInt(businesssegmentid);
            contacthierarchyLevel = businessgroup;
            contacttype = "add";
                isprimary = $('input[name="isPrimary"]:checked').val();

        } else {


            contactAccountid = contactOverviewOb.accountid;
            contactsegid = parseInt(businesssegmentid);
            contacthierarchyLevel = contactOverviewOb.group;
            contacttype = "edit";
            isprimary = JSON.parse($('input[name="isPrimary"]:checked').val());

        }



        const addContact = {
            "accountId": contactAccountid,
            "accBusSegId": contactsegid,
            "hierarchyLevel": contacthierarchyLevel,
            "lastName": $("input[name=lastname]").val(),
            "firstName": $("input[name=firstname]").val(),
            "role": $('select[name="role"]').find(":selected").val(),
            "title": $("input[name=contacttitle]").val(),
            "isPrimary": isprimary,
            "address": {
                "physicalCountry": data.userinfo.country,
                "physicalLine1": $("input[name=physicalLine1]").val(),
                "physicalLine2": $("input[name=physicalLine2]").val(),
                "physicalCity": $("input[name=physicalCity]").val(),
                "physicalProvince": $('select[name="physicalState"]').find(":selected").val(),
                "physicalPostal": $("input[name=physicalPostalCode]").val(),
                "mailingCountry": data.userinfo.country,
                "mailingLine1": $("input[name=mailingLine1]").val(),
                "mailingLine2": $("input[name=mailingLine2]").val(),
                "mailingCity": $("input[name=mailingCity]").val(),
                "mailingProvince": $('select[name="mailingState"]').find(":selected").val(),
                "mailingPostal": $("input[name=mailingPostalCode]").val()
            },
            "communications": []
        };

        var communications = addContact.communications;

        var editcontact = addContact;
         editaddress = addContact.address;
         var directMail = {
                            "methodOfContact": "DIRECT_MAIL",
                           "label": "Direct Mail",
                           "value": $('input[name="mpaddress"]:checked').val(),
                           "preferred": 1,
                           "textable": 0,
                            "type": contacttype
                        };

        if (document.getElementById("contact-form-container").dataset.formtype == "edit") {
            editcontact["type"] = "all";
            editcontact["contactId"] = contactOverviewOb.contactid;

        }

        if (document.getElementById("contact-form-container").dataset.formtype == "add") {

            communications.push(directMail);
        }

        $(".emailkeyup").each(function () {
            if ($(this).val() != "") {
                if ($(this).parents(".form-group").find(".radiocheckbox").prop("checked")) {
                    preferred = 1;
                    textable = 0;
                } else {
                    preferred = 0;
                    textable = 0;
                }

                var comItem = {
                    "methodOfContact": $(this).attr("data-method"),
                    "label": $(this).attr("data-label"),
                    "value": $(this).val(),
                    "preferred": preferred,
                    "textable": textable,

                };

                if ($(this).attr("data-value") != "" && $(this).attr("data-value") != null) {
                    comItem["type"] = "edit";
                } else {
                    comItem["type"] = "add";
                }

                communications.push(comItem);

            } else if($(this).attr("data-value") != "" && $(this).attr("data-value") != null) {
                if ($(this).parents(".form-group").find(".radiocheckbox").prop("checked")) {
                    preferred = 1;
                    textable = 0;
                } else {
                    preferred = 0;
                    textable = 0;
                }

                var comItem = {
                    "methodOfContact": $(this).attr("data-method"),
                    "label": $(this).attr("data-label"),
                    "value": $(this).val(),
                    "preferred": preferred,
                    "textable": textable,

                };

                comItem["type"] = "edit";
               
                communications.push(comItem);
            }




        });
        if (document.getElementById("contact-form-container") != null) {
            if (document.getElementById("contact-form-container").dataset.formtype == "add") {

                postAjaxRequest("POST", "/content/basfeupf/us/contactdetails.get_add_contact.json", addContact, addContactFun);
            } else {

                postAjaxRequest("POST", "/content/basfeupf/us/contactdetails.get_update_contact.json", addContact, addContactFun);
            }
        }

    }
});



function addContactFun(datacontact) {
    var parsedataContact = JSON.parse(datacontact);
    if (document.getElementById("contact-form-container").dataset.formtype == "add") {
         
        if(parsedataContact.message?.toLowerCase() == "contact already existed"){
            var contactAlreadyExist = document.getElementById("contactAlreadyExist").value;
            document.getElementById("alertMessage").innerHTML = contactAlreadyExist;
        }else if(parsedataContact.c_WorkEmail != undefined){
            var successMessage = document.getElementById("successMessage").value;
            document.getElementById("alertMessage").innerHTML = successMessage;
        } else{
            var errorMessage = document.getElementById("errorMessage").value;
            document.getElementById("alertMessage").innerHTML = errorMessage;
        }
            document.getElementById('ACthankyou').style.display = 'block';
    }else{
        if (parsedataContact != "" || parsedataContact != null) {
            location.href = contactOverviewUrl;
        } else {
            console.log(datacontact);
        }
    }

}

function closeWindow() {

    document.getElementById('ACthankyou').style.display = 'none';
    location.href = redirectUrl;
}

function cancellocation() {
    location.href = cancelRedirectUrl;
}