var countryList = [{name : "United States", "id" : "us"}, {name : "Canada", "id" : "ca"}];

function buildCountryListEl(el) {
    $(el).find('option').remove(); 
    for (i = countryList.length - 1; i >= 0; i--) {
            var countryOptionEntries =
                '<option value="' + countryList[i].id + '">' + countryList[i].name + '</option>'
            $(el).append(countryOptionEntries); 
    }
    $(el).multiselect({
        columns: 1,
        texts: {
            selectAll: "Select countries",
            placeholder: "- Choose  -",
        },
        selectAll: true,
    });
}

var languageList = [{name : "Spanish ", "id" : "es"},{name : "French", "id" : "fr"},{name : "English", "id" : "en"}];

function getLangNameViaCode(selectedLanguages, languageList) {
    const selectedLangArray = selectedLanguages.split(",");
    const res = [];

    languageList.forEach((lang, i) => {
        let currTrackerIndex = selectedLangArray.indexOf(lang.id);
        if (currTrackerIndex > -1) {
            res.push(lang.name);
        }
    })
    
    return res.join(",");
}

function objPropNullChecker(prop){
    return !!prop ? prop : ''
}

function applicationapicall() {

    $(".attribute-loader").show();
    var xhttp, i, applicationmanagement, AAMobj;
    xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {

        if (this.readyState == 4 && this.status == 200) {


            try {
                applicationmanagement = this.responseText;
                AAMobj = JSON.parse(applicationmanagement);
                if (AAMobj.errormsg.toLowerCase() == "success") {
                    $("#applistcontent .attributelistcontentlist").remove();
                    $(".attribute-loader").hide();

                    for (i = AAMobj.messgeId - 1; i >= 0; i--) {
                        var SAMrow1 = '<div class="attributelistcontentlist"><p>' + AAMobj.appsList[i].app_name + '</p><ul><li><a href="#applicationpopup" class="addnew appedit" onclick="getusergroup()" data-index="' + AAMobj.appsList[i].app_id + '"> <img  src="/apps/basfeupf/components/eupfAdmin/clientlibs/images/icon-edit.svg" alt=""> Edit</a></li><li><a href="#applicationdeletepopup" class="deleteapplication addnew" data-index="' + AAMobj.appsList[i].app_id + '" >  <img  src="/apps/basfeupf/components/eupfAdmin/clientlibs/images/icon-delete.svg" alt=""> Delete</a></li><li> <a href="#" id="applicationPreference" data-index="' + AAMobj.appsList[i].app_id + '"  data-info="' + AAMobj.appsList[i].app_name + '"> <img class="preferences-icon" src="/apps/basfeupf/components/eupfAdmin/clientlibs/images/icon-preferences.svg" alt="" > Preferences</a></li></ul></div>';
                        $("#applistcontent").append(SAMrow1);
                    }

                } else {
                    alert(AAMobj.errormsg.toLowerCase());
                }

            } catch (e) {
                $("#applistcontent").html(e.message);
            }
        }
    };
    xhttp.open("POST", "/content/basfeupf/us/admin.get_apps_list.json", true);
    xhttp.setRequestHeader("Content-Type", "application/json");
    xhttp.send(null);
}

function applicationpreferenceget(appprefid) {

    $(".attribute-loader").show();
    var xhttpAp, i, applicationpreferences, APobj;
    xhttpAp = new XMLHttpRequest();
    xhttpAp.onreadystatechange = function() {

        if (this.readyState == 4 && this.status == 200) {


            try {
                applicationpreferences = this.responseText;
                APobj = JSON.parse(applicationpreferences);
                if (APobj.errormsg.toLowerCase() == "success") {
                    $('#apppreferencedata .apppreferencedata').remove();
                    $('#apppreferencedata .pline').remove();

                    $("#applicationpreferenceForm .preferenceformlabel input").attr('data-index', appprefid);
                    $(".attribute-loader").hide();
                    for (i = APobj.messgeId - 1; i >= 0; i--) {

                        if (APobj.appSegmentAttributeMapList[i].mandatory_attrib == "Yes") {

                            var checked = "checked"
                        } else {

                            var checked = ""
                        }
                        /* if(APobj.appSegmentAttributeMapList[i].group_check == "Yes"){
                            var group_checked = "checked"
                        }else{
                            var group_checked = ""
                        } */

                        var SProw = '<div class="apppreferencedata"><p>' + APobj.appSegmentAttributeMapList[i].attrib_name + '</p><p>' + APobj.appSegmentAttributeMapList[i].segment_name + '</p><p>' + APobj.appSegmentAttributeMapList[i].account_type + '</p><p>' + APobj.appSegmentAttributeMapList[i].role + '</p><p>' + getLangNameViaCode(objPropNullChecker(APobj.appSegmentAttributeMapList[i].language), languageList) + '</p><p><label class="preeditable"><input type="checkbox" ' + checked + ' ><span class="checkmark"></span></label></p><p><a href="#apppredeletepopup"  class="deleteattribute addnew"  id="applicationdeletepreferences" data-index="' + APobj.appSegmentAttributeMapList[i].asa_id + '"  data-info="' + appprefid + '"><img class="delete-icon" src="/apps/basfeupf/components/eupfAdmin/clientlibs/images/icon-delete.svg" alt=""></a></p></div><div class="pline"></div>';
                        $("#apppreferencedata").append(SProw);

                        //groupBox Code
                        //<p><label class="preeditable"><input type="checkbox" '+ group_checked +' ><span class="checkmark"></span></label></p>
                    }

                    $("#appPreferedLanguage").find('option').remove(); 
                    for (i = languageList.length - 1; i >= 0; i--) {
                            var languageOptionEntries =
                                '<option value="' + languageList[i].id + '">' + languageList[i].name + '</option>';                    	
                            $("#appPreferedLanguage").append(languageOptionEntries); 
                    }
                    $("#appPreferedLanguage").multiselect({
                        columns: 1,
                        texts: {
                            selectAll: "Select Language",
                            placeholder: "- Choose  -",
                        },
                        selectAll: true,
                    });

                } else {
                    alert(APobj.errormsg.toLowerCase());
                }



            } catch (e) {
                $("#segpreferencedata").html(e.message);
            }
        }
    };
    xhttpAp.open("POST", "/content/basfeupf/us/admin.get_app_segment_attribute_map.json", true);
    xhttpAp.setRequestHeader("Content-Type", "application/json");
    xhttpAp.send(JSON.stringify({
        "app_id": appprefid
    }));

}

$(document).ready(function() {


    applicationapicall();


    $(".tabs-stagecontent").on("click", ".deleteapplication", function(event) {
        var id = $(this).attr("data-index");
        $('#applicationdeletepopup .formbut .done').attr('data-index', id);

    });

    $(".tabs-stagecontent").on("click", "#applicationdeletepreferences", function(event) {

        var id = $(this).attr("data-index");
        var appid = $(this).attr("data-info");
        $('#apppredeletepopup .formbut .done').attr('data-index', id);
        $('#apppredeletepopup .formbut .done').attr('data-info', appid);
    });

    $("#apppredeletepopup .formbut .done").click(function() {
        event.preventDefault();
        $(".attribute-loader").show();
        var applicationpdeleteid = $(this).attr("data-index");
        var applicationpid = $(this).attr("data-info");

        var xhttp, i, applicationdeletemanagement, APPPDobj;
        xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {

            if (this.readyState == 4 && this.status == 200) {


                try {
                    applicationdeletemanagement = this.responseText;
                    APPPDobj = JSON.parse(applicationdeletemanagement);
                    if (APPPDobj.errormsg.toLowerCase() == "success") {
                        $(".attribute-loader").hide();
                        applicationpreferenceget(applicationpid);
                        $(".cancel").click();

                    } else {
                        alert(APPPDobj.errormsg.toLowerCase());
                    }

                } catch (e) {
                    alert(e.message);

                }
            }
        };
        xhttp.open("POST", "/content/basfeupf/us/admin.delete_app_segment_attribute_map.json", true);
        xhttp.setRequestHeader("Content-Type", "application/json");
        xhttp.send(JSON.stringify({
            "asa_id": applicationpdeleteid
        }));



    });



    $("#applicationdeletepopup .formbut .done").click(function() {
        $(".attribute-loader").show();
        var attrib_id = $(this).attr("data-index");

        var xhttp, i, applicationdeletemanagement, APPDobj;
        xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {

            if (this.readyState == 4 && this.status == 200) {


                try {
                    applicationdeletemanagement = this.responseText;
                    APPDobj = JSON.parse(applicationdeletemanagement);
                    if (APPDobj.errormsg.toLowerCase() == "success") {
                        $(".attribute-loader").hide();
                        applicationapicall();
                        $(".cancel").click();

                    } else {
                        alert(APPDobj.errormsg.toLowerCase());
                    }

                } catch (e) {
                    alert(e.message);

                }
            }
        };
        xhttp.open("POST", "/content/basfeupf/us/admin.delete_app_detail.json", true);
        xhttp.setRequestHeader("Content-Type", "application/json");
        xhttp.send(JSON.stringify({
            "app_id": attrib_id
        }));


    });


    /********edit attribute *********/

    $(".tabs-stagecontent").on("click", ".appedit", function(event) {
        event.preventDefault();
        $(".attribute-loader").show();

        var id = $(this).attr("data-index");
        $('#applicationForm .submit').attr('data-index', id);
        var getattribute = "/content/basfeupf/us/admin.get_apps_list.json"
        appeditmanagement(id, getattribute);
    });

});
function disabledFieldCheckbox(){
    $('.apppopuplist').each(function () {
        var input = $(this).find('input, select');

        // Check if the current element should be excluded
        if (!$(this).is(':contains("User Group")') &&
            !$(this).is(':contains("Country")') &&
            !$(this).is(':contains("Require Group Check For Application Access")') &&
            !$(this).is(':contains("Request State Parameter")')){

            input.prop('disabled', $('#disabledFieldsCheckbox').prop('checked'));
            $(this).toggle(!$('#disabledFieldsCheckbox').prop('checked'));
        }
    });
}
function appeditmanagement(ids, getattributes) {

    var xhttp, i, appmanagement, AMobj;
    xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {

        if (this.readyState == 4 && this.status == 200) {

            try {
                appmanagement = this.responseText;
                AMobj = JSON.parse(appmanagement);
                
                if (AMobj.errormsg.toLowerCase() == "success") {
                    $(".attribute-loader").hide();
                    for (i = AMobj.messgeId - 1; i >= 0; i--) {
                        if (ids == AMobj.appsList[i].app_id) {
 							
                            $("#applicationname").val(AMobj.appsList[i].app_name);
                            $("#appreurl").val(AMobj.appsList[i].app_link);
                            $("#appimageurl").val(AMobj.appsList[i].app_image_path);
                            $("#appdesc").val(AMobj.appsList[i].app_description);
                            $("#clientsecret").val(AMobj.appsList[i].client_secret);
                            $("#clientid").val(AMobj.appsList[i].client_id);
                            $("#apptype").val(AMobj.appsList[i].app_type);
                            $("#linkedstatus").val(AMobj.appsList[i].linked_status);
                            $("#responsemode").val(AMobj.appsList[i].response_mode);
                            $("#responsetype").val(AMobj.appsList[i].response_type);
                            $("#scope").val(AMobj.appsList[i].scope);
                            $("#state").val(AMobj.appsList[i].state);
                            $("#theme").val(AMobj.appsList[i].theme);
                            $("#policy").val(AMobj.appsList[i].policy);
                            $("#azurelink").val(AMobj.appsList[i].azure_link);
                            $("#nonce").val(AMobj.appsList[i].nonce);
                            $("#openoption").val(AMobj.appsList[i].window_open_option);

                            $("#applogourl").val(AMobj.appsList[i].app_logo);
                            if (AMobj.appsList[i].group_check == "Yes") {
                                $(".isexternal input").prop("checked", true);
                            } else {
                                $(".isexternal input").prop("checked", false);
                            }
                            if (AMobj.appsList[i].active == "Yes") {
                                $(".editable input").prop("checked", true);
                            } else {
                                $(".editable input").prop("checked", false);
                            }
                            $('.apppopuplist').each(function () { 
                                var input = $(this).find('input, select'); 
                                    input.prop('disabled', '');
                                    $(this).removeAttr( 'style' ); 
                            });
                            AMobj.appsList[i].use_state == 'Yes' ? $(".appstate input").prop("checked", true) : $(".appstate input").prop("checked", false);
                            AMobj.appsList[i].app_state == 'Yes' ? $(".appState input").prop("checked", true) : $(".appState input").prop("checked", false);
                            AMobj.appsList[i].b2c_non_applicable == 'Yes' ? $(".b2cdisabled input").prop("checked", true) : $(".b2cdisabled input").prop("checked", false);
                            if(AMobj.appsList[i].b2c_non_applicable == 'Yes'){
                                disabledFieldCheckbox();
                            }
                            try {
                                var checkselect = AMobj.appsList[i].group_association;
                                //, selectgroup = "";
                                if (checkselect.indexOf(',') > -1) {
                                    var a = [];
                                    a = checkselect.split(',');
                                    for (var b = 0; b < a.length; b++) {
                                        for (var j = 0; j < $("#ms-list-3 ul li").length; j++) {
                                            var list = $("#ms-list-3 ul li label input")[j].value
                                            if (a[b] == list) {
                                                //$("#ms-list-3 ul li label input")[j].checked=true;
                                                //selectgroup += ($("#ms-list-3 ul li label input")[j].title)+","
                                                $("#usergroup option[value='" + a[b] + "']").prop("selected", "selected");
                                                $("#usergroup").multiselect("reload");
                                            }
                                        }
                                    }
                                    //selectgroup = selectgroup.slice(0,-1);
                                } else {
                                    for (var j = 0; j < $("#ms-list-3 ul li").length; j++) {
                                        var list = $("#ms-list-3 ul li label input")[j].value
                                        if (checkselect == list) {
                                            //$("#ms-list-3 ul li label input")[j].checked=true;
                                            //selectgroup = ($("#ms-list-3 ul li label input")[j].title);
                                            $("#usergroup option[value='" + checkselect + "']").prop("selected", "selected");
                                            $("#usergroup").multiselect("reload");
                                        }
                                    }
                                }

                                /* fill the country option box with value from api */
                                var checkCountryList = AMobj.appsList[i].country;

                                if (checkCountryList.indexOf(',') > -1) {
                                    var multiCountryArr = [];
                                    multiCountryArr = checkCountryList.split(',');    

                                    for (var x = 0; x < multiCountryArr.length; x++) {
                                       
                                        for (var k = 0; k < $("#ms-list-4 ul li").length; k++) {
                                            var countryValue = $("#ms-list-4 ul li label input")[k].value;
                                            
                                            if (multiCountryArr[x] == countryValue) {
												
                                                $("#selectCountries option[value='" + multiCountryArr[x] + "']").prop("selected", "selected");
                                                $("#selectCountries").multiselect("reload");
                                            }
                                        }
                                    }
                                    //selectgroup = selectgroup.slice(0,-1);
                                } else {
                                    for (var k = 0; k < $("#ms-list-4 ul li").length; k++) {
                                        
                                        var countryValue = $("#ms-list-4 ul li label input")[k].value

                                        if (checkCountryList == countryValue) {

                                            $("#selectCountries option[value='" + checkCountryList + "']").prop("selected", "selected");
                                            $("#selectCountries").multiselect("reload");
                                        }
                                    }
                                }

                            } catch (e) {

                            }
                            //$("#ms-list-3 span").text(selectgroup);
                            //$("#usergroup").attr("data-usergroup",checkselect);

                        }
                    }

                } else {
                    alert(AMobj.errormsg.toLowerCase());
                }

            } catch (e) {
                $("#applistcontent").html(e.message);
            }
        }
    };
    xhttp.open("POST", getattributes, true);
    xhttp.setRequestHeader("Content-Type", "application/json");
    xhttp.send(null);

}

function getusergroup() {
    var xhttp, i, usergroupmanagement, SAMobj;
    xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {

            try {
                usergroupmanagement = this.responseText;
                SAMobj = JSON.parse(usergroupmanagement);
                if (SAMobj.errormsg.toLowerCase() == "success") {
                    $('#usergroup').find('option').remove();
                    for (i = SAMobj.segmentsList.length - 1; i >= 0; i--) {
                        var Amrow2 =
                            '<option value="' + SAMobj.segmentsList[i].group_id + '">' + SAMobj.segmentsList[i].group_name + '</option>'
                        $("#usergroup").append(Amrow2);
                    }                    
                    //setTimeout(function(){
                    $("#usergroup").multiselect({
                        columns: 1,
                        texts: {
                            selectAll: "Select all that apply",
                            placeholder: "- Choose -",
                        },
                        selectAll: true,
                    });
                    // }, 1000);

                } else {
                    alert(SAMobj.errormsg.toLowerCase());
                }

                buildCountryListEl('#selectCountries');

            } catch (e) {
                $("#usergroup").html(e.message);
            }



        } else {

        }

    }
    xhttp.open("POST", "/content/basfeupf/us/admin.get_user_group_list.json", true);
    xhttp.setRequestHeader("Content-Type", "application/json");
    xhttp.send(null);
}

