function dccontactOverview(contactOverviewOb) {

    var preferredText = document.getElementById('preferredText')?document.getElementById('preferredText').value:"";
    var primaryText =document.getElementById('primaryText')? document.getElementById('primaryText').value:"";

    if ($('.dc-Container').find('.dc-ContactOverview').length != 0) {
        const contactdetail = {
            "contactId": contactOverviewOb.contactid,
            "accountId": contactOverviewOb.accountid,
            "accBusSegId": contactOverviewOb.segmentid,
            "hierarchyLevel": contactOverviewOb.group
        }

        postAjaxRequest("POST", "/content/basfeupf/us/contactdetails.get_contact_detail.json", contactdetail, contactDetail);

        function contactDetail(contactdata) {

            var contactdata = JSON.parse(contactdata);


            /****************banner**************/

            $(".brand-user .user-avatar span").text((contactdata.firstName).charAt(0) + (contactdata.lastName).charAt(0));
            $(".brand-user .user-info h1").text(contactdata.firstName + ", " + contactdata.lastName);
            $(".sub-title.role").text(contactdata.role);



            /**********page **************/
            $(".cntAccName").text(contactdata.cntAccName != null ? contactdata.cntAccName : "");
            $(".cntAccCity").text((contactdata.cntAccCity != null ? contactdata.cntAccCity : "") + (contactdata.cntAccProvince != null ?  "," + contactdata.cntAccProvince : ""));
            $(".cntAccBasfId").text(contactdata.cntAccBasfId != null ? "BASF ID " + contactdata.cntAccBasfId :"");
            if ($(".contactInfo .title").text(contactdata.title) != "") {
                $(".contactInfo .title").text(contactdata.title);
            } else {
                $(".contactInfoTitle.title").hide();
            }
            if (contactdata.isPrimary == "TRUE") {
                $(".isPrimary").text("Yes");
                $(".brand-pill").text(primaryText);
            } else {
                $(".isPrimary").text("No");
                $(".brand-pill").hide();
            }
            $(".physicalline1").text(contactdata.physical.line1);
            $(".physicalstate").text((contactdata.physical.city ? contactdata.physical.city + "," : "") + contactdata.physical.province + contactdata.physical.postal);
            $(".navigateto").attr("href", 'https://www.google.com/maps/dir/?api=1&destination=' + contactdata.physical.latitude + ',' + contactdata.physical.longitude);
            $(".mailingline2").text(contactdata.mailing.line1);
            $(".mailingstate").text((contactdata.mailing.city ? contactdata.mailing.city + "," : "") + contactdata.mailing.province + contactdata.mailing.postal)
            for (var i = 0; i < contactdata.communications.length; i++) {
                if (contactdata.communications[i].value != null && contactdata.communications[i].methodOfContact != "DIRECT_MAIL"  && contactdata.communications[i].value != "") {
                    var preferred
                    if (contactdata.communications[i].preferred != "0") {
                        preferred = "";
                    } else {
                        preferred = "hidden";
                    }
                    if (contactdata.communications[i].methodOfContact.includes("PHONE") || contactdata.communications[i].methodOfContact.includes("MOBILE")) {
                        $("#comPhone").show();
                        var communicationloop = `<div class="workEmail">
         <p class="prefered">${contactdata.communications[i].label} <span class="grey-pill ${preferred}">${preferredText}</span> </p>
             <p><a href="tel:${contactdata.communications[i].value}">${contactdata.communications[i].value}</a></p>
        </div>`;
                        document.getElementById('comPhone').innerHTML += communicationloop;
                    } else {
                        $("#comEmail").show();
                        var communicationloop = `<div class="workEmail">
      <p class="prefered">${contactdata.communications[i].label} <span class="grey-pill ${preferred}">${preferredText}</span> </p>
                <p ><a href="mailto:${contactdata.communications[i].value}">${contactdata.communications[i].value}</a></p>
        </div>`;
                        document.getElementById('comEmail').innerHTML += communicationloop;
                    }


                }
            }
        }
    }
}