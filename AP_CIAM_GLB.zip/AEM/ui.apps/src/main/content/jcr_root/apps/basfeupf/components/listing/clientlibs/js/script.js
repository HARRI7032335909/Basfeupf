var redirectURL = "";

var openLinkVia = "_blank";

var openInNewWindowRefKey = 'newWindow';

var app_tools_req = {
    "type": "get_app_id",
    "segment_id": 30
}

var app_list_req = {
    "type": "get_app_id",
    "segment_id": 30,
    "view_apps": ""
}

var app_tool_form_req = {
    "type": "get_app_data",
    "segment_id": 30,
    "app_id": "1",
    "EUPF_ID": "",
    "Request_Attribute": "APP",
    "Request_Type": "Fetch",
    "Account_Type": "",
    "Business_Segment_Id": "32",
    "Email_Address": "",
    "Lead_ID": ""
}

function navigateTo(url, via) {
    if(via == openInNewWindowRefKey) {
        var strWindowFeatures = "location=yes,height=570,width=800,scrollbars=yes,status=yes";
        window.open(url, "_blank", strWindowFeatures);
    } else {
        window.open(url, via);
    }
    
}

$(document).ready(function () {

    //populateTools();
    if (window.location.href.indexOf('app-center') != -1) {

        try {
            //                var data=JSON.parse(localStorage.getItem('userloggedindata'));
            //                if(data.userinfo.hasOwnProperty("groups")){
            //                    var usergroup = data.userinfo.groups;
            //                    var usergroupname="";
            //                    for(var i=0; i<usergroup.length; i++){
            //                        usergroupname = usergroupname + JSON.parse(data.userinfo.groups[i]).displayName+",";
            //                    }
            //                    app_tools_req.user_group=usergroupname.substring(0,usergroupname.length-1);
            //                }
            var data = JSON.parse(localStorage.getItem('userloggedindata'));
            var UserGroupRegexp = /^[a-zA-Z0-9-,]+$/;
            var CountryRegexp = /^[a-zA-Z0-9-_]+$/;
            if (data.userinfo.hasOwnProperty("groups")) {
                //var usergroup = data.userinfo.groups;
                if (data.userinfo.groups != "") {
                    var usergroupname = "";
                    var usergroupset = data.userinfo.groups.split(",");
                    for (var i = 0; i < usergroupset.length - 1; i++){
                        var usergroup = usergroupset[i].split(":");
                        usergroupname += usergroup[0] + ",";
                    }
                    var usergroupcheck = usergroupname.substring(0, usergroupname.length - 1);
                    if (usergroupcheck.search(UserGroupRegexp) !== -1)
                        { 
                            app_list_req.view_apps = encodeURIComponent(usergroupname.substring(0, usergroupname.length - 1));
                        }
                    } else {
                    var usergroupset = data.userinfo.groups;
                    var usergroupcheck = usergroupset;
                    if (usergroupcheck.search(UserGroupRegexp) !== -1)
                        { 
                            app_list_req.view_apps = encodeURIComponent(usergroupset);
                        }
                   
                }

            }
        } catch (e) {

        }
        var getCountryvalid  = getCountry();
        if (getCountryvalid.search(CountryRegexp) !== -1)
        { 
            app_list_req.country = encodeURIComponent(getCountry());
        } 
        postAjaxRequest("POST", "/content/basfeupf/us/formdata.json", app_list_req, populateTools);
    }
});
function RegisterAppCenterDOMEvents() {
    $('.gonow-link').on('click', function (event) {

        var lmsObj = generateLMSRequest();
        let lmsAppName= $("header").attr("data-app-name").toLowerCase() || "";
        if (event.currentTarget.getAttribute("data-appname").toLowerCase() == lmsAppName) {
            lmsObj["id_token"] = JSON.parse(localStorage.getItem("userloggedindata")).login.id_token;
            postAjaxRequest("POST", "/content/basfeupf/us/talendsavelms.json", lmsObj, "");
        }
        var data = JSON.parse(localStorage.getItem('userloggedindata'));
        app_tool_form_req.segment_id = localStorage.getItem('businesssegmentid');
        app_tool_form_req.app_id = $(event.currentTarget).data('appid');

        try {
            var userdatafrmstorage = JSON.parse(localStorage.getItem("userloggedindata"));
            var profileData = userdatafrmstorage.talendjson.Profile_Data;
            app_tool_form_req.EUPF_ID = userdatafrmstorage["userinfo"]["sub"];
            app_tool_form_req.Business_Segment_Id = localStorage.getItem('businesssegmentid');
            app_tool_form_req.Account_Type = localStorage.getItem('businessgroup');
            app_tool_form_req.Email_Address = userdatafrmstorage.userinfo.email;
            if (userdatafrmstorage.talendstatus == "Acknowledged") {
                if (profileData.hasOwnProperty('Lead_Id') && profileData.Lead_Id != '') {
                app_tool_form_req.Lead_ID = userdatafrmstorage["talendjson"]["Profile_Data"]["Lead_Id"];
                }
            } else {
                if (profileData.hasOwnProperty('Lead_ID') && profileData.Lead_ID != '') {
                app_tool_form_req.Lead_ID = userdatafrmstorage["talendjson"]["Profile_Data"]["Lead_ID"];
                }
            }
            app_tool_form_req["id_token"] = JSON.parse(localStorage.getItem("userloggedindata")).login.id_token;
            app_tool_form_req["language"] = getLanguage();
            if (data["talendstatus"].toUpperCase() == "LINKED") {
                app_tool_form_req.Contact_Id = userdatafrmstorage["talendjson"]["Profile_Data"]["Contact_Id"];
                app_tool_form_req.account_id = userdatafrmstorage["talendjson"]["Profile_Data"]["account_id"];
            }
        } catch (err) {
            console.error(err);
        }

        redirectURL = $(this).data('href');
        openLinkVia = $(this).data('openvia');
        if(event.currentTarget.getAttribute("data-b2cnonapplicable") === "Yes"){
            navigateTo(redirectURL, openLinkVia);
        } else{
            postAjaxRequest("POST", "/content/basfeupf/us/formdata.json", app_tool_form_req, populateAppForm);
        }
        // if (data["talendstatus"].toUpperCase() == "LINKED") {
        //     app_tool_form_req["id_token"] = JSON.parse(localStorage.getItem("userloggedindata")).login.id_token;
        //     postAjaxRequest("POST", "/content/basfeupf/us/formdata.json", app_tool_form_req, populateAppForm);
        // } else {
        //     // window.location.href = redirectURL;
        //     window.open(redirectURL, '_blank').focus();
        // }

        //
    });
}
function populateTools(data) {
    var response = JSON.parse(data);
    var basfTools = $(".eupf-basftools-content");
    basfTools.empty();
    if (response.data.length > 0) {
        response.data.forEach(function (e, i) {
            var link = "";
            if ( e.b2c_non_applicable === "Yes" || e.app_type == "saml" ) {
                link = e.app_link;
            }
            if (e.app_type == 'openid') {
                var nonce = e.nonce;
                var uilocale = "";
                try {
                    nonce = JSON.parse(localStorage.getItem('userloggedindata')).userinfo.nonce;
                    uilocale = "&ui_locales=" + JSON.parse(localStorage.getItem('userloggedindata')).userinfo.ui_locales;

                } catch (err) {

                }
                let useState = '';
                let appcontext = '';
                let appuri = '';
                var url = new URL(window.location.href);
                
                if (e.use_state == "No" && e.app_state == 'Yes' && url.searchParams.has('state')) {
					link = $('#sfcc_redirect_uri').val();
				} else if (e.use_state == "No" && e.app_state != 'Yes') {
                    if (url.searchParams.has('state')) {
                        useState = "&state=" + url.searchParams.get('state');
                    }
                    try {
                        appcontext = JSON.parse(localStorage.getItem('userloggedindata')).userinfo.appContext;
                        if (appcontext != undefined && appcontext != null) {
                            appcontext = "&appContext=" + appcontext;
                        }

                    } catch (err) {
                        appcontext = '';
                    }
                    try {
                        appuri = JSON.parse(localStorage.getItem('userloggedindata')).userinfo.appUri;
                        if (appuri != undefined && appuri != null) {
                            appuri = "&appUri=" + appuri;
                        }
                    } catch (err) {
                        appuri = '';
                    }
                   
                    link = e.azure_link + "?p=" + e.policy + "&client_id=" + e.client_id + "&nonce=" + nonce + "&redirect_uri=" + e.app_link + "&scope=" + e.scope + "&response_type=" + e.response_type + "&response_mode=" + e.response_mode + useState + "&theme=" + e.theme + uilocale + appcontext + appuri;

                } else {
                    if (e.state != '') {
                        useState = "&state=" + e.state;
                    }
                    try {
                        appcontext = "&appContext=" + JSON.parse(localStorage.getItem('userloggedindata')).userinfo.appContext;
                    } catch (err) {
                        appcontext = '';
                    }
                    try {
                        appuri = "&appUri=" + JSON.parse(localStorage.getItem('userloggedindata')).userinfo.appUri;
                    } catch (err) {
                        appuri = '';
                    }
                   
                    link = e.azure_link + "?p=" + e.policy + "&client_id=" + e.client_id + "&nonce=" + nonce + "&redirect_uri=" + e.app_link + "&scope=" + e.scope + "&response_type=" + e.response_type + "&response_mode=" + e.response_mode + useState + "&theme=" + e.theme + uilocale + appcontext + appuri;
                }

            }
            var card = `<div class="eupf-tools-content-repeat"><img class="banner-img hide-desktop show-mobile" src="${e["app_image_path"]}" alt="image"><div class="basftools-wraper" data-appid="${e["app_id"]}" data-apptype="${e["app_type"]}"><div class="tool-text-content"><div class="icon"><img src="${e["app_logo"]}" alt="" width="39px" height="40px"></div><div class="tooltitle">${e["app_name"]}</div><div class="tools-description">${e["app_description"]}</div><a data-href="${link}" data-b2cnonapplicable="${e["b2c_non_applicable"]}" data-openvia="${e["window_open_option"]}" data-appid="${e["app_id"]}" class="gonow-link" data-appname="${e["app_name"]}">Go Now</a></div> <img class="banner-img hide-mobile show-desktop" src="${e["app_image_path"]}" alt=""  width="256px" height="140px"></div></div>`
            basfTools.append($(card));
        });
        if (basfTools.children() === 0) {
            basfTools.remove();
        }
        document.querySelector(".basicpage").style.display = "block";
        RegisterAppCenterDOMEvents();
    }
}

/**
 * 
 * @param {object} prop  
 * a utility funtion to bullet proof an object property
 */
function bulletProofObjProp(prop) {
    return ( !!prop ) ? prop : ''; 
}


function populateAppForm(data) {
    
    //	https://basfusext.b2clogin.com/basfusext.onmicrosoft.com/B2C_1_EOP_Signin/oauth2/v2.0/authorize?
    // client_id=52891428-3395-4a1c-932c-42bc2596eace
    // &redirect_uri=https%3A%2F%2Fjwt.ms
    // &scope=openid%20offline_access
    // &response_type=id_token
    // &nonce=135679&state=login&theme=green&ui_locales=en
    $(".enrollment_form").empty();
    var datas = JSON.parse(data);
    var elements = datas.data;
    var domaindata = localStorage.getItem("userloggedindata")
    if ((datas.hasOwnProperty('allFieldsSubmitted') && datas['allFieldsSubmitted'] == true) || JSON.parse(domaindata).same_domain == true) {
        if (datas['allFieldsSubmitted'] == true || JSON.parse(domaindata).same_domain == true) {
            //window.location.href = redirectURL;
            navigateTo(redirectURL, openLinkVia);
        }
    } else {
        if (elements.length != 0) {
            var buttonHtml = `<div class="col-100">
            <button type="button" class="btn btn-continue matchMergeRedirect">Continue</button>
            <button type="button" class="btn btn-cancel cancelmodal">Cancel</button>
         </div>`;

            var htmlData = "",
                counter = 0,
                multiSelectOption = "",
                optionHtml = "";
            elements.forEach(function (eachData) {
                $('.tool_app_name').text(eachData['app_name']);
                counter++;
                if (eachData['attrib_type'] == 'text') {
                    htmlData += ` <div class="col-50">
                <label for="${eachData['attrib_name']}">${eachData['attrib_name']}</label>
                <input class="talandAppForm" type="text" data-mapid="${eachData['attrib_map_id']}" data-type="${eachData['crm_attrib_type']}" id="${eachData['attrib_name']}" name="${eachData['attrib_name']}" placeholder="" value="${bulletProofObjProp(eachData['attrib_value'])}" ${eachData['editable'] == 'No' ? 'readonly' : ''}>
             </div>`;
                } else if (eachData['attrib_type'].toLowerCase() == 'select') {
                    var value = eachData['default_value'].split('||');
                    if (!!eachData['attrib_value']) {
                        value.forEach(function (key, ind) {
                            if (eachData['attrib_value'] == key.split('|')[1]) {
                                optionHtml += `<option value="${key.split('|')[1]}" selected>${key.split('|')[0]}</option>`    
                            } else {
                               optionHtml += `<option value="${key.split('|')[1]}">${key.split('|')[0]}</option>`
                            }

                        });
                    } else {
                        value.forEach(function (key, ind) {
                            optionHtml += `<option value="${key.split('|')[1]}">${key.split('|')[0]}</option>`
                        });
                        optionHtml += `<option value="" disabled selected hidden>Select</option>`
                    }
                    htmlData += `<div class="col-50">
                <label for="${eachData['attrib_name']}">${eachData['attrib_name']}</label>
                <select id="${eachData['attrib_name']}" data-mapid="${eachData['attrib_map_id']}" data-type="${eachData['crm_attrib_type']}" class="select arrow-intrest ion-chevron-down talandAppForm" value="${bulletProofObjProp(eachData['attrib_value'])}" ${eachData['editable'].toLowerCase() == 'no' ? 'disabled' : ''}>
                  ${optionHtml}
                </select>
             </div>`;
                } else if (eachData.attrib_type === 'checkbox') {
                    htmlData += `<div class="col-50">
                                    <input class="talandAppForm" type="checkbox" data-mapid="${eachData['attrib_map_id']}" data-type="${eachData['crm_attrib_type']}" id="${eachData.attrib_name}" name="${eachData.attrib_name}">
                                    <label for="${eachData.attrib_name}"> ${eachData.attrib_name}</label>
                            </div>`;

                } 
                /** DONT DELETE THIS COMMENTED CODE: BELOW CODE NEED TO BE REVISITED BASED ON THE BACKLOG TICKET PRIORITY :*/
                // else if (eachData.attrib_type.toLowerCase() === 'multiselect1') {
                //     var values = eachData['attrib_value'].split('||');
                //     values.forEach(function (key, ind) {
                //         var checkecdValue = '';
                //         try {
                //             var checkvalue = eachData['attrib_value'].split(',');
                //             checkvalue.forEach(function (checkedKey) {
                //                 if (key.toLocaleLowerCase().startsWith(checkedKey.toLocaleLowerCase())) {
                //                     checkecdValue = 'checked';
                //                 }
                //             });
                //         } catch (err) {
                //             console.log(err);
                //         }
                //         multiSelectOption += `<li class="checkbox">
                //         <input type="checkbox" id="${key.split('|')[1]}" name="${key.split('|')[1]}" value="${key.split('|')[1]}" class="multi_checkbox">
                //         <label for="check-1">${key.split('|')[0]}</label>
                //      </li>`;
                //         // <option value="${key.split('|')[1]}">${key.split('|')[0]}</option>`
                //     });

                //     htmlData += `<div class="col-50">
                //     <label for="${eachData.attrib_name}">${eachData.attrib_name}</label>
                //     <dl class="dropdown">
                //        <dt>
                //           <a href="javascript:void(0)">
                //           <span data-mapid="${eachData['attrib_map_id']}" data-type="${eachData['crm_attrib_type']}" id="${eachData.attrib_name}" name="${eachData.attrib_name}" class="multi_select_placeholder">${typeof eachData.attrib_value != undefined ? eachData.attrib_value : 'Select All That Apply'}</span><span class="arrow-intrest ion-chevron-down"></span>
                //           </a>
                //        </dt>
                //        <dd>
                //           <div class="mutliSelect">
                //              <ul class="multiple_select">
                //                ${multiSelectOption}
                //              </ul>
                //           </div>
                //        </dd>
                //     </dl>
                //  </div>`;
                // }
            });
            if (counter % 2 != 0) {
                htmlData += `<div class="col-50"></div>`;
            }
            $('.enrollment_form').append(htmlData);
            $('.enrollment_form').append(buttonHtml);
            showmultiselectoption();
            $('#enrolment').show();
            $('.multi_checkbox').on('click', function () {
                multicheckbox(event);
            })

        } else {
            // alert("Array is blank");
            window.location.href = $('.gonow-link').data('href');
            // $('.basftools-wraper').attr('data-id');
            // $('.basftools-wraper').attr('data-apptype');
            //redirect url logic implement
        }

    }


    $('.matchMergeRedirect').on('click', function () {
        var data = JSON.parse(localStorage.getItem('userloggedindata'));
        //data['talend']['ContactId'], data['talend']['Account_BASF_ID']
        var Contact_Id, Account_BASF_ID;
        var validForm = true;
        $('.talandAppForm:visible').each(function () {
            if ($(this).val() == "" || $(this).val() === undefined) {
                validForm = false;

            }
        });

        if (!validForm) {
            $(".global-error-red").show();
            $(".global-success").hide();
            $('#enrolment').hide();
            // $('html, body').animate({
            //     scrollTo: $('.global-error-red').offset().top
            // }, 500);
            window.scrollTo($('.global-error-red').offset());
            return false;

        }
        try {
            var userdatafrmstorage = JSON.parse(localStorage.getItem("userloggedindata"));
            Contact_Id = userdatafrmstorage["talendjson"]["Profile_Data"]["Contact_Id"];
            Account_BASF_ID = userdatafrmstorage["talendjson"]["Profile_Data"]["account_id"];
        } catch (err) {
            console.error(err);
        }

        var obj = generateRequest(data['userinfo']['sub'], "App", "Update", Contact_Id, Account_BASF_ID, localStorage.getItem('userselectedaccount'), $("select.segment-div option:selected").text());
        var lmsObj = generateLMSRequest();
        let lmsAppName= $("header").attr("data-app-name").toLowerCase() || "";
        if ($('.tool_app_name').text().toLowerCase() == lmsAppName) {
            lmsObj["id_token"] = JSON.parse(localStorage.getItem("userloggedindata")).login.id_token;
            postAjaxRequest("POST", "/content/basfeupf/us/talendsavelms.json", lmsObj, "");
        }
        obj["id_token"] = JSON.parse(localStorage.getItem("userloggedindata")).login.id_token;
        postAjaxRequest("POST", "/content/basfeupf/us/talendsave.json", obj, matchmergeResponse);
    });
    $('.cancelmodal').on('click', function () {
        var x = document.getElementById("enrolment");
        x.style.display = "none";
    });
}

function matchmergeResponse(data) {
    $('.cancelmodal').trigger('click');
    if (JSON.parse(data)["talendresponse"]["responseMessage"].toLocaleLowerCase() === 'success') {
        navigateTo(redirectURL, openLinkVia);
    } else {
        $('.form-error-text').text('We get Error in response.Somethings went wrong');
        $(".global-error-red").show();

    }
    $('html, body').animate({
        scrollTop: 0
    }, 'slow');
}

function generateLMSRequest() {

    var lmsReq = {
        "name": "Charles Wagner", //jwt
        "email": "charles.wagner@gmail.com", //jwt
        "application_name": "LMX", //constant
        "ext_Portal_UUID": "<Azure B2C Unique Object ID>", //sub
        "country": "US", //jwt
        "Lead_ID": "",
        "contact_id": "", //DB
        "account_types": [],
        "application_attributes": {
            "LMX": {
                "userType": "INTERNAL", //constant
                "adobe_uuid": "", // blank
                "profile": "External Learner",
                "type": "user"
            }
        }
    }

    var data = JSON.parse(localStorage.getItem('userloggedindata'));
    var profileData = data.talendjson.Profile_Data;
    lmsReq.name = data.userinfo.firstname + " " + data.userinfo.lastname;
    lmsReq.email = data.userinfo.email;
    lmsReq.ext_Portal_UUID = data.userinfo.sub;
    lmsReq.country = data.userinfo.country;
    lmsReq.contact_id = data.talendjson.Profile_Data.Contact_Id;
    try {
        if (data.talendstatus == "Acknowledged") {
            if (profileData.hasOwnProperty('Lead_Id') && profileData.Lead_Id != '') {
            lmsReq.Lead_ID = data["talendjson"]["Profile_Data"]["Lead_Id"];
            }
        } else {
            if (profileData.hasOwnProperty('Lead_ID') && profileData.Lead_ID != '') {
            lmsReq.Lead_ID = data["talendjson"]["Profile_Data"]["Lead_ID"];
            }
        }
        lmsReq.account_types = data["talendjson"]["Profile_Data"]["Account_Types"];
    } catch (err) {
        console.log(err);
    }
    return lmsReq;
}

function multicheckbox(event) {
    var data = $(event.currentTarget);
    var parent = data.parents('.dropdown');
    var input = parent.find('.multi_select_placeholder');
    var checkboxContainer = data.parents('.multiple_select');
    var value = checkboxContainer.find('.multi_checkbox:checked').map(function () {
        return $(this).val();
    }).get().join(',');
    input.text(value);
}