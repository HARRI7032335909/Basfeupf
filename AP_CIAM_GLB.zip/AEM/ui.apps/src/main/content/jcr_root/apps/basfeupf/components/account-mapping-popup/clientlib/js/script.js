var accMappingObj = {
    grant_type: "client_credentials",
    scope: "https://graph.microsoft.com/.default",
    contactId: "",
    account_id: "",
    sub: "",
    type: "update_user_linked_user",
    userObj: {}
}
var mdmAccMapping = {
    "type": "account_mapping",
    "Request_Type": "AccountMapping",
    "Request_Attribute": "Profile",
    "EUPF_ID": "",
    "Email_Address": "",
    "Lead_ID": "",
    "Contact_Id": ""
}
const azureExtNo = $('#azure_extension_no').val();
var accountDetails;

function populateAccouts(data) {
    // if (localStorage.hasOwnProperty('userloggedindata') && JSON.parse(localStorage.getItem('userloggedindata')).talendstatus != 'Acknowledged') {
    //     accountDetails = JSON.parse(localStorage.getItem('userloggedindata')).talendjson.Profile_Data.Accounts;
    //     if (accountDetails.length > 1) {
    //         accountDetails.forEach(element => {
    //             let option = document.createElement('option');
    //             option.setAttribute('data-id', element.account_id);
    //             option.text = element.account_name;
    //             $('.accountpopup').find('select').append(option);
    //         });

    //         $('.accountpopup select').niceSelect();

    //     }
    // }
    $('.accountpopup select').niceSelect('destroy');
    $('.accountpopup select').children().remove()

    data = JSON.parse(data);
    if (data.hasOwnProperty("responseMessage") && data["responseMessage"] == 'Success') {
        const accounts = data['Profile_Data']['Accounts'];
        if (accounts.length > 1) {
            accounts.forEach(element => {
                let option = document.createElement('option');
                option.setAttribute('value', element.account_id);
                option.text = element.account_name + '&emsp;' + element.state + '&emsp;' + element.Zipcode;
                $('.accountpopup').find('select').append(option);
            });

            $('.accountpopup select').niceSelect();
            toggleAccountPopup();
        }
    }
}

function toggleAccountPopup() {
    if ($('.accountpopup').is(":visible")) {
        $('.accountpopup').hide();
        $('.accountpopup .backgroundpopup').hide();
    } else {
        $('.accountpopup').show();
        $('.accountpopup .backgroundpopup').show();
    }
}

$('.accountpopup input[type=button]').on('click', () => {
    //url redirect-linkstoring
    var redirectlink = localStorage.getItem("link"); 
    // const selectedAccId = $('.accountpopup select :selected').data('id');
    const selectedAccId = $('.accountpopup select :selected').val();
    const userdata = JSON.parse(localStorage.getItem('userloggedindata'));
    localStorage.setItem('accountID', selectedAccId);
    localStorage.setItem("businessaccountid", selectedAccId); 
   localStorage.setItem('multiAccountUser', 'Yes');
   localStorage.setItem('dcMultiAccountUser','Yes');
    const contactId = userdata['talendjson']['Profile_Data']['Contact_Id'];
    accMappingObj.account_id = selectedAccId;
    accMappingObj.contactId = contactId;
    accMappingObj.sub = userdata['userinfo']['sub'];

    accMappingObj.userObj['extension_' + azureExtNo + '_contact_id'] = contactId;
    accMappingObj.userObj['extension_' + azureExtNo + '_account_number'] = selectedAccId;

    postAjaxRequest("POST", "/content/basfeupf/us/formdata.json", accMappingObj, reLogin);

    function reLogin() {
        const state = 'login';
        const id_token = userdata['login']['id_token'];
        getAjaxRequest('GET', "/content/basfeupf/us/generatevalidatetoken.json?code=&state=" + state + "&id_token=" + id_token + "&language="+ getLanguage() + "&country=" + getCountry(), {}, saveUserLogInData);
        toggleAccountPopup();
    }
    if (userdata.origin == 'different') {  
        $("#enrolment").css("z-index","9");                 
    } 
    //show accountpopup before redirection
    if(userdata.merged != undefined && userdata.merged.allFieldsSubmitted != undefined){
        if (userdata.merged.allFieldsSubmitted){
        if (userdata.origin == 'different' && redirectlink != "") { 
            localStorage.removeItem("link");
           
            var data = JSON.parse(localStorage.getItem('userloggedindata'));
            var pid = '';
            var accountid = '';
            var contactid = '';
            var bs = '';
            var profileData = data.talendjson.Profile_Data;
            
            if (profileData.hasOwnProperty('Lead_Id') && profileData.Lead_Id != '') {
            pid = "&pid=" + data.talendjson.Profile_Data.Lead_Id;
            }
            else if (profileData.hasOwnProperty('Lead_ID') && profileData.Lead_ID != '') {
            pid = "&pid=" + data.talendjson.Profile_Data.Lead_ID;
            }
            if (profileData.hasOwnProperty('Contact_Id') && profileData.Contact_Id != '') {
            contactid = "&cid=" + data.talendjson.Profile_Data.Contact_Id;
            }
            if (localStorage.getItem('accountID')!= null && localStorage.getItem('accountID')!= undefined) {
                accountid = "&an=" + localStorage.getItem('accountID');
            }
            let userinfo = data.userinfo;
            if (userinfo.hasOwnProperty('extension_bs') && userinfo.extension_bs != '') {
            bs = "&bs=" + data.userinfo.extension_bs;
            }
            window.location.href = redirectlink+ pid + bs + contactid + accountid;
                            
        }
        } 
    }
  
});