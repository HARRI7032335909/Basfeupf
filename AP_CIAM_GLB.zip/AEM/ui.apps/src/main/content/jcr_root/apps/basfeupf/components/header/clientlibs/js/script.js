var toggleLoader = (function () {
    var arr = [];
    return function (bool) {
        if (bool) {
            arr.push("loaderActive");
            $('.eupf-loader').css("display", "flex");
        } else if (!bool) {
            arr.pop();
            if (arr.length == 0) {
                $('.eupf-loader').hide();
            }

        }
    }
})()
if (window.location.href.includes("app-center") && !window.top.location.href.includes('/editor.html/')) {
    toggleLoader(true);
}
if(window.top.location.href.includes('/editor.html/')){
    toggleLoader(false);
}



// var x, i, j, l, ll, selElmnt, a, b, c;
// /*look for any elements with the class "custom-select":*/
// x = document.getElementsByClassName("custom-select");
// l = x.length;
// for (i = 0; i < l; i++) {
//     selElmnt = x[i].getElementsByTagName("select")[0];
//     ll = selElmnt.length;
//     if (ll > 0) {
//         /*for each element, create a new DIV that will act as the selected item:*/
//         a = document.createElement("DIV");
//         a.setAttribute("class", "select-selected");
//         a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
//         x[i].appendChild(a);
//         /*for each element, create a new DIV that will contain the option list:*/
//         b = document.createElement("DIV");
//         b.setAttribute("class", "select-items select-hide");
//         for (j = 1; j < ll; j++) {
//             /*for each option in the original select element,
//             create a new DIV that will act as an option item:*/
//             c = document.createElement("DIV");
//             c.innerHTML = selElmnt.options[j].innerHTML;
//             c.addEventListener("click", function (e) {
//                 /*when an item is clicked, update the original select box,
//                 and the selected item:*/
//                 var y, i, k, s, h, sl, yl;
//                 s = this.parentNode.parentNode.getElementsByTagName("select")[0];
//                 sl = s.length;
//                 h = this.parentNode.previousSibling;
//                 for (i = 0; i < sl; i++) {
//                     if (s.options[i].innerHTML == this.innerHTML) {
//                         s.selectedIndex = i;
//                         h.innerHTML = this.innerHTML;
//                         y = this.parentNode.getElementsByClassName("same-as-selected");
//                         yl = y.length;
//                         for (k = 0; k < yl; k++) {
//                             y[k].removeAttribute("class");
//                         }
//                         this.setAttribute("class", "same-as-selected");
//                         break;
//                     }
//                 }
//                 h.click();
//             });
//             b.appendChild(c);
//         }
//         x[i].appendChild(b);
//         a.addEventListener("click", function (e) {
//             /*when the select box is clicked, close any other select boxes,
//             and open/close the current select box:*/
//             e.stopPropagation();
//             closeAllSelect(this);
//             this.nextSibling.classList.toggle("select-hide");
//             this.classList.toggle("select-arrow-active");
//         });
//     }

// }

// function closeAllSelect(elmnt) {
//     /*a function that will close all select boxes in the document,
//     except the current select box:*/
//     var x, y, i, xl, yl, arrNo = [];
//     x = document.getElementsByClassName("select-items");
//     y = document.getElementsByClassName("select-selected");
//     xl = x.length;
//     yl = y.length;
//     for (i = 0; i < yl; i++) {
//         if (elmnt == y[i]) {
//             arrNo.push(i)
//         } else {
//             y[i].classList.remove("select-arrow-active");
//         }
//     }
//     for (i = 0; i < xl; i++) {
//         if (arrNo.indexOf(i)) {
//             x[i].classList.add("select-hide");
//         }
//     }
// }
// /*if the user clicks anywhere outside the select box,
// then close all select boxes:*/
// document.addEventListener("click", closeAllSelect);
$('.retailerdrop select').niceSelect();
$(".main-menu .menu-container .view-list-con span").click(function () {

    $(".main-menu .menu-container .view-list-con ul").show();
});
$('body').click(function (e) {
    if (!$(e.target).closest('.main-menu .menu-container .view-as-wrapper').length) {
        $(".main-menu .menu-container .view-list-con ul").hide();
    }
});
var cdata;
var inputFieldData;
var accSegmentId;
//document.addEventListener("DOMContentLoaded", function () {
$(window).on('load', function () {
    if (window.location.href.indexOf('internal.html') > -1) {
        return false;
    }
    if ($('.page-general-error').length > 0) {
        $('.main-menu').css("display", "none");
    }

    try {
        var error = getUrlParameter('error');
        var error_description = getUrlParameter('error_description');

        if (error == "access_denied" && error_description.indexOf('AADB2C90091') > -1) {
            window.location.href = "/content/basfeupf/us/en/my-profile.html";
            return;

        }

    } catch (error) {}
    /* alert("Welcome User"); */
    if (localStorage.getItem("logout") === null) {

        try {
            var accessCode = getUrlParameter('code');
            var id_token = getUrlParameter('id_token');
            var state = getUrlParameter('state');
            var error_description = getUrlParameter('error_description');

            if (error_description != null && error_description != '') {
                window.location.href = "/content/basfeupf/us/en/error.html";

            }

            if (state == 'abort') {
                if (!sessionStorage.hasOwnProperty('updatepassword')) {
                    window.location.href = "/us/en/azure-registration.html";
                }
            }

            try {
                if (localStorage.getItem("reset_password") != null) {
                    if (localStorage.getItem("reset_password") == 'yes') {
                        localStorage.removeItem("reset_password");

                        var update_reset_password_cookie = {
                            "id_token": id_token,
                            "state": state,
                            "code": accessCode,
                            "type": "update_reset_password_cookie",
                            "scope": "B2C_1A_PasswordChange"
                        }
                        postAjaxRequest("POST", "/content/basfeupf/us/formdata.json", update_reset_password_cookie, "");
                    }


                }

            } catch (error) {}

            checkLoginAjaxRequest().then(function (responsedata) {
                var isLogin = checklogin(responsedata);
                if ((accessCode != null && accessCode != '') || (id_token != null && id_token != '')) {
                    if (isLogin) {
                        if ("userloggedindata" in localStorage) {
                            var data = localStorage.getItem("userloggedindata");
                            // User navigates to apps-center pages from Direct application - PlantHealth
                            if ((accessCode != null && accessCode != '' && JSON.parse(data).origin == 'different') ||
                                  (id_token != null && id_token != '' && JSON.parse(data).origin == 'different')) {
								getInitialData(accessCode, state, id_token);
							} else {
								saveUserLogInData(data);
							}
                            //selectedDropDwnValue(data);
                        }
                    } else {
                        if (window.location.href.indexOf('/app-center') > -1 || window.location.href.indexOf('/my-profile') > -1) {
                            getInitialData(accessCode, state, id_token);
                        }

                    }

                } else {
                    if (isLogin) {

                        var data = localStorage.getItem("userloggedindata");

                        if (JSON.parse(data).hasOwnProperty('redirect')) {
                            if (JSON.parse(data).redirect == true) {
                                return false;
                            }
                            // window.location.href = "/content/basfeupf/us/en/error.html";

                        }
                        //geteditdata();
                        saveUserLogInData(data)
                        //  if (localStorage.getItem("user_information") === null) {
                        //postAjaxRequest("POST", "/content/basfeupf/us/talend.json", null, selectedDropDwnValue);
                        // } else {

                        //selectedDropDwnValue(data);
                        try {
                            if (localStorage.hasOwnProperty('userselectedaccount')) {
                                var select_acc = document.getElementsByClassName("profile-type-select")[0];
                                createSegment(select_acc.options[select_acc.selectedIndex].text);
                            }
                        } catch (err) {
                            var jdata = JSON.parse(localStorage.getItem("userloggedindata"));
                            basicInfoPopulation(jdata.userinfo);
                        }

                        // }
                    } else {
                        /* alert("You are not Login"); */

                        localStorage.clear();
                        if (location.href.indexOf("success.html") == -1 && location.href.indexOf("error.html") == -1 && location.href.indexOf("azure-registration.html") == -1 && window.top.location.href.indexOf("editor.html") == -1) {
                            location.href = document.getElementById("segmentid-nonlogedin").value;

                        }
                    }

                }
            })


        } catch (err) {
            //  console.log("ERROR!!!!!" + err);
        }
    } else {
        redirection();
    }

    if (window.location.href.indexOf('/app') > -1) {
        $('.nav-link a').eq(0).addClass('active');
        $('.main-menu .menu-container #switchuser-type-dropdown').show();
    }
    if (window.location.href.indexOf('/my-profile') > -1) {
        $('.nav-link a').eq(1).addClass('active');
        $('.main-menu .menu-container #switchuser-type-dropdown').hide();
    }

    // tabbed content

    $(".tab_content").hide();
    $(".tab_content:first").show();

    refreshEventsListener();
    /* Extra class "tab_last" to add border to right side of last tab */
    $('ul.tabs li').last().addClass("tab_last");

    /*Form Validation*/
    // default jquery validation apply for lite user and made specific changes for Full and invite based user on the basis of account access mode flag
    //phone number validation
    jQuery.validator.addMethod("phoneNumberFormat", function (value, element) {
        return this.optional(element) || /^\D?(\d{3})\D?\D?(\d{3})\D?(\d{4})$/i.test(value);
    }, "Please enter 10 digit phone number");
    jQuery.validator.addMethod("numericdashe", function (value, element) {
        if (/^[0-9\-]+$/i.test(value)) {
            return true;
        } else {
            return false;
        };
    }, "Please enter 10 digit phone number");

    $(".personal-info-form, .business-info-form").each(function() {
        $(this).validate({
        ignore: [':not(checkbox:hidden)'],
        focusInvalid: false,
        invalidHandler: function (form, validator) {
            if (!validator.numberOfInvalids())
                return;

            $('html, body').animate({
                scrollTop: $(validator.errorList[0].element).offset().top
            }, 500);            
            $(".global-success").hide();
        },
        rules: {
            firstname: {
                required: true,
                maxlength: 64,
            },
            lastname: {
                required: true,
                maxlength: 64
            },
            email: {
                required: true,
                email: true
            },
            phone: {
                required: true,
                phoneNumberFormat: true,
                numericdashe: true
            },
            mobile: {
                phoneNumberFormat: true
            },

            mailaddress: {
                required:function() {
						let newObject = window.localStorage.getItem("userloggedindata");
						var newValidation = JSON.parse(newObject);
	                    return newValidation.userinfo.account_access_mode =="FULL" || newValidation.userinfo.account_access_mode == undefined;
                 },
                maxlength: 1024
            },
            city: {
                required: function() {

                    let newObject = window.localStorage.getItem("userloggedindata");
                    var newValidation = JSON.parse(newObject);
                    return newValidation.userinfo.account_access_mode =="FULL" || newValidation.userinfo.account_access_mode == undefined;
             },
            
                maxlength: 128
            },
            state:{
				required: function() {
						let newObject = window.localStorage.getItem("userloggedindata");
						var newValidation = JSON.parse(newObject);
	                    return newValidation.userinfo.account_access_mode =="FULL" || newValidation.userinfo.account_access_mode == undefined;
                 }
			},
			country:{
				required: function() {
						let newObject = window.localStorage.getItem("userloggedindata");
						var newValidation = JSON.parse(newObject);
	                    return newValidation.userinfo.account_access_mode =="FULL" || newValidation.userinfo.account_access_mode == undefined;
                 }			
			},
			lang: {
				required: function() {
						let newObject = window.localStorage.getItem("userloggedindata");
						var newValidation = JSON.parse(newObject);
	                    return newValidation.userinfo.account_access_mode =="FULL" || newValidation.userinfo.account_access_mode == undefined;
                 }
			},
			customertype:{
				required:true
			},

            zipcode: {
                required: true,
                digits: true,
                maxlength: 40
            },
            leagalreview: {
                required: false
            },
            businessName: {
				required: false
			}
			
        },
        // Specify validation error messages
        messages: {
            firstname: {
                required: "Please enter your First Name.",
                maxlength: "Your name should not exceed 64 characters."
            },
            lastname: {
                required: "Please enter your Last Name.",
                maxlength: "Your name should not exceed 64 characters."
            },
            leagalreview: {
                required: "Please accept SMS/text messaging terms and conditions."
            },
            city: "Please enter your City.",
            state: "Please enter your State.",
            country: "Please enter your Country.",
            lang: "Please enter your language.",
            email: "Please enter a valid Email Address",
            mailaddress: "Please enter Mailing Address",
            zipcode: "Must be all numbers."
        },

        errorPlacement: function (error, element) {
            console.log('dd', element.attr("name"))
            if (element.attr("name") == "leagalreview") {
                error.appendTo("#legalErrorBox");
            } else {
                error.insertAfter(element)
            }
        },

        debug: true,
        errorClass: 'error-element',
        validClass: 'success',
        highlight: function (element, errorClass, validClass) {
            $(element).parents("div.col").addClass(errorClass).removeClass(validClass);
        },
        unhighlight: function (element, errorClass, validClass) {
            $(element).parents(".error-element").removeClass(errorClass).addClass(validClass);
        },
        // Make sure the form is submitted to the destination defined
        // in the "action" attribute of the form when valid
        submitHandler: function (form) {
            if ($(".col .error").length > 1) {
                //  console.log("test");
                $(".col").addClass("error-element");
            }

        }

    });

}); 
// hide error messages on click of close btn
$(".close-btn").on("click", function () {
    $(".global-error").hide();
    $(".modal").hide();
});  

});

function checkLoginAjaxRequest() {

    return new Promise(function (resolve, reject) {
        var xhr = new XMLHttpRequest();
        xhr.onload = function () {
            resolve(this.responseText);
            // checklogin(this.responseText)
        };

        xhr.onerror = function () {
            reject(new Error("Some thing went wrong"));
        }
        let requestJson = '';
        if (localStorage.getItem('userloggedindata') !== null) {
            requestJson = JSON.stringify(JSON.parse(localStorage.getItem("userloggedindata")).login);
            if (sessionStorage.hasOwnProperty('updatepassword') && window.location.href.indexOf('/app-center') > -1) {
                requestJson = '';
            }
            if (sessionStorage.hasOwnProperty('updatepassword') && window.location.href.indexOf('/my-profile') > -1) {
                sessionStorage.removeItem('updatepassword');
            }
        }
        xhr.open("POST", "/content/basfeupf/us/checklogin.json");
        xhr.send(requestJson);

    });
}

function checklogin(logindata) {
    var status = JSON.parse(logindata).status;
    if (status == 'success') {
        return true;
    } else {
        toggleLoader(false);
        return false;
    }
}

cdata = {
    "root": {
        "ContactData": {
            "Status": "Linked",
            "EUPF_ID": "222",
            "Email_Address": "Kory@gmail.com",
            "Contact_First_Name": "kory",
            "Contact_Last_Name": "Hayenga",
            "Mailing_Address": "123 Oak Glen",
            "City": "abc",
            "State": "CA",
            "Zipcode": "92618",
            "Country": "US",
            "Phone_Number": "12345678",
            "Account_ID": "56789",
            "Business_Name": "Corp",
            "Requested_Business_Segment": "Turf & Ornamental",
            "ContactId": "1234",
            "Email_Opt_In": "Yes",
            "Preferred_Language": "English",
            "Mobile_Phone": "87654321",
            "AccountType": [{
                    "account_type": "Distributor-Retailer",
                    "Segment": [{
                            "bus_segment_id": "2",
                            "bus_segment_name": "Farming"
                        },
                        {
                            "bus_segment_id": "3",
                            "bus_segment_name": "PCS"
                        }
                    ]
                },
                {
                    "account_type": "Enduser / Grower",
                    "Segment": [{
                            "bus_segment_id": "4",
                            "bus_segment_name": "Turf"
                        },
                        {
                            "bus_segment_id": "5",
                            "bus_segment_name": "Ornamental"
                        },
                        {
                            "bus_segment_id": "6",
                            "bus_segment_name": "ProVM"
                        }
                    ]
                }
            ]
        }
    }
}

inputFieldData = {
    "2": [{
            "attribute_label": "Firstname",
            "attribute_placeholder": "Enter your firstname",
            "attribute_type": "text",
            "attribute_name": "firstname"
        },
        {
            "attribute_label": "Lastname",
            "attribute_placeholder": "Enter your lastname",
            "attribute_type": "text",
            "attribute_name": "lastname"
        },
        {
            "attribute_label": "Lastname",
            "attribute_placeholder": "Enter your lastname",
            "attribute_type": "text",
            "attribute_name": "lastname"
        },
        {
            "attribute_label": "Lastname",
            "attribute_placeholder": "Enter your lastname",
            "attribute_type": "text",
            "attribute_name": "lastname"
        }
    ],
    "3": [{
            "attribute_label": "Age",
            "attribute_placeholder": "Enter your age",
            "attribute_type": "text",
            "attribute_name": "custage",
        },
        {
            "attribute_label": "Sex",
            "attribute_placeholder": "Enter your sex",
            "attribute_type": "select",
            "attribute_name": "custsex",
            "attribute_options": ["Male", "Female", "Other"]
        }
    ],
    "4": [{
            "attribute_label": "Age",
            "attribute_placeholder": "Enter your age",
            "attribute_type": "text",
            "attribute_name": "custage",
        },
        {
            "attribute_label": "Sex",
            "attribute_placeholder": "Enter your sex",
            "attribute_type": "select",
            "attribute_name": "custsex",
            "attribute_options": ["Male", "Female", "Other"]
        }
    ],
    "5": [{
            "attribute_label": "Age",
            "attribute_placeholder": "Enter your age",
            "attribute_type": "text",
            "attribute_name": "custage",
        },
        {
            "attribute_label": "Sex",
            "attribute_placeholder": "Enter your sex",
            "attribute_type": "select",
            "attribute_name": "custsex",
            "attribute_options": ["Male", "Female", "Other"]
        }
    ],
    "6": [{
            "attribute_label": "Age",
            "attribute_placeholder": "Enter your age",
            "attribute_type": "text",
            "attribute_name": "custage",
        },
        {
            "attribute_label": "Sex",
            "attribute_placeholder": "Enter your sex",
            "attribute_type": "select",
            "attribute_name": "custsex",
            "attribute_options": ["Male", "Female", "Other"]
        }
    ]
}
var account_type = "Distributor-Retailer";

function basicInfoPopulation1(data) {

    $("#tab1 #firstname").attr("value", data.firstname);

    $("#tab1 #lastname").attr("value", data.lastname);

    $("#tab1 #email").attr("value", data.email);

    $("#tab1 #phone").attr("value", data.telephoneNumber);

    $("#tab1 #businessname").attr("value", data.extension_business_name);

    $("#tab1 #mailaddress").attr("value", data.extension_mailing_address);

    $("#tab1 #city").attr("value", data.extension_mailing_city);

    $("#tab1 #state").val(data.extension_mailing_state);

    $("#tab1 #zipcode").attr("value", data.extension_mailing_postalCode);

    if (data.extension_email_communication_consent == true) {

        $('#tab1 #email-chk').prop("checked", true);
    }

    $("#tab1 #mobile").attr("value", data.telephoneNumber);

    $("#tab1 #lang").attr("value", data.preferredLanguage);


}

function accountTypePopulation(data) {

    //console.log(data.root.ContactData["Account_Types"]);
    var accountType = data['talendjson']["Profile_Data"]["Account_Types"];
    accountType.forEach(function (acctType, index) {
        var option = $("<option>");
        option[0].innerText = acctType["account_type"];
        $(".profile-type-select optgroup").append(option[0]);
    });

}

function tabRemoval() {
    $("ul [rel=tab1]").parent().children().not(':first-child').remove();
    $("ul [rel=tab1]").click();
    $(".tab-1").parent().children().not(':first-child').remove();
}

$(".profile-type-select").change(function () {
    var select_acc = document.getElementsByClassName("profile-type-select")[0];
    localStorage.setItem("userselectedaccount", select_acc.value.trim());
    //account_type = select_acc.options[select_acc.selectedIndex].text;
    createSegment(select_acc.options[select_acc.selectedIndex].text);
    $(".news-event-selection select").change();
    tabRemoval();
    tabCreation(JSON.parse(localStorage.getItem('userloggedindata')));
});

function refreshEventsListener() {

    $("ul.tabs li").off("click");
    /* if in tab mode */
    $("ul.tabs li").click(function () {

        $(".tab_content").hide();
        var activeTab = $(this).attr("rel");
        $("#" + activeTab).fadeIn();

        $("ul.tabs li").removeClass("active");
        $(this).addClass("active");

        $(".tab_drawer_heading").removeClass("d_active");
        $(".tab_drawer_heading[rel^='" + activeTab + "']").addClass("d_active");

        $(".global-error-red").hide();
        $('.success-model').hide();

    });
    /* if in drawer mode */
    $(".tab_drawer_heading").off("click");
    $(".tab_drawer_heading").click(function () {

        $(".tab_content").hide();
        var d_activeTab = $(this).attr("rel");
        $("#" + d_activeTab).fadeIn();

        $(".tab_drawer_heading").removeClass("d_active");
        $(this).addClass("d_active");

        $("ul.tabs li").removeClass("active");
        $("ul.tabs li[rel^='" + d_activeTab + "']").addClass("active");
    });
}

function tabCreation(cdata) {
    var accountTypes = cdata['talendjson']["Profile_Data"]["Account_Types"];
    var acc_type_sel = $('.custom-select.retailerdrop option:selected').attr('data-acctype');
    var accountType = accountTypes.filter(e => {
        return e["account_type"] == acc_type_sel;
    })[0];
    // accountType["Segment"].forEach(function (segment, index) {
        accSegmentId = localStorage.getItem('businesssegmentid');
        accSegmentName = localStorage.getItem('selectedSegmentName');
        var tab = $("<li>");
        tab[0].innerText = accSegmentName;
        $(tab).attr("rel", "" + accSegmentId);
        $(tab).addClass("dynamicTabs-js");

        $(".tabs").append(tab);
        var outterTab = $("<div>");
        $(outterTab).addClass("tab-" + accSegmentId);
        outterTab[0].innerHTML += '<h3 class="tab_drawer_heading" rel="tab' + accSegmentId + '">' + accSegmentName + '</h3>' +
            '<div id="tab' + accSegmentId + '" class="tab_content" style="display: block;">' +
            '<h2>' + accSegmentName + '</h2>' + '<hr>' +
            '<form class="disp-inline-blk" action="" novalidate>' +
            '<div class="container"></div></form></div></div>';
        $(".tab_container").append(outterTab);
        // var request = {
        //   "type": "get_form_data"
        // }
        // postAjaxRequest("POST", "/content/basfeupf/us/formdata.json", request, inputFieldCreation);
        //inputFieldCreation(accSegmentId, accSegmentName, inputFieldData);
        refreshEventsListener();
    // });
    //  $('.tab-2,.tab-3').hide();
    $(".tab_content").hide();
    $(".tab_content:first").show();
    $(".dynamicTabs-js").on('click', function (e) {
        tools.account_type = $('.custom-select.retailerdrop select :selected')[0].getAttribute('data-acctype');
        tools.segment_id = e.currentTarget.getAttribute("rel");
        /********get data from localstorage********* */
        try {
            var userdatafrmstorage = JSON.parse(localStorage.getItem("userloggedindata"));
            tools.EUPF_ID = userdatafrmstorage["userinfo"]["sub"];
            tools.Contact_Id = userdatafrmstorage["talendjson"]["Profile_Data"]["Contact_Id"];
            tools.Account_BASF_ID = userdatafrmstorage["talendjson"]["Profile_Data"]["account_id"];
        } catch (err) {
            //console.error(err);
        }
        /** */
        localStorage.setItem("selectedSegment", e.currentTarget.getAttribute("rel"));
        tools["id_token"] = JSON.parse(localStorage.getItem("userloggedindata")).login.id_token;
        postAjaxRequest("POST", "/content/basfeupf/us/formdata.json", tools, populateformElement);
    });
    // $(".dynamicTabs-js").on('click', function (e) {
    //     tools.account_type = localStorage.getItem("userselectedaccount");
    //     tools.segment_id = e.currentTarget.getAttribute("rel");
    //     /********get data from localstorage********* */
    //     try {
    //         var userdatafrmstorage = JSON.parse(localStorage.getItem("userloggedindata"));
    //         tools.EUPF_ID = userdatafrmstorage["userinfo"]["sub"];
    //         tools.Contact_Id = userdatafrmstorage["talendjson"]["Profile_Data"]["Contact_Id"];
    //         tools.Account_BASF_ID = userdatafrmstorage["talendjson"]["Profile_Data"]["Account_BASF_ID"];
    //     } catch (err) {
    //         //console.error(err);
    //     }
    //     /** */
    //     localStorage.setItem("selectedSegment", e.currentTarget.getAttribute("rel"));
    //     tools["id_token"] = JSON.parse(localStorage.getItem("userloggedindata")).login.id_token;
    //     postAjaxRequest("POST", "/content/basfeupf/us/formdata.json", tools, populateformElement);
    // });
}

var tools = {
    "type": "get_form_data",
    "segment_id": 30,
    "locale": "en",
    "account_type": localStorage.getItem("userselectedaccount"),
    "Request_Type": "Fetch",
    "Request_Attribute": "Segment",
    "EUPF_ID": "",
    "Contact_Id": "",
    "Account_BASF_ID": ""
}

// var boxUi ={
//     "select":""
// }

function populateformElement(data) {
    $(".tab_content").hide();
    var segment_id = tools.segment_id;
    var elements = JSON.parse(data).data
    var segmentId = "#tab" + segment_id + ".tab_content";
    var segmentContainer = "#tab" + segment_id + " form";
    var buttonHtml = `<div class="disp-inline-blk float-left w-100 text-center btn-block">
    <button type="" class="segmentsavebtn text-center">Save</button>
</div>`;

    var htmlData = "",
        optionHtml = "",
        multiSelectOption = "";
    elements.forEach(function (eachData) {
        if (eachData.attrib_type === 'select') {
            var value = eachData['default_value'].split('||');

            if (eachData.hasOwnProperty('attrib_value')) {
                value.forEach(function (key, ind) {
                    if (eachData['attrib_value'] == key.split('|')[1]) {
                        optionHtml += `<option value="${key.split('|')[1]}">${key.split('|')[0]}</option>`
                    } else {
                        optionHtml += `<option value="${key.split('|')[1]}" selected>${key.split('|')[0]}</option>`
                    }

                });
            } else {
                value.forEach(function (key, ind) {
                    optionHtml += `<option value="${key.split('|')[1]}">${key.split('|')[0]}</option>`
                });
            }
            htmlData += ` <div class="col col-lg-6 col-xs-12 mtb-1">
            <label for="${eachData.attrib_name}">${eachData.attrib_name}</label>
            <select class="talandAppForm" data-mapid="${eachData.attrib_map_id}" data-type="${eachData.crm_attrib_type}" name="${eachData.attrib_name}" id="${eachData.attrib_name}" required="" ${eachData.editable == 'No' ? 'disabled' : ''}>
               ${optionHtml}
            </select>
            <span class="aerow-down"></span>
         </div>`
        } else if (eachData.attrib_type === 'checkbox') {
            htmlData += `<div class="col col-lg-6 col-xs-12 mtb-1">
                            <input class="talandAppForm" type="checkbox" id="${eachData.attrib_name}" name="${eachData.attrib_name}" data-mapid="${eachData.attrib_map_id}" data-type="${eachData.crm_attrib_type}">
                            <label for="${eachData.attrib_name}"> ${eachData.attrib_name}</label>

                    </div>`;

        } else if (eachData.attrib_type === 'text') {
            htmlData += `<div class="col col-lg-6 col-xs-12 mtb-1">
                        <label for="${eachData.attrib_name}">${eachData.attrib_name}</label>
                        <input class="talandAppForm" type="${eachData.attrib_type}" placeholder="" data-mapid="${eachData.attrib_map_id}" data-type="${eachData.crm_attrib_type}" name="${eachData.attrib_name}" id="${eachData.attrib_name}" required="" value="${eachData.attrib_value}" aria-invalid="false" ${eachData.editable == 'No' ? 'readonly' : ''}>
                    </div>`;
        } else if (eachData.attrib_type === 'multiselect') {
            var values = eachData['default_value'].split('||');
            var checkvalue = eachData['attrib_value'].split(',');
            values.forEach(function (key, ind) {
                var checkecdValue = '';
                if (checkvalue != '') {
                    checkvalue.forEach(function (checkedKey) {
                        if (key.toLocaleLowerCase().startsWith(checkedKey.toLocaleLowerCase())) {
                            checkecdValue = 'checked';
                        }
                    });
                }
                multiSelectOption += `<li class="checkbox">
                <input type="checkbox" id="${key.split('|')[1]}" name="${key.split('|')[1]}" value="${key.split('|')[1]}" class="multi_checkbox" ${checkecdValue} />
                <label for="${key.split('|')[0]}">${key.split('|')[0]}</label>
             </li>`;
                // <option value="${key.split('|')[1]}">${key.split('|')[0]}</option>`
            })
            htmlData += `<div class="col col-lg-6 col-xs-12 mtb-1">
            <label for="${eachData.attrib_name}">${eachData.attrib_name}</label>
            <dl class="dropdown course-type">
               <dt>
                  <a href="javascript:void(0)">
                  <span data-mapid="${eachData.attrib_map_id}" data-type="${eachData.crm_attrib_type}" name="${eachData.attrib_name}" id="${eachData.attrib_name}" class="multi_select_placeholder talandAppForm" value="${eachData.attrib_value}">${typeof eachData.attrib_value != undefined ? eachData.attrib_value : 'Select All That Apply'}</span><span class="arrow-intrest ion-chevron-down"></span>
                  </a>
               </dt>
               <dd>
                  <div class="mutliSelect">
                     <ul class="multiple_select">
                       ${multiSelectOption}
                     </ul>
                  </div>
               </dd>
            </dl>
         </div>`;
        }
    });

    $(segmentId).css("display", "block");
    $(segmentContainer).find(".container").html(htmlData);
    $(segmentContainer).find(".container").append(buttonHtml);
    showmultiselectoption();

    $('.multi_checkbox').on('click', function () {
        multicheckbox(event);
    })

    $('.segmentsavebtn').on("click", function (event) {

        event.preventDefault();

        var data = JSON.parse(localStorage.getItem('userloggedindata'));
        var ContactId, Account_BASF_ID;
        try {
            var userdatafrmstorage = JSON.parse(localStorage.getItem("userloggedindata"));
            // ContactId = userdatafrmstorage["talendjson"]["Profile_Data"]["Contact_Id"];
            // Account_BASF_ID = userdatafrmstorage["talendjson"]["Profile_Data"]["Account_BASF_ID"];
        } catch (err) {
            // console.error(err);
        }
        //data['talend']['ContactId'], data['talend']['Account_BASF_ID'], data['talend']['Account_Type'], data['talend']['Business_Segment']
        var obj = generateRequest(data['userinfo']['sub'], "Segment", "Update", localStorage.getItem('userselectedaccount'), $('.dynamicTabs-js.active').attr('rel'));
        obj["id_token"] = JSON.parse(localStorage.getItem("userloggedindata")).login.id_token;
        postAjaxRequest("POST", "/content/basfeupf/us/talendsave.json", obj, showPopUp);

    })

}

function inputFieldCreation(response) {
    //var segmentId = inputFieldData[accSegmentId];
    var segmentId = JSON.parse(response.response).segmentId == undefined ? '2' : JSON.parse(response.response).segmentId;
    var fieldData = JSON.parse(response.response).data;
    fieldData.forEach(function (attribute, index) {
        var divTab = $("<div>");
        if (attribute["attrib_type"] == "text") {
            $(divTab).addClass("col col-lg-6 col-xs-12 mtb-1");
            divTab[0].innerHTML = '<label for="' + attribute[" attrib_name"] + '">' + attribute["attrib_label"] + '*</label>' +
                '<input type="' + attribute[" attrib_type"] + '" placeholder="' + attribute["attribute_placeholder"] + '"' +
                'name="' + attribute["attrib_name"] + '"' +
                'id="' + attribute["attrib_name"] + '" required="" value="" aria-invalid="false">';
        } else {
            $(divTab).addClass("col col-lg-3 col-xs-6 col-xxs-12 mtb-1");
            divTab[0].innerHTML = '<label class="disp-block" for="' + attribute[" attrib_name"] + '">' + attribute["attrib_label"] + '</label>' +
                '<select name="' + attribute["attrib_name"] + '" id="' + attribute["attrib_name"] + '" required="" value="CA"></select>'
            attribute["attrib_options"].forEach(function (sex, index) {
                $(divTab[0]).find("#" + attribute["attrib_name"])[0].innerHTML += '<option>' + sex + '</option>';
            });
        }
        $("#tab" + segmentId + " .container").append(divTab);
    });
    $("#tab" + segmentId + " .container").append(`<div class="disp-inline-blk float-left w-100 text-center btn-block">
    <button type="" class="registerbtn text-center">Save</button>
</div>`);
}

function getInitialData(accessCode, state, id_token) {
    var requestObj = {};
    requestObj.accessCode = accessCode;
    // sendAjaxRequestGet('GET', '/content/basfeupf/us/generatevalidatetoken.json?code=' + accessCode, requestObj);
    getAjaxRequest('GET', '/content/basfeupf/us/generatevalidatetoken.json?code=' + accessCode + "&state=" + state + "&id_token=" + id_token + "&language="+ getLanguage() + "&country=" + getCountry(), requestObj, saveUserLogInData);

}

function saveUserLogInData(data) {
    if (JSON.parse(data).hasOwnProperty('redirect') && window.location.href.indexOf('internal.html') == -1) {
        if (JSON.parse(data).redirect == true) {
            window.location.href = "/content/basfeupf/us/en/internal.html";
            return false;
        }
        // window.location.href = "/content/basfeupf/us/en/error.html";

    }


    if ((JSON.parse(data).status == 'fail' || JSON.parse(data).status == "errormsg") && !window.location.href.includes('/error')) {
        window.location.href = "/content/basfeupf/us/en/error.html";
    }

    if (JSON.parse(data).status == 'abort') {
        // window.location.href = "/content/basfeupf/us/en/success.html";

    }

    localStorage.setItem("userloggedindata", data);
    
    var parsedata = JSON.parse(localStorage.getItem("userloggedindata"));
    try {
        if (sessionStorage.hasOwnProperty('updatepassword')) {
            if (sessionStorage.getItem('updatepassword') == 'true') {
                sessionStorage.removeItem('updatepassword');
                window.location.href = parsedata.userinfo.appUri;
            }
        }
    } catch (error) {}
    // localStorage.setItem("user_information", parsedata['talendjson']);
    if (parsedata['origin'] == 'different') {
        selectedDropDwnValue(data);
        showAppForm(data)
       
        
    } else {
       // if (window.location.href.indexOf('/app-center') > -1 || window.location.href.indexOf('/my-profile') > -1) {
            //  getInitialData(accessCode, state, id_token);
            if (JSON.parse(data).hasOwnProperty('redirect')) {
                if (JSON.parse(data).redirect == true) {
                    window.location.href = "/content/basfeupf/us/en/internal.html";
                    return false;
                }
                // window.location.href = "/content/basfeupf/us/en/error.html";

            }
            selectedDropDwnValue(data);

       // }

    }
    dcLogin(localStorage.getItem("userloggedindata"));
    //  getAjaxRequest("POST", "/content/basfeupf/us/talend.json", null, selectedDropDwnValue);
}



function getAjaxRequest(method, endpoint, reqObj, callback) {
    $(".basicpage").show();
    toggleLoader(true);
    obj = JSON.stringify(reqObj);
    var xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function () {
        if (this.status == 200 & this.readyState == 4) {
            callback(this.responseText);
            toggleLoader(false);
            toggleLoader(false);
        }
    };
    xhr.open(method, endpoint, true);
    xhr.setRequestHeader('Accept', 'application/json');
    xhr.send();
}


function postAjaxRequest(method, endpoint, obj, callback, paramObj={}) {
    if(endpoint != "/content/basfeupf/us/accountoverview.get_repo_details.json" ||  $('.dc-Container').find('.get-support').length != 0){
		toggleLoader(true);
    }
    obj = JSON.stringify(obj);
    var xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function () {
      if ((this.status == 200) & (this.readyState == 4)) {
        toggleLoader(false);
        try {
          callback(this.responseText, paramObj);
        } catch (err) {
            console.log(`caught error at ${endpoint} endpoint`, err);
        }
      } 
    };

    xhr.open(method, endpoint, true);
    xhr.setRequestHeader("Accept", "application/json");
    xhr.send(obj);
}

function setAccountType(val) {
    $('.selectedAccount').val(val);
    // createSegment(val);
    // $(".news-event-selection select").change();
    // tabCreation(JSON.parse(localStorage.getItem('user_information')));

}

function getUrlParameter(seachParamName) {
    var queryParamsKeyValues = getAllUrlParameters()
    for (var i = 0; i < queryParamsKeyValues.length; i++) {
        var parameterNameAndValue = queryParamsKeyValues[i].split('=');
        if (parameterNameAndValue[0] === seachParamName) {
            return parameterNameAndValue[1] === undefined ? true :
                decodeURIComponent(parameterNameAndValue[1]);
        }
    }
    return "";
}

function getAllUrlParameters() {
    var queryParams = window.location.search.substring(1);

    if (queryParams.length == 0 && window.location.href.split('#').length > 1) {
        queryParams = window.location.href.split('#')[1];
    }
    return queryParams.length == 0 ? [] : queryParams.split('&');
}

function selectedDropDwnValue(dropdowndata) {

    try {
        if (JSON.parse(dropdowndata).hasOwnProperty('redirect')) {
            if (JSON.parse(data).redirect == true) {
                window.location.href = "/content/basfeupf/us/en/internal.html";
                return false;
            }
            // window.location.href = "/content/basfeupf/us/en/error.html";

        }

        if (localStorage.getItem("userloggedindata") === null) {
            //  localStorage.setItem("user_information", JSON.stringify(dropdowndata.responseText));
            localStorage.setItem("userloggedindata", dropdowndata);
        }
        var data = JSON.parse(localStorage.getItem("userloggedindata")); // store data in local storage
        // if (data['talendjson']["Profile_Data"]['Status'].toUpperCase() == "LINKED") {
        //     try {
        //         populateName();
        //     } catch (err) {}
        //     if ($("#api").length == 0) {
        //         toggleLoader(false);
        //         // populateName();
        //         try {
        //             if (data.hasOwnProperty('mismatchlogin')) {
        //                 if (data['mismatchlogin'] === false) {
        //                     var ProVM = data['mismatchloginsegment'];
        //                     var seg = data['talendjson']["Profile_Data"]["Account_Types"][0]["Segment"][0]["bus_segment_name"]
        //                     $('.popuptext').text('You are not a member of ' + ProVM + '.' + ' You’re viewing content for ' + seg + '.');
        //                     $('.pending').show();

        //                 }
        //             }
        //         } catch (error) {
        //             // console.log(error);
        //         }

        //         var accessCode = getUrlParameter('code');
        //         // var accounttypedata = data['talendjson']["Profile_Data"]['Account_Types'];
        //         var accounttypedata = data['talendjson']["Profile_Data"]['Account_Types'];
        //         var select = document.getElementById('changeusertype');
        //         var select1 = document.getElementById('changeusertypeheader');
        //         if (accessCode != null && accessCode != '') {
        //             if (accounttypedata.length > 1) {
        //                 /********************************************/
        //                 var dataaccouttype = JSON.parse(localStorage.getItem('userloggedindata'));
        //                 if (data.hasOwnProperty('selected_account_type') && data['selected_account_type'] != "") {
        //                     autoclosemodal(data['selected_account_type']);
        //                 }
        //                 if (localStorage.getItem('userselectedaccount') === null) {
        //                     openmodal();
        //                 } else {
        //                     if (data.hasOwnProperty('selected_account_type') && data['selected_account_type'] != "") {
        //                         createSegment(data['selected_account_type']);
        //                         localStorage.setItem("userselectedaccount", data['selected_account_type']);

        //                     } else {
        //                         createSegment(accounttypedata[0]['account_type']);
        //                         localStorage.setItem("userselectedaccount", accounttypedata[0]['account_type']);

        //                     }
        //                 }
        //             } else {
        //                 createSegment(accounttypedata[0]['account_type']);
        //                 localStorage.setItem("userselectedaccount", accounttypedata[0]['account_type']);
        //             }
        //         }

        //         for (var i = 0; i < accounttypedata.length; i++) {
        //             var opt = document.createElement('option');
        //             opt.value = accounttypedata[i]['account_type'];
        //             opt.innerHTML = accounttypedata[i]['account_type'];

        //             select.appendChild(opt); // should not be multiple
        //             //  to ul li instead select option using nice select jquery
        //             $('#changeusertype').niceSelect();
        //             $('#changeusertype').niceSelect('update');

        //             var opt1 = document.createElement('option');
        //             opt1.value = accounttypedata[i]['account_type'];
        //             opt1.innerHTML = accounttypedata[i]['account_type'];
        //             select1.appendChild(opt1);
        //             //  to ul li instead select option using nice select jquery
        //             $('#changeusertypeheader').niceSelect();
        //             $('#changeusertypeheader').niceSelect('update');
        //         }
        //         try {
        //             if (localStorage.getItem('userselectedaccount') != null) {
        //                 $('#changeusertypeheader').val(localStorage.getItem('userselectedaccount'));
        //                 $('#changeusertypeheader').niceSelect();
        //                 $('#changeusertypeheader').niceSelect('update');
        //                 // $('.segment-div').val(localStorage.getItem('selectedSegment'));
        //                 // $('.segment-div').trigger('change');
        //             } else {
        //                 $('.profile-type-select').trigger('change');
        //             }

        //         } catch (err) {
        //             // console.log(err);
        //         }
        //     } else {
        //         var accounttypedata = data['talendjson']["Profile_Data"]['Account_Types'];
        //         var accounttypedata = data['talendjson']["Profile_Data"]['Account_Types'];
        //         var select = document.getElementById('changeusertypeheader');
        //         for (var i = 0; i < accounttypedata.length; i++) {
        //             try {
        //                 var opt = document.createElement('option');
        //                 opt.value = accounttypedata[i]['account_type'];
        //                 opt.innerHTML = accounttypedata[i]['account_type'];
        //                 select.appendChild(opt);
        //                 //  to ul li instead select option using nice select jquery
        //                 $('#changeusertypeheader').niceSelect('update');
        //                 $('#changeusertypeheader').niceSelect();
        //             } catch (err) {
        //                 //  console.error(err);
        //             }
        //         }
        //         try {
        //             $('#changeusertypeheader').val(localStorage.getItem('userselectedaccount'));
        //             $('#changeusertypeheader').niceSelect();
        //             $('#changeusertypeheader').niceSelect('update');
        //             //  $('.segment-div').val(localStorage.getItem('selectedSegment'));
        //             // $('.segment-div').trigger('change');

        //         } catch (err) {
        //             // console.log(err);
        //         }

        //         // $("#changeusertypeheader").val(localStorage.getItem("userselectedaccount"));
        //         $('.selectedAccount').val(localStorage.getItem("userselectedaccount"));
        //         // var data = localStorage.getItem(user_information);
        //         var jdata = JSON.parse(localStorage.getItem("userloggedindata"));
        //         basicInfoPopulation(jdata.userinfo);
        //         // basicInfoPopulation(cdata);
        //         var select_acc = document.getElementsByClassName("profile-type-select")[0];
        //         account_type = select_acc.options[select_acc.selectedIndex].text;
        //         tabCreation(data);

        //     }
        //     newsCarouselInit();
        //     populateName();
        // }
        if (data['talendjson']["Profile_Data"]['Status'].toUpperCase() == "LINKED") {
            var data = JSON.parse(localStorage.getItem('userloggedindata'));
            
            createSegment(0);
            if (data.segmentdetails.length > 0) {

                createAccountType(data.talendjson.Profile_Data.Account_Types);
                $('.retailerdrop select').on('change', (e) => {
                    createSegment(e.currentTarget.selectedIndex);
                })
                $(".news-event-selection select").change();
                $('.aerow-down-green').hide();

            }
            populateName();
            if (!$("#api").length == 0) {
                var accounttypedata = data['talendjson']["Profile_Data"]['Account_Types'];
                var accounttypedata = data['talendjson']["Profile_Data"]['Account_Types'];
                var select = document.getElementById('changeusertypeheader');
                //openmodal();
                for (var i = 0; i < accounttypedata.length; i++) {
                    try {
                        var opt = document.createElement('option');
                        opt.value = accounttypedata[i]['account_type'];
                        opt.innerHTML = accounttypedata[i]['account_type'];
                        select.appendChild(opt);
                        //  to ul li instead select option using nice select jquery
                        $('#changeusertypeheader').niceSelect('update');
                        $('#changeusertypeheader').niceSelect();
                    } catch (err) {
                        //  console.error(err);
                    }
                }
                try {
                    $('#changeusertypeheader').val(localStorage.getItem('userselectedaccount'));
                    $('#changeusertypeheader').niceSelect();
                    $('#changeusertypeheader').niceSelect('update');
                    //  $('.segment-div').val(localStorage.getItem('selectedSegment'));
                    // $('.segment-div').trigger('change');

                } catch (err) {
                    // console.log(err);
                }

                // $("#changeusertypeheader").val(localStorage.getItem("userselectedaccount"));
                $('.selectedAccount').val(localStorage.getItem("userselectedaccount"));
                // var data = localStorage.getItem(user_information);
                var jdata = JSON.parse(localStorage.getItem("userloggedindata"));
                basicInfoPopulation(jdata.userinfo);
                // basicInfoPopulation(cdata);
                // var select_acc = document.getElementsByClassName("profile-type-select")[0];
                // account_type = select_acc.options[select_acc.selectedIndex].text;
                tabCreation(jdata);
            }

            $('#profile-type').hide();
            $('.menu_list').show();
            newsCarouselInit();
            function populateaccountData(){ 
                var userinfo = JSON.parse(localStorage.getItem('userloggedindata'));
                var profileData = userinfo.talendjson.Profile_Data;
				if (profileData.hasOwnProperty('Lead_ID') && profileData.Lead_ID != '') {
					mdmAccMapping.Lead_ID = userinfo['talendjson']['Profile_Data']['Lead_ID'];
				}
                mdmAccMapping.Email_Address = userinfo['userinfo']['email'];
                mdmAccMapping.EUPF_ID = userinfo['userinfo']['sub'];
                mdmAccMapping.Contact_Id = userinfo['talendjson']['Profile_Data']['Contact_Id'];

                postAjaxRequest("POST","/content/basfeupf/us/formdata.json",mdmAccMapping,populateAccouts);
			
		}
            if (data.talendjson.Profile_Data.Accounts.length > 1) {
                if (localStorage.getItem('accountID') === null) {                   
                   populateaccountData();
                   
                  if (data.origin == 'different') {
                        $("#enrolment").css("z-index","-1");            
                  }
                }
            } else {
                localStorage.setItem('accountID', data.talendjson.Profile_Data.Accounts[0].account_id);
                if (data.origin == 'different') {  
                    $("#enrolment").css("z-index","9");                 
              }               
            }
        }
        if (data['talendjson']["Profile_Data"]['Status'] == "Not Linked") {
            var data = JSON.parse(localStorage.getItem('userloggedindata'));
            var seg_name = "";
            var seg_id = "";

            createSegment(0);
            if (data.segmentdetails.length > 0) {
                // data.segmentdetails.forEach(function (obj) {
                //     seg_name = obj['Segment'][0]['bus_segment_name'];
                //     seg_id = obj['Segment'][0]['bus_segment_id'];
                //     // $('.segment-div').append(`<option value="${seg_id != null || seg_id != '' ? seg_id : '30'}">${seg_name != null || seg_name != '' ? seg_name : "PCS"}</option>`);
                //     // $('.segment-div').append(`<input type="text" value="${obj['segment_id']}" placeholder="${obj['segment_name']} id="id_segment"/>"`);
                //     // $('#id_segment').val("${obj['segment_name']}");
                //     // $("#id_segment").change();
                //     createSegment(obj.account_type);
                // })
                createAccountType(data.talendjson.Profile_Data.Account_Types);
                $('.retailerdrop select').on('change', (e) => {
                    createSegment(e.currentTarget.selectedIndex);
                })
                $(".news-event-selection select").change();
                // $('.segment-div').hide();
                // $('.eupf-landingpage-heading H1').append(seg_name);
                $('.aerow-down-green').hide();

            }
            populateName();
            if (!$("#api").length == 0) {
                var accounttypedata = data['talendjson']["Profile_Data"]['Account_Types'];
                var accounttypedata = data['talendjson']["Profile_Data"]['Account_Types'];
                var select = document.getElementById('changeusertypeheader');
                for (var i = 0; i < accounttypedata.length; i++) {
                    try {
                        var opt = document.createElement('option');
                        opt.value = accounttypedata[i]['account_type'];
                        opt.innerHTML = accounttypedata[i]['account_type'];
                        select.appendChild(opt);
                        //  to ul li instead select option using nice select jquery
                        $('#changeusertypeheader').niceSelect('update');
                        $('#changeusertypeheader').niceSelect();
                    } catch (err) {
                        //  console.error(err);
                    }
                }
                try {
                    $('#changeusertypeheader').val(localStorage.getItem('userselectedaccount'));
                    $('#changeusertypeheader').niceSelect();
                    $('#changeusertypeheader').niceSelect('update');
                    //  $('.segment-div').val(localStorage.getItem('selectedSegment'));
                    // $('.segment-div').trigger('change');

                } catch (err) {
                    // console.log(err);
                }

                // $("#changeusertypeheader").val(localStorage.getItem("userselectedaccount"));
                $('.selectedAccount').val(localStorage.getItem("userselectedaccount"));
                // var data = localStorage.getItem(user_information);
                var jdata = JSON.parse(localStorage.getItem("userloggedindata"));
                basicInfoPopulation(jdata.userinfo);
                // basicInfoPopulation(cdata);
                // var select_acc = document.getElementsByClassName("profile-type-select")[0];
                // account_type = select_acc.options[select_acc.selectedIndex].text;
            }

            $('#profile-type').hide();
            $('.menu_list').show();
            $('.popuptext').text('Your account is under review as a new account. Please enjoy secure guest access during this time.');
            $('.pending').show();
            newsCarouselInit();
        }

        if (data['talendjson']["Profile_Data"]['Status'] == "Acknowledged") {
            var data = JSON.parse(localStorage.getItem('userloggedindata'));
            var seg_name = "";
            var seg_id = "";
            $('#profile-type').hide();
            $('.menu_list').show();
            $('.popuptext').text('Your account is under review as a new account. Please enjoy secure guest access during this time.');
            createAccountType();
            populateName();
            if ($("#api").length == 0) {
                if (data.segmentdetails.hasOwnProperty('data')) {
                    data.segmentdetails.data.forEach(function (obj) {
                        seg_name = obj['segment_name'];
                        seg_id = obj['segment_id']
                        // $('.segment-div').append(`<option value="${obj['segment_id'] != null || obj['segment_id'] != '' ? obj['segment_id'] : '30'}">${obj['segment_name'] != null || obj['segment_name'] != '' ? obj['segment_name'] : "PCS"}</option>`);
                        // $('.segment-div').append(`<input type="text" value="${obj['segment_id']}" placeholder="${obj['segment_name']} id="id_segment"/>"`);
                        // $('#id_segment').val("${obj['segment_name']}");
                        // $("#id_segment").change();
                        createSegment()
                    })
                    $(".news-event-selection select").change();
                    // $('.segment-div').hide();
                    // $('.eupf-landingpage-heading H1').append(seg_name);
                    $('.aerow-down-green').hide();
                }
                $('.pending').show();
                newsCarouselInit();
            } else {
                // var accounttypedata = data['talendjson']["Profile_Data"]['Account_Types'];
                // var accounttypedata = data['talendjson']["Profile_Data"]['Account_Types'];
                var select = document.getElementById('changeusertypeheader');
                // for (var i = 0; i < accounttypedata.length; i++) {
                //     try {
                //         var opt = document.createElement('option');
                //         opt.value = accounttypedata[i]['account_type'];
                //         opt.innerHTML = accounttypedata[i]['account_type'];
                //         select.appendChild(opt);
                //         //  to ul li instead select option using nice select jquery
                //         $('#changeusertypeheader').niceSelect('update');
                //         $('#changeusertypeheader').niceSelect();
                //     } catch (err) {
                //         //  console.error(err);
                //     }
                // }
                // try {
                //     $('#changeusertypeheader').val(localStorage.getItem('userselectedaccount'));
                //     $('#changeusertypeheader').niceSelect();
                //     $('#changeusertypeheader').niceSelect('update');
                //     //  $('.segment-div').val(localStorage.getItem('selectedSegment'));
                //     // $('.segment-div').trigger('change');

                // } catch (err) {
                //     // console.log(err);
                // }

                // $("#changeusertypeheader").val(localStorage.getItem("userselectedaccount"));
                $('.selectedAccount').val(localStorage.getItem("userselectedaccount"));
                // var data = localStorage.getItem(user_information);
                var jdata = JSON.parse(localStorage.getItem("userloggedindata"));
                basicInfoPopulation(jdata.userinfo);
                // basicInfoPopulation(cdata);
                // var select_acc = document.getElementsByClassName("profile-type-select")[0];
                // account_type = select_acc.options[select_acc.selectedIndex].text;
                // tabCreation(data);
            }

        }
        //callback(JSON.parse(this.responseText));
        toggleLoader(false);
    } catch (err) {
        // console.log(err);
        toggleLoader(false);
        // window.location.href = "/content/basfeupf/us/en/error.html";
    }
    toggleLoader(false);
}

function populateName() {
    $('#switchAccount').hide();
    if ("userloggedindata" in localStorage) {
        var userinfo = JSON.parse(localStorage.getItem('userloggedindata'));
        var profileData = userinfo.talendjson.Profile_Data;
        $('#username').text(userinfo.userinfo.firstname + " " + userinfo.userinfo.lastname + " ");
        $('#usernameDropdownName').text(userinfo.userinfo.firstname + " " + userinfo.userinfo.lastname + " ");
        $('.letter-print').text(userinfo.userinfo.firstname.charAt(0).toUpperCase() + userinfo.userinfo.lastname.charAt(0).toUpperCase());
        if (userinfo.talendstatus == "Linked") {
            if (userinfo.talendjson.Profile_Data.Accounts.length == 1) {
                if(localStorage.getItem('accountID')){
                    $('[data-accountid]').text('BASF ID '+localStorage.getItem('accountID'));
                }else{
                    $('[data-accountid]').text('BASF ID '+userinfo.talendjson.Profile_Data.Accounts[0]['account_id']);
                    }
            } else {
                $('[data-accountid]').hide();
            }

        } else {
            $('[data-accountid]').hide();
        }

        $('[data-accountName]').text($('.custom-select.retailerdrop select :selected')[0].getAttribute('data-segtype') + " - " + userinfo.userinfo.businessType);
        if(userinfo['talendstatus'] == 'Linked'){
            $('#switchAccount a').unbind();
            $('#switchAccount a').on('click',() =>{
                
                if (profileData.hasOwnProperty('Lead_ID') && profileData.Lead_ID != '') {
                    mdmAccMapping.Lead_ID = userinfo['talendjson']['Profile_Data']['Lead_ID'];
                }
                mdmAccMapping.Email_Address = userinfo['userinfo']['email'];
                mdmAccMapping.EUPF_ID = userinfo['userinfo']['sub'];
                mdmAccMapping.Contact_Id = userinfo['talendjson']['Profile_Data']['Contact_Id'];

                postAjaxRequest("POST","/content/basfeupf/us/formdata.json",mdmAccMapping,populateAccouts);
            })
        }
//show hide switch account link on profile dropdown

        var userinfo = JSON.parse(localStorage.getItem('userloggedindata'));
        if (profileData.hasOwnProperty('Lead_ID') && profileData.Lead_ID != '') {
            mdmAccMapping.Lead_ID = userinfo['talendjson']['Profile_Data']['Lead_ID'];
        }
        mdmAccMapping.Email_Address = userinfo['userinfo']['email'];
        mdmAccMapping.EUPF_ID = userinfo['userinfo']['sub'];
        mdmAccMapping.Contact_Id = userinfo['talendjson']['Profile_Data']['Contact_Id'];

        if (mdmAccMapping.Contact_Id != undefined) {

            postAjaxRequest("POST","/content/basfeupf/us/formdata.json",mdmAccMapping,switchAccountLink);
        }


            
        // if(!$('.segment-div :selected').length ==0){
        // }else{
        //     const acctype = userinfo.segmentdetails.data[0].segment_name;
        //     const segType = userinfo.userinfo.businessType;
        //     $('[data-accountName]').text(acctype + " - " + segType);
        // }
    }
}
function switchAccountLink(data) {
    data = JSON.parse(data);
    if (data.hasOwnProperty("responseMessage") && data["responseMessage"] == 'Success') {
        const accounts = data['Profile_Data']['Accounts'];
        if (accounts.length > 1) {
            $('#switchAccount').show();
       } else {
        $('#switchAccount').hide();	
       }

	}
}
function closemodal() {

    try {
        setAccountType($("#changeusertype").val());
        $('#changeusertypeheader').niceSelect();
        $('#changeusertypeheader').niceSelect('update');
        rememberme();

    } catch (err) {}
    var x = document.getElementById("myModal");
    x.style.display = "none";
    createSegment($('#changeusertype').val());
    localStorage.setItem("userselectedaccount", $('#changeusertype').val());
    $(".news-event-selection select").change();


}

function autoclosemodal(val) {
    try {
        setAccountType(val);
        $('#changeusertypeheader').niceSelect();
        $('#changeusertypeheader').niceSelect('update');

    } catch (err) {}
    createSegment(val);
    localStorage.setItem("userselectedaccount", val);
    $(".news-event-selection select").change();

}

function rememberme() {
    /***update selected account type in db***/
    if ($('#remember-chk').is(":checked")) {
        var update_account_type = {
            "type": "update_account_user_type",
            "account_type": $('#changeusertype').val(),
            "sub": JSON.parse(localStorage.getItem('userloggedindata'))['userinfo']['sub']
        }
        postAjaxRequest("POST", "/content/basfeupf/us/formdata.json", update_account_type, "");
    }
    /****************************************/
}

function remembermeprofile() {
    /***update selected account type in db***/
    var update_account_type = {
        "type": "update_account_user_type",
        "account_type": $('#changeusertypeheader').val(),
        "sub": JSON.parse(localStorage.getItem('userloggedindata'))['userinfo']['sub']
    }
    postAjaxRequest("POST", "/content/basfeupf/us/formdata.json", update_account_type, "");
    /****************************************/
}

function openmodal() {
    var x = document.getElementById("myModal");
    x.style.display = "block";
}
$('.close-model').on('click', function () {
    $('.pending').hide();
})

function updateUserData() {
    var name = $("#firstname").val() + " " + $("#lastname").val();
    var fname = $("#firstname").val();
    var lname = $("#lastname").val();
    var business = $('#businessname').val();
    var country = $("#country").val();
    var language = $("#lang").val();
    var contact = $("#mobile").val();
    var mailingaddr = $("#mailaddress").val();
    var customerType = $('#customerType').val();
    var city = $("#city").val();
    var state = $("#state").val();
    var zipcode = $("#zipcode").val();
    var emailchk = $("#email-chk").is(":checked");
    var textchk = $("#text-chk").is(":checked");
    var leagalReview = $("#leagalReview").is(":checked");
    var mobile = $("#mobile").val();
    var workmobileArray = [];
    var workmobile = $('#phone').val();
    if (workmobile != undefined && workmobile != null && workmobile != '') {
        workmobileArray.push(workmobile);
    }

    var sub = JSON.parse(localStorage.getItem('userloggedindata'));
    //data['talend']['ContactId'], data['talend']['Account_BASF_ID'], data['talend']['Account_Type'],data['talend']['Business_Segment']
    try {
        var userdatafrmstorage = JSON.parse(localStorage.getItem("userloggedindata"));
        Contact_Id = userdatafrmstorage["talendjson"]["Profile_Data"]["Contact_Id"];
        Account_BASF_ID = userdatafrmstorage["talendjson"]["Profile_Data"]["account_id"];
    } catch (err) {
        //  console.error(err);
    }
    var obj = generateProfileRequest(sub['userinfo']['sub'], "Profile", "Update", "", "", customerType);

    var profilejson = {};
    var azure_extension_no = $('#azure_extension_no').val();

    profilejson.sub = sub['userinfo']['sub'];
    profilejson.firstname = fname;
    profilejson.lastname = lname;
    profilejson.country = country;
    profilejson.preferredLanguage = language;
    profilejson.requested_business_segment = getBusinessSegment(userdatafrmstorage.userinfo.extension_bs, userdatafrmstorage.userinfo.extension_user_Registration_bs, customerType);
    profilejson.account_type = getAccountType(customerType);
    profilejson.extension_business_name = business;
    profilejson.city = city;
    profilejson.state = state;
    profilejson.postalCode = zipcode;
    profilejson.mobile = mobile;

    var ext_mailing_address = "extension_" + azure_extension_no + "_mailing_address";
    var ext_mailing_city = "extension_" + azure_extension_no + "_mailing_city";
    var ext_mailing_state = "extension_" + azure_extension_no + "_mailing_state";
    var ext_mailing_postalCode = "extension_" + azure_extension_no + "_mailing_postalCode";
    var ext_email_communication_consent = "extension_" + azure_extension_no + "_email_communication_consent";
    var ext_MobileConsent = "extension_" + azure_extension_no + "_MobileConsent";
    var ext_customer_type = "extension_" + azure_extension_no + "_business_type";
    var ext_business_name = "extension_" + azure_extension_no + "_business_name";

    var ext_extension_bs = "extension_" + azure_extension_no + "_user_Registration_bs";
    try {
        var extension_account_number = "extension_" + azure_extension_no + "_account_number";
        var extension_contact_id = "extension_" + azure_extension_no + "_contact_id";
    } catch (err) {
        //console.log(err)
    }


    var data = {
        "grant_type": "client_credentials",
        "client_id": "17cc5c5f-e0f5-4cd8-b318-801b770945df",
        "client_secret": "c_.83tsRoA.-CC6m33FldL5UBI9zT9GNwP",
        "scope": "https://graph.microsoft.com/.default",
        "userObject": {
            "givenName": fname,
            "surname": lname,
            "country": country,
            "preferredLanguage": language,
            "mobilePhone": mobile,
            // "extension_5414203b3cb64ca1b2ba6122a0e0ddee_contact_id": contact,
            [ext_mailing_address]: mailingaddr,
            [ext_mailing_city]: city,
            [ext_mailing_state]: state,
            [ext_mailing_postalCode]: zipcode,
            [ext_email_communication_consent]: emailchk,
            [ext_MobileConsent]: textchk,
            [ext_customer_type]: customerType,
            [ext_extension_bs]: getBusinessSegment(userdatafrmstorage.userinfo.extension_bs, userdatafrmstorage.userinfo.extension_user_Registration_bs, customerType)
        },
        "talendUserObject": obj,
        "sub": sub.userinfo.sub,
        "profile": profilejson
    };
    if (textchk == false) {
        delete data['userObject']['mobilePhone'];
    }

    data["id_token"] = JSON.parse(localStorage.getItem("userloggedindata")).login.id_token;
    postAjaxRequest("POST", "/content/basfeupf/user.json", data, postUserInfoUpdate);
}

// Personal info  submit
$('.personal-info-save').on('click', function (e) {
    var baseinfo;
    e.preventDefault();
    var validator = $('.personal-info-form').validate(); 
    if (validator.form()) {
        baseinfo = true;
        $('.personal-info-form').submit();
        updateUserData();

    }
});

// business info update
$('.business-info-save').on('click', function (e) {
    var baseinfo;
    e.preventDefault();
    var validator = $(".business-info-form").validate();
    if (validator.form()) {
       baseinfo = true;
      $(".business-info-form").submit();
       updateUserData();
       
    }
});



function postUserInfoUpdate(data) {
    $('.update-personal').hide();
    $('.backgroundpopup').hide();
    $('.eupf-loader').show();
    if (JSON.parse(data).talendresponse["responseCode"] === 200) {
        setTimeout(() => {
            window.location.reload(true);
        }, 5000);

    } else {
        $('.eupf-loader').hide();
        $('.form-error-text').text('We get Error in response.Somethings went wrong');
        $(".global-error-red").show();
    }
    $('html, body').animate({
        scrollTop: 0
    }, 'slow');
}

function showPopUp(data) {
    $('.update-personal').hide();
    $('.backgroundpopup').hide();
    if (JSON.parse(data).talendresponse["responseCode"] === 200) {
        $(".global-error-red").hide();
        $('.success-model').show();
        basicInfoPopulation();
    } else {
        basicInfoPopulation();
        $('.form-error-text').text('We get Error in response.Somethings went wrong');
        $(".global-error-red").show();
    }
    $('html, body').animate({
        scrollTop: 0
    }, 'slow');

}

/***************************Create Segment As Selected ****************************/
function createSegment(val) {
    $('.eupf-landingpage-heading span.news-event-selection select').niceSelect('destroy');
    $('.eupf-landingpage-heading span.news-event-selection select option').remove();
    //initialize custom dropdown
    $('.eupf-landingpage-heading span.news-event-selection select').niceSelect();
    //var userinfo = JSON.parse(localStorage.getItem('userinfo'))
    // $('.segment-div').empty();
    let data = JSON.parse(localStorage.getItem('userloggedindata'));
    if (data['talendstatus'] == 'Acknowledged') {
        var segmentType = data['segmentdetails']['data'];
        segmentType.forEach(function (obj) {
            if (obj) {
                $('.segment-div').append(createSegmentDripDown(obj));
            }
        })
    } else {
        var accountType = data['talendjson']["Profile_Data"]["Account_Types"][val];

        try {
            var segment = accountType["Segment"];
            $('.segment-div').append(createSegmentDripDown(segment));
        } catch (err) {
            // console.log("Error!!" + err)
        }
    }

    if (document.referrer.includes('profile')) {
        if ("selectedSegment" in localStorage) {
            $('.segment-div').val(localStorage.getItem('businesssegmentid')).change();
        }
        if ($(".segment-div").val() == null) {
            $(".segment-div").val($(".segment-div option:first").val());

        }
    } else {
        $('.segment-div').trigger('change');
    }
    $('.segment-div').niceSelect('update');
}

/*************Create Account Type***************/
function createAccountType(obj) {
    $('.retailerdrop select').niceSelect('destroy');
    $('.retailerdrop select option').remove();
    const userObj = JSON.parse(localStorage.getItem('userloggedindata'));
    if (obj == undefined || obj == null) {
        const opt = '<option data-segtype="' + userObj.segmentdetails.data[0].segment_name + '" data-accType="' + userObj.userinfo.businessType + '" >' + userObj.userinfo.businessType + '</option>';
        $('.retailerdrop select').append(opt);
    } else {
        obj.forEach(ele => {
            const opt = '<option data-segtype="' + userObj.segmentdetails[0].Segment[0].bus_segment_name + '" data-accType="' + ele.account_type + '" >' + ele.account_sub_type + '</option>';
            $('.retailerdrop select').append(opt);
        })
    }

    $('.retailerdrop select').niceSelect();
}

function createSegmentDripDown(segment) {
    var option = '';
    if (Array.isArray(segment)) {
        segment.forEach(function (obj) {
            option += `<option value="${obj['bus_segment_id']}">${obj['bus_segment_name']}</option>`;
        });
    } else {
        option += `<option value="${segment['segment_id']}">${segment['segment_name']}</option>`;
    }
    return option;
}

function logoutCall() {
    localStorage.setItem("logout", "true");
    window.location.href = $('.sign-out').data('redirect');
    //event.preventDefault();

}

function redirection() {
    var returnUrl = "";
    try {
        returnUrl = document.getElementById("segmentid-" + localStorage.getItem('businesssegmentid')).value;
    } catch (err) {}

    if (returnUrl == "") {
        returnUrl = document.getElementById("segmentid-default").value;
    }
    localStorage.clear();
    sessionStorage.clear();
    window.location.href = returnUrl;
}

$(function () {
    var checkbox = $("#text-chk");
    checkbox.change(function () {
        if (checkbox.is(':checked')) {
            $("#mobile").prop('required', true);
            $(".mobile-optional").addClass('error-element');

        } else {
            $("#mobile").prop('required', false);
            $(".mobile-optional").removeClass('error-element');
        }
    });
});

/************************User dropdown show hide***************************/
$('.profile').click(function() {
    $('.user-profile-dropdown').toggle();
});

$(document).click(function(e) {
    if (!$(e.target).parents().is('.profile')) {
        $(".user-profile-dropdown").hide();
    }
});

$(".user-profile-dropdown").click(function(e) {
    e.stopPropagation();
});

function Growlinkredirection(){
     var data = JSON.parse(localStorage.getItem('userloggedindata'));
        var pid = '';
        var accountid = '';
        var contactid = '';
        var bs = '';
        var link = "";
        if((data.talendstatus == "Acknowledged")||(data.talendstatus == "Linked" && localStorage.getItem('multiAccountUser') == 'Yes')) {
			var profileData = data.talendjson.Profile_Data;
			if (profileData.hasOwnProperty('Lead_Id') && profileData.Lead_Id != '') {
				pid = "&pid=" + data.talendjson.Profile_Data.Lead_Id;
			} 
			else if (profileData.hasOwnProperty('Lead_ID') && profileData.Lead_ID != '') {
				pid = "&pid=" + data.talendjson.Profile_Data.Lead_ID;
			}			
			if (profileData.hasOwnProperty('Contact_Id') && profileData.Contact_Id != '') {
				contactid = "&cid=" + data.talendjson.Profile_Data.Contact_Id;
			}
			if (profileData.hasOwnProperty('account_id') && profileData.account_id != '') {
				accountid = "&an=" + data.talendjson.Profile_Data.account_id;
			}
			let userinfo = data.userinfo;
		    if (userinfo.hasOwnProperty('extension_bs') && userinfo.extension_bs != '') {
				bs = "&bs=" + data.userinfo.extension_bs;
			}
		}
        data['appdata']['data'].forEach(function (e) {
            if (e.app_type == "saml") {
                link = e.app_link;
            }
            if (e.app_type == 'openid') {
                var nonce = e.nonce;
                var uilocale = "";
                try {
                    nonce = JSON.parse(localStorage.getItem('userloggedindata')).userinfo.nonce;
                    uilocale = "&ui_locales=" + JSON.parse(localStorage.getItem('userloggedindata')).userinfo.ui_locales;

                } catch (err) {

                }
                let useState = '';
                let appcontext = '';
                let appuri = '';
                var url = new URL(window.location.href);
				if (e.use_state == "No" && e.app_state == 'Yes' && url.searchParams.has('state')
					&& url.searchParams.get('state') == 'partner') {
					link = $('#sfcc_redirectURI').val();
				} else if (e.use_state == "No") {
                    let appState = window.location.href.split("?")[1].split("&");
                    appState.forEach(function (ele) {
                        try {
                            if (ele.split("=")[0] == "state" && ele.split("=")[1] != '') {
                                useState = "&state=" + ele.split("=")[1];
                            }
                        } catch (err) {}
                    })
                    try {
                        appcontext = JSON.parse(localStorage.getItem('userloggedindata')).userinfo.appContext;
                        if (appcontext != undefined && appcontext != null) {
                            appcontext = "&appContext=" + appcontext;
                        }

                    } catch (err) {
                        appcontext = '';
                    }
                    try {
                        appuri = JSON.parse(localStorage.getItem('userloggedindata')).userinfo.appUri;
                        if (appuri != undefined && appuri != null) {
                            appuri = "&appUri=" + appuri;
                        }
                    } catch (err) {
                        appuri = '';
                    }
                    link = e.azure_link + "?p=" + e.policy + "&client_id=" + e.client_id + "&nonce=" + nonce + "&redirect_uri=" + e.app_link + "&scope=" + e.scope + "&response_type=" + e.response_type + "&response_mode=" + e.response_mode + useState + pid + bs + contactid + accountid + "&theme=" + e.theme + uilocale + appcontext + appuri;
                } else {
                    if (e.state != '') {
                        useState = "&state=" + e.state;
                    }
                    try {
                        appcontext = "&appContext=" + JSON.parse(localStorage.getItem('userloggedindata')).userinfo.appContext;
                    } catch (err) {
                        appcontext = '';
                    }
                    try {
                        appuri = "&appUri=" + JSON.parse(localStorage.getItem('userloggedindata')).userinfo.appUri;
                    } catch (err) {
                        appuri = '';
                    }
                    link = e.azure_link + "?p=" + e.policy + "&client_id=" + e.client_id + "&nonce=" + nonce + "&redirect_uri=" + e.app_link + "&scope=" + e.scope + "&response_type=" + e.response_type + "&response_mode=" + e.response_mode + useState + pid + bs + contactid + accountid + "&theme=" + e.theme + uilocale + appcontext + appuri;
                }

            }
        });
        //show account popup before redirection
        var userinfo = JSON.parse(localStorage.getItem('userloggedindata'));
        var profileData = userinfo?.talendjson?.Profile_Data;
        if(profileData?.hasOwnProperty('Accounts') && userinfo?.talendjson?.Profile_Data?.Accounts?.length > 1){
            localStorage.setItem("link", link);
            return true;
        } else{
            if (link != "") {
                toggleLoader(true);
            }
            window.location.href = link; 
        }
}

/*****************************In case of different origin show App Form *********************/
function showAppForm(data) {

    //	https://basfusext.b2clogin.com/basfusext.onmicrosoft.com/B2C_1_EOP_Signin/oauth2/v2.0/authorize?
    // client_id=52891428-3395-4a1c-932c-42bc2596eace
    // &redirect_uri=https%3A%2F%2Fjwt.ms
    // &scope=openid%20offline_access
    // &response_type=id_token
    // &nonce=135679&state=login&theme=green&ui_locales=en
    $(".enrollment_form").empty();
    if (JSON.parse(data).merged.allFieldsSubmitted != true && !(JSON.parse(data).same_domain)) {
        var elements = JSON.parse(data).merged.data;

        if (elements.length != 0) {
            var buttonHtml = `<div class="col-100">
      <button type="button" class="btn btn-continue con_btn">Continue</button>
      <button type="button" class="btn btn-cancel cancelmodal" onclick="selectedDropDwnValue('')">Cancel</button>
   </div>`;

            var htmlData = "",
                counter = 0,
                multiSelectOption = "",
                optionHtml = "";
            elements.forEach(function (eachData) {
                try {
                    $('.tool_app_name').text(eachData['app_name']);
                    counter++;
                    if (eachData['attrib_type'] == 'text') {
                        htmlData += ` <div class="col-50">
          <label for="${eachData['attrib_name']}">${eachData['attrib_name']}</label>
              <input class="talandAppForm" type="text" data-type="${eachData['crm_attrib_type']}" data-mapid="${eachData['attrib_map_id']}" id="${eachData['attrib_name']}" name="${eachData['attrib_name']}" placeholder="${eachData['default_value']}" value="${typeof eachData['attrib_value'] != 'undefined'  ? eachData['attrib_value'] : ''}" ${eachData['editable'] == 'No' ? 'readonly' : ''}>
       </div>`;
                    } else if (eachData['attrib_type'] == 'select') {
                        var value = eachData['default_value'].split('||');
                        if (eachData.hasOwnProperty('attrib_value')) {
                            value.forEach(function (key, ind) {
                                if (eachData['attrib_value'] == key.split('|')[1]) {
                                    optionHtml += `<option value="${key.split('|')[1]}">${key.split('|')[0]}</option>`
                                } else {
                                    optionHtml += `<option value="${key.split('|')[1]}" selected>${key.split('|')[0]}</option>`
                                }

                            });
                        } else {
                            value.forEach(function (key, ind) {
                                optionHtml += `<option value="${key.split('|')[1]}">${key.split('|')[0]}</option>`
                            });
                        }

                        htmlData += `<div class="col-50">
          <label for="${eachData['attrib_name']}">${eachData['attrib_name']}</label>
          <select data-mapid="${eachData['attrib_map_id']}" id="${eachData['attrib_name']}" data-type="${eachData['crm_attrib_type']}" class="select talandAppForm arrow-intrest ion-chevron-down" value="${eachData['attrib_value'] != null || eachData['attrib_value'] != '' ? eachData['attrib_value'] : ''}" ${eachData['editable '] == 'No' ? 'disabled' : ''}>
            ${optionHtml}
          </select>
       </div>`;
                    } else if (eachData.attrib_type === 'checkbox') {
                        htmlData += `<div class="col-50">
                                    <input class="talandAppForm" type="checkbox" id="${eachData.attrib_name}" name="${eachData.attrib_name}" data-mapid="${eachData.attrib_map_id}" data-type="${eachData['crm_attrib_type']}">
                                    <label for="${eachData.attrib_name}"> ${eachData.attrib_name}</label>
                            </div>`;

                    } else if (eachData.attrib_type === 'multiselect') {
                        var values = eachData['default_value'].split('||');

                        values.forEach(function (key, ind) {
                            var checkecdValue = '';
                            try {
                                var checkvalue = eachData['attrib_value'].split(',');
                                checkvalue.forEach(function (checkedKey) {
                                    if (key.toLocaleLowerCase().startsWith(checkedKey.toLocaleLowerCase())) {
                                        checkecdValue = 'checked';
                                    }
                                });
                            } catch (err) {
                                //  console.log(err);
                            }
                            multiSelectOption += `<li class="checkbox">
                                checkecdValue = 'checked';
                                <input type="checkbox" id="${key.split('|')[1]}" name="${key.split('|')[1]}" value="${key.split('|')[1]}" class="multi_checkbox" ${checkecdValue}>
                        <label for="check-1">${key.split('|')[0]}</label>
                     </li>`;
                            // <option value="${key.split('|')[1]}">${key.split('|')[0]}</option>`
                        });
                        htmlData += `<div class="col-50">
                    <label for="${eachData.attrib_name}">${eachData.attrib_name}</label>
                    <dl class="dropdown">
                       <dt>
                          <a href="javascript:void(0)">
                        <span data-mapid="${eachData.attrib_map_id}" data-type="${eachData['crm_attrib_type']}" name="${eachData.attrib_name}" id="${eachData.attrib_name}" class="multi_select_placeholder talandAppForm" value="${eachData.attrib_value}">${typeof eachData.attrib_value != undefined ? eachData.attrib_value : 'Select All That Apply'}</span><span class="arrow-intrest ion-chevron-down"></span>
                          </a>
                       </dt>
                       <dd>
                          <div class="mutliSelect">
                             <ul class="multiple_select">
                               ${multiSelectOption}
                             </ul>
                          </div>
                       </dd>
                    </dl>
                 </div>`;
                    }
                } catch (err) {
                    // console.error(err);
                }

            });
            if (counter % 2 != 0) {
                htmlData += `<div class="col-50"></div>`;
            }
            $('.enrollment_form').append(htmlData);
            $('.enrollment_form').append(buttonHtml);
            showmultiselectoption();
            $('#enrolment').show();
            $('.multi_checkbox').on('click', function () {
                multicheckbox(event);
            })
            toggleLoader(false);

        } else {
            toggleLoader(true);
            // alert("Array is blank");
            Growlinkredirection();
            //window.location.href = $('.gonow-link').data('href');
            // $('.basftools-wraper').attr('data-id');
            // $('.basftools-wraper').attr('data-apptype');
            //redirect url logic implement
        }
    } else {

       Growlinkredirection();
    }

    $('.con_btn').on('click', function () {
        submitTalantForm();
    });
    $('.cancelmodal').on('click', function () {
        var x = document.getElementById("enrolment");
        x.style.display = "none";
    });

}
/************************Talend Form submit request *********************/
// var appFormSubmitRequest = {
//     "EUPF_ID": "",
//     "Request_Attribute": "APP",
//     "Request_Type": "Update",
//     "Contact_Id": "12345",
//     "Account_BASF_ID": "56789",
//     "Account_Type": "Retailer",
//     "Business_Segment_Id": "Pest Control",
//     "Attributes": [],
//     "Email_Address": ""
// }
var appFormSubmitRequest = {
    "EUPF_ID": "",
    "Request_Attribute": "APP",
    "Request_Type": "Update",
    "Attributes": [],
    "Email_Address": "",
    "Lead_ID": ""
}

function generateRequest(EUPF_ID, Request_Attribute, Request_Type, Account_Type, Business_Segment) {
    var userData = JSON.parse(localStorage.getItem("userloggedindata"));
    var profileData = userData.talendjson.Profile_Data;
    if (userData.talendstatus == "Acknowledged") {
        if (profileData.hasOwnProperty('Lead_Id') && profileData.Lead_Id != '') {
        appFormSubmitRequest.Lead_ID = userData.talendjson.Profile_Data.Lead_Id;
        }
        userData = userData.userinfo;
    } else {
        if(userData.talendstatus == 'Linked'){
            appFormSubmitRequest.account_id = userData.talendjson.Profile_Data.account_id;
            appFormSubmitRequest.Contact_Id = userData.talendjson.Profile_Data.Contact_Id;
        }
        userData = userData.userinfo;
        if(userData.prospect_id != ''){
        appFormSubmitRequest.Lead_ID = userData.prospect_id;
        }
    }
    // appFormSubmitRequest.Account_BASF_ID = Account_BASF_ID;
    // appFormSubmitRequest.Account_Type = Account_Type;
    appFormSubmitRequest.Request_Attribute = Request_Attribute;
    appFormSubmitRequest.EUPF_ID = EUPF_ID;
    appFormSubmitRequest.Email_Address = userData.email;
    // appFormSubmitRequest.Business_Segment_Id = Business_Segment;
    appFormSubmitRequest.Request_Type = Request_Type;
    // appFormSubmitRequest.Contact_Id = ContactId;
    var Attributes = [];
    $('.talandAppForm[data-mapid]:visible').each(function () {
        if ($(this).attr("type") != 'checkbox') {
            var formobj = {}
            formobj["attr_key"] = $(this).attr('data-mapid');
            if (Request_Type.toLocaleLowerCase() == 'fetch') {
                formobj["attr_value"] = "";
            } else {
                formobj["attr_value"] = $(this).val();
            }

            if ($(this).is("span")) {
                if (Request_Type.toLocaleLowerCase() == 'fetch') {
                    formobj["attr_value"] = "";
                } else {
                    formobj["attr_value"] = $(this).text();
                }
            }
            formobj["attr_type"] = $(this).data('type');
            // formobj["attr_type"] = $(this).attr('data-type');
            Attributes.push(formobj);
        }
    });
    $("input[type=checkbox][data-mapid]:visible").each(function () {

        var formobj = {}
        formobj["attr_key"] = $(this).attr('data-mapid');
        if (Request_Type.toLocaleLowerCase() == 'fetch') {
            formobj["attr_value"] = "";
        } else {
            formobj["attr_value"] = $(this).prop('checked') == true ? "Yes" : "No";
        }
        formobj["attr_type"] = $(this).data('type');

        if ($(this).attr('data-mapid') != undefined) {
            Attributes.push(formobj);
        }

    })
    appFormSubmitRequest.Attributes = Attributes
    return appFormSubmitRequest;
}
function disableEnterKeySubmit(){
    $('.personal-info-form, .business-info-form').on('keypress', function(e) {
        return e.which !== 13;
    });
}
function noBsvalueError(){
    $('.bsnovalue-error').hide();
     let newObject = window.localStorage.getItem("userloggedindata");
     let ext_bs = JSON.parse(newObject);
                  ext_bs = ext_bs.userinfo.extension_bs;
     //if bs value is empty show error text and disable dropdown

     if (ext_bs =="" || ext_bs == undefined){
         $('.bsnovalue-error').show();
         $('#customerType').prop('disabled', true).niceSelect('update').prop('readonly', true);
         $('.personal-info-save, .business-info-save').prop('disabled', true);
         disableEnterKeySubmit();
        }
}

function generateProfileRequest(EUPF_ID, Request_Attribute, Request_Type, Account_Type, Business_Segment, Account_SubType) {
    var userData = JSON.parse(localStorage.getItem("userloggedindata"));
    let ext_bs = userData.userinfo.extension_bs;
    let ext_urbs = userData.userinfo.extension_user_Registration_bs;
    var profileData = userData.talendjson.Profile_Data;
    if (userData.talendstatus == "Acknowledged") {
        if (profileData.hasOwnProperty('Lead_Id') && profileData.Lead_Id != '') {
        appFormSubmitRequest.Lead_ID = userData.talendjson.Profile_Data.Lead_Id;
        }
    } else if (userData.talendstatus == "Linked"){
        appFormSubmitRequest.Contact_Id = userData.talendjson.Profile_Data.Contact_Id;
        appFormSubmitRequest.account_id = userData.talendjson.Profile_Data.Accounts[0].account_id;
        if (profileData.hasOwnProperty('Lead_ID') && profileData.Lead_ID != '') {
        appFormSubmitRequest.Lead_ID = userData.talendjson.Profile_Data.Lead_ID;
        }
    } else if (profileData.hasOwnProperty('Lead_ID') && profileData.Lead_ID != '') {
        
        appFormSubmitRequest.Lead_ID = userData.talendjson.Profile_Data.Lead_ID;
    }
    userData = userData.userinfo;
    // appFormSubmitRequest.Account_BASF_ID = Account_BASF_ID;
    // appFormSubmitRequest.Account_Type = Account_Type;
    appFormSubmitRequest.Request_Attribute = Request_Attribute;
    appFormSubmitRequest.EUPF_ID = EUPF_ID;
    appFormSubmitRequest.Email_Address = userData.email;
    // appFormSubmitRequest.Business_Segment_Id = Business_Segment;
    appFormSubmitRequest.Request_Type = Request_Type;
    // appFormSubmitRequest.Contact_Id = ContactId;
    appFormSubmitRequest.extension_bs = getBusinessSegment(ext_bs, ext_urbs, Account_SubType);
    
    appFormSubmitRequest.Account_Type = $('.custom-select.retailerdrop select :selected').data('acctype');
    appFormSubmitRequest.Business_Segment_Id  = localStorage.getItem('businesssegmentid');

    var Attributes = [];
    $('.talandAppForm[data-mapid][basicinfo]').each(function () {
        if ($(this).attr("type") != 'checkbox') {
            var formobj = {}
            formobj["attr_key"] = $(this).attr('data-mapid');
            if (Request_Type.toLocaleLowerCase() == 'fetch') {
                formobj["attr_value"] = "";
            } else {
                if ($(this).attr('data-mapid') == 'Account_Type') {
                    formobj["attr_value"] = getAccountType(Account_SubType);
                } else {
                formobj["attr_value"] = $(this).val();
                }
            }

            if ($(this).is("span")) {
                if (Request_Type.toLocaleLowerCase() == 'fetch') {
                    formobj["attr_value"] = "";
                } else {
                    formobj["attr_value"] = $(this).text();
                }
            }
            // formobj["attr_type"] = $(this).attr('data-type');
            Attributes.push(formobj);
        }
    });
    $("input[type=checkbox][data-mapid][basicinfo]").each(function () {

        var formobj = {}
        formobj["attr_key"] = $(this).attr('data-mapid');
        if (Request_Type.toLocaleLowerCase() == 'fetch') {
            formobj["attr_value"] = "";
        } else {
            formobj["attr_value"] = $(this).prop('checked') == true ? "Yes" : "No";
        }

        if ($(this).attr('data-mapid') != undefined) {
            Attributes.push(formobj);
        }

    })
    appFormSubmitRequest.Attributes = Attributes
    return appFormSubmitRequest;
}

function submitTalantForm() {
    var data = JSON.parse(localStorage.getItem('userloggedindata'));
    var obj = generateRequest(data['talendjson']['Profile_Data']['EUPF_ID'], "APP", "Update", data['talend']['Account_Type'], data['talend']['Business_Segment']);
    obj["id_token"] = JSON.parse(localStorage.getItem("userloggedindata")).login.id_token;
    postAjaxRequest("POST", "/content/basfeupf/us/talendsave.json", obj, redirectToWebsite);
}

function redirectToWebsite(postdata) {
    var responsestatus = JSON.parse(postdata).talendresponse.responseMessage;
    if (responsestatus != 'Error') {
        var data = JSON.parse(localStorage.getItem('userloggedindata'));
        var link = "";
        var pid = '';
        var accountid = '';
        var contactid = '';
        var bs = '';
        if((data.talendstatus == "Acknowledged")||(data.talendstatus == "Linked" && localStorage.getItem('multiAccountUser') == 'Yes')) {
			var profileData = data.talendjson.Profile_Data;
			if (profileData.hasOwnProperty('Lead_Id') && profileData.Lead_Id != '') {
				pid = "&pid=" + data.talendjson.Profile_Data.Lead_Id;
			} 
			else if (profileData.hasOwnProperty('Lead_ID') && profileData.Lead_ID != '') {
				pid = "&pid=" + data.talendjson.Profile_Data.Lead_ID;
			}
			if (profileData.hasOwnProperty('Contact_Id') && profileData.Contact_Id != '') {
				contactid = "&cid=" + data.talendjson.Profile_Data.Contact_Id;
			}
			if (profileData.hasOwnProperty('account_id') && profileData.account_id != '') {
				accountid = "&an=" + data.talendjson.Profile_Data.account_id;
			}
			let userinfo = data.userinfo;
		    if (userinfo.hasOwnProperty('extension_bs') && userinfo.extension_bs != '') {
				bs = "&bs=" + data.userinfo.extension_bs;
			}			
		}
        data['appdata']['data'].forEach(function (e) {
            if (e.app_type == "saml") {
                link = e.app_link;
            }
            if (e.app_type == 'openid') {
                var nonce = e.nonce;
                var uilocale = "";
                try {
                    nonce = JSON.parse(localStorage.getItem('userloggedindata')).userinfo.nonce;
                    uilocale = "&ui_locales=" + JSON.parse(localStorage.getItem('userloggedindata')).userinfo.ui_locales;

                } catch (err) {

                }
                let useState = '';
                let appcontext = '';
                let appuri = '';
                var url = new URL(window.location.href);
				if (e.use_state == "No" && e.app_state == 'Yes' && url.searchParams.has('state')
					&& url.searchParams.get('state') == 'partner') {
					link = $('#sfcc_redirectURI').val();
				} else if (e.use_state == "No") {
                    let appState = window.location.href.split("?")[1].split("&");
                    appState.forEach(function (ele) {
                        try {
                            if (ele.split("=")[0] == "state" && ele.split("=")[1] != '') {
                                useState = "&state=" + ele.split("=")[1];
                            }
                        } catch (err) {}
                    })
                    try {
                        appcontext = JSON.parse(localStorage.getItem('userloggedindata')).userinfo.appContext;
                        if (appcontext != undefined && appcontext != null) {
                            appcontext = "&appContext=" + appcontext;
                        }

                    } catch (err) {
                        appcontext = '';
                    }
                    try {
                        appuri = JSON.parse(localStorage.getItem('userloggedindata')).userinfo.appUri;
                        if (appuri != undefined && appuri != null) {
                            appuri = "&appUri=" + appuri;
                        }
                    } catch (err) {
                        appuri = '';
                    }
                    link = e.azure_link + "?p=" + e.policy + "&client_id=" + e.client_id + "&nonce=" + nonce + "&redirect_uri=" + e.app_link + "&scope=" + e.scope + "&response_type=" + e.response_type + "&response_mode=" + e.response_mode + useState + pid + bs + contactid + accountid + "&theme=" + e.theme + uilocale + appcontext + appuri;
                } else {
                    if (e.state != '') {
                        useState = "&state=" + e.state;
                    }
                    try {
                        appcontext = "&appContext=" + JSON.parse(localStorage.getItem('userloggedindata')).userinfo.appContext;
                    } catch (err) {
                        appcontext = '';
                    }
                    try {
                        appuri = "&appUri=" + JSON.parse(localStorage.getItem('userloggedindata')).userinfo.appUri;
                    } catch (err) {
                        appuri = '';
                    }
                    link = e.azure_link + "?p=" + e.policy + "&client_id=" + e.client_id + "&nonce=" + nonce + "&redirect_uri=" + e.app_link + "&scope=" + e.scope + "&response_type=" + e.response_type + "&response_mode=" + e.response_mode + useState + pid + bs + contactid + accountid + "&theme=" + e.theme + uilocale + appcontext + appuri;
                }

            }
        });
        window.location.href = link;
    } else {
        $('.form-error-text').text('We get Error in response.Somethings went wrong');
        $(".global-error-red").show();
        $('html, body').animate({
            scrollTop: 0
        }, 'slow');
    }
}

function basicInfoPopulation() {

    try {
        $('.eupf-loader').show();
        var userdatafrmstorage = JSON.parse(localStorage.getItem("userloggedindata"));
        EUPF_ID = userdatafrmstorage["userinfo"]["sub"];
        // Contact_Id = userdatafrmstorage["talendjson"]["Profile_Data"]["Contact_Id"];
        // Account_BASF_ID = userdatafrmstorage["talendjson"]["Profile_Data"]["Account_BASF_ID"];
        var obj = generateProfileRequest(userdatafrmstorage['userinfo']['sub'], "Profile", "Fetch", "", "", "");
        // if(userdatafrmstorage['talendjson']["Profile_Data"]['Status'].toUpperCase() == "LINKED"){
        //     obj.account_id = userdatafrmstorage['talendjson']["Profile_Data"]["Accounts"][0]["account_id"];
        //     obj.Contact_Id = userdatafrmstorage['talendjson']["Profile_Data"]["Contact_Id"];
        // }
        obj["type"] = "talend-user-data";

        // obj["id_token"] = JSON.parse(localStorage.getItem("userloggedindata")).login.id_token
        postAjaxRequest("POST", "/content/basfeupf/us/formdata.json", obj, populateInfo);

    } catch (err) {

    }
}

function populateInfo(data) {
    if (JSON.parse(data)["responseCode"] === 200) {
        var prodata = JSON.parse(data);
        var profilearr = prodata["Attributes"];
        setCustomerDropDown();
        personalData(profilearr);
        fillPersonalForm(profilearr);
        $('[for=leagalReview]').on('click', (e) => {
            $('input[data-mapid=' + e.currentTarget.getAttribute("data-id") + ']').trigger('click')
        })
        // profilearr.forEach(function (eachdata) {
        //     if (eachdata.attr_value == 'Yes') {
        //         $("#regForm").find('[data-mapid="' + eachdata.attr_key + '"]').prop('checked', true);
        //     } else {
        //         $("#regForm").find('[data-mapid="' + eachdata.attr_key + '"]').prop('checked', false);
        //         $("#regForm").find('[data-mapid="' + eachdata.attr_key + '"]').val(eachdata.attr_value);
        //     }
        // });
        // window.location.reload(true);
        

    } else {
        $('.form-error-text').text('We get Error in response.Somethings went wrong');
        $(".global-error-red").show();
    }
    $('html, body').animate({
        scrollTop: 0
    }, 'slow');
    $('.eupf-loader').hide();
}

function setCustomerDropDown() {
    const dropDown = $('.custom-select.new-customer select');
    dropDown.niceSelect('destroy');
    const usCropId = 22;
    var segId = JSON.parse(localStorage.getItem('userloggedindata')).userinfo.extension_bs;

    if (usCropId == segId) {
        dropDown.find('[data-seg!=22]').remove();
        } else {
         dropDown.find('[data-seg=0]').remove();
        }

        // Customer type Dropdown populate

        let newObject = window.localStorage.getItem("userloggedindata");
        let ext_bs = JSON.parse(newObject);
                     ext_bs = ext_bs.userinfo.extension_bs;     
        let ext_urbs =JSON.parse(newObject);
                    ext_urbs = ext_urbs.userinfo.extension_user_Registration_bs;
     
                    if(ext_bs == '22' && ext_urbs == '22') {
                        $("#customerType").empty().trigger('change');
                        let ebs_Equal_rbs =["Distributor", "Retailer", "Grower", "Crop Consultant"];
                
                        $.each(ebs_Equal_rbs, function(){
                                $('#customerType').append(`<option value='${this}'>${(this)}</option>`);                    
                           });
                    }
                
                    if (ext_bs != '22' && ext_urbs != '22'){
                
                        $("#customerType").empty().trigger('change');
                        let ebs_rbs_not = ["Distributor", "Golf course", "GH/nursery", "Pest Control", "Vegetation Management", "Lawn Care"]
                
                        $.each(ebs_rbs_not , function(){
                                $('#customerType').append(`<option value='${this}'>${(this)}</option>`);  
                            });  
                    }
                
                  if ((ext_bs == '22' && ext_urbs != '22') || (ext_bs != '22' && ext_urbs == '22')){
                    $("#customerType").empty().trigger('change');
                        let ebs_rbsViceVersa =["Retailer", "Grower", "Crop Consultant", "Distributor", "Golf course", "GH/nursery", "Pest Control", "Vegetation Management", "Lawn Care"]
                
                        $.each(ebs_rbsViceVersa  , function(){
                                $('#customerType').append(`<option value='${this}'>${(this)}</option>`);   
                            }); 
                  }
    dropDown.niceSelect();
}

function personalData(data) {
    data.forEach(ele => {
        if (ele.attr_value != null && ele.attr_value != undefined) {
            if ($('.update-personal [data-mapid=' + ele.attr_key + ']')[0].attributes.type.value == 'checkbox') {

                if (ele.attr_value.toUpperCase() == 'YES') {
                    $('#tab1').find('[data-mapid=' + ele.attr_key + ']').attr('class', "");
                    $('#tab1').find('[data-mapid=' + ele.attr_key + '] span').hide();
                    $('#tab1').find('[data-mapid=' + ele.attr_key + ']').attr('class', "green-tick");
                } else {
                    $('#tab1').find('[data-mapid=' + ele.attr_key + ']').attr('class', "");
                    $('#tab1').find('[data-mapid=' + ele.attr_key + '] span').show();
                    $('#tab1').find('[data-mapid=' + ele.attr_key + ']').attr('class', "red-intocon");
                }
            } else {
                $('#tab1').find('[data-mapid=' + ele.attr_key + ']').find('span').text(ele.attr_value);
            }
        } else {
            if ($('.update-personal [data-mapid=' + ele.attr_key + ']')[0].attributes.type.value == 'checkbox') {
                $('#tab1').find('[data-mapid=' + ele.attr_key + ']').attr('class', "");
                $('#tab1').find('[data-mapid=' + ele.attr_key + '] span').show();
                $('#tab1').find('[data-mapid=' + ele.attr_key + ']').attr('class', "red-intocon");
            }
        }
    })
}

function fillPersonalForm(data) {
    data.forEach(ele => {
        if (ele.attr_value != null && ele.attr_value != undefined) {
            if ($('.update-personal [data-mapid=' + ele.attr_key + ']')[0].attributes.type.value == 'checkbox') {
                if (ele.attr_value == 'Yes') {
                    $('.update-personal [data-mapid=' + ele.attr_key + ']').prop('checked', true);
                }
            } else if ($('.update-personal [data-mapid=' + ele.attr_key + ']')[0].attributes.type.value == 'select') {
                $('.update-personal [data-mapid=' + ele.attr_key + ']').find('option[value="' + ele.attr_value + '"]').prop('selected', 'selected');
                $('.update-personal [data-mapid=' + ele.attr_key + ']').niceSelect('update');
            } else {
                $('.update-personal [data-mapid=' + ele.attr_key + ']').val(ele.attr_value);
            }
        }
    })
    JSON.parse(localStorage.getItem('userloggedindata')).talendstatus.toUpperCase()== 'LINKED' && ($('.update-personal #customerType').prop('disabled', true).niceSelect('update') && $('.update-personal #businessName').prop('readonly', true));
}

function showmultiselectoption() {
    $(".dropdown dt a").on('click', function () {
        $(".dropdown dd ul").slideToggle('fast');
    });

    $(".dropdown dd ul li a").on('click', function () {
        $(".dropdown dd ul").hide();
    });

    $(document).bind('click', function (e) {
        var $clicked = $(e.target);
        if (!$clicked.parents().hasClass("dropdown")) $(".dropdown dd ul").hide();
    });
}

function getSelectedValue(id) {
    return $("#" + id).find("dt a span.value").html();
}

function getCountry() {
	var path = window.location.pathname;
	if (path.includes('/content')) {
		return path.split('/')[3];
	} else {
		return path.split('/')[1];
	}
}

function getLanguage() {
	var path = window.location.pathname;
	if (path.includes('/content')) {
		return path.split('/')[4];
	} else {
		return path.split('/')[2];
	}
}

function getAccountType(SubType) {
    if (SubType == 'Retailer' || SubType == 'Distributor') {
         return SubType;
    }
     return 'End User';
}

function getBusinessSegment(extension_bs, extension_user_Registration_bs, Account_SubType) {
	let non_crop_protection_sub_types = ["Distributor", "Golf course", "GH/nursery", "Pest Control", "Vegetation Management", "Lawn Care"];
    let crop_protection_sub_types = ["Distributor", "Retailer", "Grower", "Crop Consultant"];
    
    if (extension_user_Registration_bs != '22' && extension_bs != '22') {
         return extension_bs;
    }
    
    if (extension_user_Registration_bs == '22' && extension_bs == '22') {
         return extension_bs;
    }
    
	if ((extension_user_Registration_bs != '22' && extension_bs == '22' && crop_protection_sub_types.indexOf(Account_SubType) !== -1) || 
	    (extension_user_Registration_bs == '22' && extension_bs != '22' && non_crop_protection_sub_types.indexOf(Account_SubType) !== -1)) {
		return extension_bs;
	} else {
		return extension_user_Registration_bs;
	}
	
}
// add " - " to mobile number
$(function () {
    $('#phone').keydown(function (e) {
        var key = e.charCode || e.keyCode || 0;
        $text = $(this);
        if (key !== 8 && key !== 9) {
            if ($text.val().length === 3) {
                $text.val($text.val() + '-');
            }
            if ($text.val().length === 7) {
                $text.val($text.val() + '-');
            }
        }
        return (key == 8 || key == 9 || key == 46 || (key >= 48 && key <= 57) || (key >= 96 && key <= 105));
    })

    $('#mobile').keydown(function (e) {
        var key = e.charCode || e.keyCode || 0;
        $text = $(this);
        if (key !== 8 && key !== 9) {
            if ($text.val().length === 3) {
                $text.val($text.val() + '-');
            }
            if ($text.val().length === 7) {
                $text.val($text.val() + '-');
            }
        }
        return (key == 8 || key == 9 || key == 46 || (key >= 48 && key <= 57) || (key >= 96 && key <= 105));
    })
});

$(function () {

    //Footer mobile accordian

    if (window.matchMedia('(max-width: 768px)').matches) {

        $('.acc__title').click(function (j) {

            var dropDown = $(this).closest('.acc__card').find('.acc__panel');
            $(this).closest('.footer-container').find('.acc__panel').not(dropDown).slideUp();

            if ($(this).hasClass('active')) {
                $(this).removeClass('active');

            } else {
                $(this).closest('.footer-container').find('.acc__title.active').removeClass('active');
                $(this).addClass('active');
            }

            dropDown.stop(false, true).slideToggle();
            j.preventDefault();
        });

    }
});
$(document).ready(function () {
    if (window.location.href.indexOf("internal.html") > -1) {
        document.querySelector(".menu-container").style.display = 'none';
    }
});
$(document).ready(function () {
    $(".updateclose").click(function () {
        $(".update-personalcon,.backgroundpopup,.update-business").hide();
    });

    $(".edit-personal").click(function () {
        noBsvalueError();
        $(".update-personalcon,.backgroundpopup").show();     
    });

    $(".edit-business").click(function () {
         noBsvalueError();
        $(".update-business,.backgroundpopup").show();
    });
});